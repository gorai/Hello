package com.isb.gabps.concomseg.sftp.batch;

/**
 * Constantes relativas al batch.
 * 
 * @author xIS08485
 */
public class BatchGlobals {
	// Nombre de los jobs
	public static final String JOB_PULL_NAME = "PullFilesJob";
	public static final String JOB_PUSH_NAME = "PushFilesJob";
	public static final String JOB_REPORT_NAME = "ReportJob";
	// URLs de los jobs
	public static final String URL_BASE = "/job-beta";
	public static final String URL_PARAM_DATE = "{date}";
	public static final String URL_PULL_JOB = "/pull-files/" + URL_PARAM_DATE;
	public static final String URL_PUSH_JOB = "/push-files/{date}";
	
	// Parámetros de entrada a los jobs
	public static final String JOB_PARAM_DATE = "date";
	public static final String JOB_PARAM_CYCLE = "cycle";
	
	// Nombre de parámetros en el contexto de los jobs/steps
	public static final String JOB_CTX_JOB_ID = "job.id";
	public static final String JOB_CTX_JOB_ACTION = "job.action";
	public static final String JOB_CTX_DOWNLOAD_POL = "step.download.policies";
	public static final String JOB_CTX_DOWNLOAD_COL = "step.download.collections";
	
	// Pasos de los jobs
	public static final String STEP_DOWNLOAD = "DownloadStep";
	public static final String STEP_MERGE_UNION = "MergeUnionStep";
	public static final String STEP_MERGE_JOIN = "MergeJoinStep";
	public static final String STEP_UPLOAD = "UploadStep";
	public static final String STEP_REPORT = "ReportStep";
	// Componentes de los steps
	public static final String TASKLET_DOWNLOAD = "DownloadTasklet";
	public static final String TASKLET_MERGE_UNION = "MergeUnionTasklet";
	public static final String TASKLET_MERGE_JOIN = "MergeJoinTasklet";
	public static final String TASKLET_UPLOAD = "UploadTasklet";
	public static final String TASKLET_REPORT = "Reportasklet";
	
	// Acciones de un job
	// IMPORTANTE: Si se cambia o agrega una acción, se debe actualizar el messages.properties 
	public static final String ACTION_CONNECT = "sftp.connecting";
	public static final String ACTION_DOWNLOAD_POL = "sftp.downloading.policies";
	public static final String ACTION_DOWNLOAD_COL = "sftp.downloading.collections";
	public static final String ACTION_UPLOAD = "sftp.uploading";
	public static final String ACTION_MERGE_POL = "merge.policies";
	public static final String ACTION_MERGE_COL = "merge.collections";
	public static final String ACTION_MERGE_JOIN = "merge.join";
	
	// Validadores
	public static final String VALIDATOR_DATE = "DateValidator";
	
	// Listeners
	public static final String LISTENER_WORKDIR = "WorkdirListener";
	
	
	
	/**
	 * Clase no inicializable.
	 * Solo contiene atributos públicos.
	 */
	private BatchGlobals() {
	}
}
