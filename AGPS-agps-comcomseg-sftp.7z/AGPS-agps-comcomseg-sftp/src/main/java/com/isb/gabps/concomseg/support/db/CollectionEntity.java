package com.isb.gabps.concomseg.support.db;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Un registro de BBDD guardado por el proceso de contabilidad (concomseg-service).
 * 
 * @author xIS08485
 */
public class CollectionEntity {
	// Columnas de la tabla
	private String poliza;
	private Integer suplemento;
	private String mediador;
	private String producto;
	private String recibo;
	private String situacion;
	private String tipo;
	private String periodoPago;
	private LocalDate fechaSituacion;
	private LocalDate fechaEfecto;
	private LocalDate fechaVencimiento;
	private LocalDate fechaEmision;
	private BigDecimal impPrimaTotal;
	private BigDecimal impPrimaNeta;
	private BigDecimal impCargo;
	private BigDecimal impComisBruta;
	private BigDecimal impComisLiquida;
	private String estadoInterno;
	private String retroContab;
	private LocalDate fechaAlta;
	private LocalDate fechaRetroComis;
	private LocalDate fechaUltPeriodo;
	private BigDecimal impUltPeriodo;
	private BigDecimal impTotalPeriodo;
	private String usuario;
	private LocalDateTime fechaModificacion;
	
	
	
	/**
	 * Devuelve la póliza.
	 * 
	 * @return Código de la póliza - CHAR(14)
	 */
	public String getPoliza() {
		return poliza;
	}
	
	/**
	 * Asigna la póliza.
	 * 
	 * @param poliza Código de la póliza - CHAR(14)
	 */
	public void setPoliza(String poliza) {
		this.poliza = poliza;
	}
	
	/**
	 * Devuelve el número de suplemento.
	 * 
	 * @return Número de suplemento - DEC(5,0)
	 */
	public Integer getSuplemento() {
		return suplemento;
	}
	
	/**
	 * Asigna el número de suplemento.
	 * 
	 * @param suplemento Número de suplemento - DEC(5,0)
	 */
	public void setSuplemento(Integer suplemento) {
		this.suplemento = suplemento;
	}
	
	/**
	 * Asigna el número de suplemento.
	 * 
	 * @param suplemento Número de suplemento - DEC(5,0)
	 */
	public void setSuplemento(BigDecimal suplemento) {
		if (suplemento == null) {
			setSuplemento((Integer)null);
		} else {
			setSuplemento(suplemento.intValue());
		}
	}
	
	/**
	 * Devuelve el mediador.
	 * 
	 * @return Código del mediador - CHAR(10)
	 */
	public String getMediador() {
		return mediador;
	}
	
	/**
	 * Asigna el mediador.
	 * 
	 * @param mediador Código del mediador - CHAR(10)
	 */
	public void setMediador(String mediador) {
		this.mediador = mediador;
	}
	
	/**
	 * Devuelve el producto.
	 * 
	 * @return Código del producto - CHAR(5)
	 */
	public String getProducto() {
		return producto;
	}
	
	/**
	 * Asigna el producto.
	 * 
	 * @param producto Código del producto - CHAR(5)
	 */
	public void setProducto(String producto) {
		this.producto = producto;
	}
	
	/**
	 * Devuelve el recibo.
	 * 
	 * @return Código del recibo - CHAR(12)
	 */
	public String getRecibo() {
		return recibo;
	}
	
	/**
	 * Asigna el recibo.
	 * 
	 * @param recibo Código del recibo - CHAR(12)
	 */
	public void setRecibo(String recibo) {
		this.recibo = recibo;
	}
	
	/**
	 * Devuelve la situación del recibo.
	 * 
	 * @return Código de situación del recibo - CHAR(2)
	 */
	public String getSituacion() {
		return situacion;
	}
	
	/**
	 * Asigna la situación del recibo.
	 * 
	 * @param situacion Código de situación del recibo - CHAR(2)
	 */
	public void setSituacion(String situacion) {
		this.situacion = situacion;
	}
	
	/**
	 * Devuelve el tipo de recibo.
	 * 
	 * @return Código del tipo de recibo - CHAR(2)
	 */
	public String getTipo() {
		return tipo;
	}
	
	/**
	 * Asigna el tipo de recibo.
	 * 
	 * @param tipo Código del tipo de recibo - CHAR(2)
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	/**
	 * Devuelve la periodicidad de pago.
	 * 
	 * @return Código de la periodicidad de pago - CHAR(2)
	 */
	public String getPeriodoPago() {
		return periodoPago;
	}
	
	/**
	 * Asigna la periodicidad de pago.
	 * 
	 * @param periodoPago Código de la periodicidad de pago - CHAR(2)
	 */
	public void setPeriodoPago(String periodoPago) {
		this.periodoPago = periodoPago;
	}
	
	/**
	 * Devuelve la fecha de la situación activa.
	 * 
	 * @return Fecha de situación - DATE
	 */
	public LocalDate getFechaSituacion() {
		return fechaSituacion;
	}
	
	/**
	 * Asigna la fecha de la situación activa.
	 * 
	 * @param fechaSituacion Fecha de situación - DATE
	 */
	public void setFechaSituacion(LocalDate fechaSituacion) {
		this.fechaSituacion = fechaSituacion;
	}
	
	/**
	 * Asigna la fecha de la situación activa.
	 * 
	 * @param fechaSituacion Fecha de situación - DATE
	 */
	public void setFechaSituacion(Date fechaSituacion) {
		if (fechaSituacion == null) {
			setFechaSituacion((LocalDate)null);
		} else {
			setFechaSituacion(fechaSituacion.toLocalDate());
		}
	}
	
	/**
	 * Devuelve la fecha de efecto.
	 * 
	 * @return Fecha de efecto - DATE
	 */
	public LocalDate getFechaEfecto() {
		return fechaEfecto;
	}
	
	/**
	 * Asigna la fecha de efecto.
	 * 
	 * @param fechaEfecto Fecha de efecto - DATE
	 */
	public void setFechaEfecto(LocalDate fechaEfecto) {
		this.fechaEfecto = fechaEfecto;
	}
	
	/**
	 * Asigna la fecha de efecto.
	 * 
	 * @param fechaEfecto Fecha de efecto - DATE
	 */
	public void setFechaEfecto(Date fechaEfecto) {
		if (fechaSituacion == null) {
			setFechaEfecto((LocalDate)null);
		} else {
			setFechaEfecto(fechaEfecto.toLocalDate());
		}
	}
	
	/**
	 * Devuelve la fecha de vencimiento.
	 * 
	 * @return Fecha de vencimiento - DATE
	 */
	public LocalDate getFechaVencimiento() {
		return fechaVencimiento;
	}
	
	/**
	 * Asigna la fecha de vencimiento.
	 * 
	 * @param fechaVencimiento Fecha de vencimiento - DATE
	 */
	public void setFechaVencimiento(LocalDate fechaVencimiento) {
		this.fechaVencimiento = fechaVencimiento;
	}
	
	/**
	 * Asigna la fecha de vencimiento.
	 * 
	 * @param fechaVencimiento Fecha de vencimiento - DATE
	 */
	public void setFechaVencimiento(Date fechaVencimiento) {
		if (fechaVencimiento == null) {
			setFechaVencimiento((LocalDate)null);
		} else {
			setFechaVencimiento(fechaVencimiento.toLocalDate());
		}
	}
	
	/**
	 * Devuelve la fecha de emisión.
	 * 
	 * @return Fecha de emisión - DATE
	 */
	public LocalDate getFechaEmision() {
		return fechaEmision;
	}
	
	/**
	 * Asigna la fecha de emisión.
	 * 
	 * @param fechaEmision Fecha de emisión - DATE
	 */
	public void setFechaEmision(LocalDate fechaEmision) {
		this.fechaEmision = fechaEmision;
	}
	
	/**
	 * Asigna la fecha de emisión.
	 * 
	 * @param fechaEmision Fecha de emisión - DATE
	 */
	public void setFechaEmision(Date fechaEmision) {
		if (fechaEmision == null) {
			setFechaEmision((LocalDate)null);
		} else {
			setFechaEmision(fechaEmision.toLocalDate());
		}
	}
	
	/**
	 * Devuelve la prima total.
	 * 
	 * @return Importe de la prima total - DEC(17,2)
	 */
	public BigDecimal getImpPrimaTotal() {
		return impPrimaTotal;
	}
	
	/**
	 * Asigna la prima total.
	 * 
	 * @param impPrimaTotal Importe de la prima total - DEC(17,2)
	 */
	public void setImpPrimaTotal(BigDecimal impPrimaTotal) {
		this.impPrimaTotal = impPrimaTotal;
	}
	
	/**
	 * Devuelve la prima neta.
	 * 
	 * @return Importe de la prima neta - DEC(17,2)
	 */
	public BigDecimal getImpPrimaNeta() {
		return impPrimaNeta;
	}
	
	/**
	 * Asigna la prima neta.
	 * 
	 * @param impPrimaNeta Importe de la prima neta - DEC(17,2)
	 */
	public void setImpPrimaNeta(BigDecimal impPrimaNeta) {
		this.impPrimaNeta = impPrimaNeta;
	}
	
	/**
	 * Devuelve los cargos.
	 * 
	 * @return Importe de los cargos - DEC(17,2)
	 */
	public BigDecimal getImpCargo() {
		return impCargo;
	}
	
	/**
	 * Asigna los cargos.
	 * 
	 * @param impCargo Importe de los cargos - DEC(17,2)
	 */
	public void setImpCargo(BigDecimal impCargo) {
		this.impCargo = impCargo;
	}
	
	/**
	 * Devuelve la comisión bruta.
	 * 
	 * @return Importe de la comisión bruta - DEC(17,2)
	 */
	public BigDecimal getImpComisBruta() {
		return impComisBruta;
	}
	
	/**
	 * Asigna la comisión bruta.
	 * 
	 * @param impComisBruta Importe de la comisión bruta - DEC(17,2)
	 */
	public void setImpComisBruta(BigDecimal impComisBruta) {
		this.impComisBruta = impComisBruta;
	}
	
	/**
	 * Devuelve la comisión líquida.
	 * 
	 * @return Importe de la comisión líquida - DEC(17,2)
	 */
	public BigDecimal getImpComisLiquida() {
		return impComisLiquida;
	}
	
	/**
	 * Asigna la comisión líquida.
	 * 
	 * @param impComisLiquida Importe de la comisión líquida - DEC(17,2)
	 */
	public void setImpComisLiquida(BigDecimal impComisLiquida) {
		this.impComisLiquida = impComisLiquida;
	}
	
	/**
	 * Devuelve el estado interno.
	 * 
	 * @return Código del estado interno - CHAR(1)
	 */
	public String getEstadoInterno() {
		return estadoInterno;
	}
	
	/**
	 * Asigna el estado interno.
	 * 
	 * @param estadoInterno Código del estado interno - CHAR(1)
	 */
	public void setEstadoInterno(String estadoInterno) {
		this.estadoInterno = estadoInterno;
	}
	
	/**
	 * Devuelve el indicador de retrocesión.
	 * 
	 * @return Indicador de retrocesión de contabilidad - CHAR(1)
	 */
	public String getRetroContab() {
		return retroContab;
	}
	
	/**
	 * Asigna el indicador de retrocesión.
	 * 
	 * @param retroContab Indicador de retrocesión de contabilidad - CHAR(1)
	 */
	public void setRetroContab(String retroContab) {
		this.retroContab = retroContab;
	}
	
	/**
	 * Devuelve la fecha de alta.
	 * 
	 * @return Fecha de alta - DATE
	 */
	public LocalDate getFechaAlta() {
		return fechaAlta;
	}
	
	/**
	 * Asigna la fecha de alta.
	 * 
	 * @param fechaAlta Fecha de alta - DATE
	 */
	public void setFechaAlta(LocalDate fechaAlta) {
		this.fechaAlta = fechaAlta;
	}
	
	/**
	 * Asigna la fecha de alta.
	 * 
	 * @param fechaAlta Fecha de alta - DATE
	 */
	public void setFechaAlta(Date fechaAlta) {
		if (fechaAlta == null) {
			setFechaAlta((LocalDate)null);
		} else {
			setFechaAlta(fechaAlta.toLocalDate());
		}
	}
	
	/**
	 * Devuelve la fecha de retrocesión.
	 * 
	 * @return Fecha de retrocesión de comisión - DATE
	 */
	public LocalDate getFechaRetroComis() {
		return fechaRetroComis;
	}
	
	/**
	 * Asigna la fecha de retrocesión.
	 * 
	 * @param fechaRetroComis Fecha de retrocesión de comisión - DATE
	 */
	public void setFechaRetroComis(LocalDate fechaRetroComis) {
		this.fechaRetroComis = fechaRetroComis;
	}
	
	/**
	 * Asigna la fecha de retrocesión.
	 * 
	 * @param fechaRetroComis Fecha de retrocesión de comisión - DATE
	 */
	public void setFechaRetroComis(Date fechaRetroComis) {
		if (fechaRetroComis == null) {
			setFechaRetroComis((LocalDate)null);
		} else {
			setFechaRetroComis(fechaRetroComis.toLocalDate());
		}
	}
	
	/**
	 * Devuelve fecha de última periodificación.
	 * 
	 * @return Fecha de última periodificación - DATE
	 */
	public LocalDate getFechaUltPeriodo() {
		return fechaUltPeriodo;
	}
	
	/**
	 * Asigna la fecha de última periodificación.
	 * 
	 * @param fechaUltPeriodo Fecha de última periodificación - DATE
	 */
	public void setFechaUltPeriodo(LocalDate fechaUltPeriodo) {
		this.fechaUltPeriodo = fechaUltPeriodo;
	}
	
	/**
	 * Asigna la fecha de última periodificación.
	 * 
	 * @param fechaUltPeriodo Fecha de última periodificación - DATE
	 */
	public void setFechaUltPeriodo(Date fechaUltPeriodo) {
		if (fechaUltPeriodo == null) {
			setFechaUltPeriodo((LocalDate)null);
		} else {
			setFechaUltPeriodo(fechaUltPeriodo.toLocalDate());
		}
	}
	
	/**
	 * Devuelve el importe de la última periodificación.
	 * 
	 * @return Importe de última periodificación - DEC(17,2) 
	 */
	public BigDecimal getImpUltPeriodo() {
		return impUltPeriodo;
	}
	
	/**
	 * Asigna el importe de la última periodificación.
	 * 
	 * @param impUltPeriodo Importe de última periodificación - DEC(17,2)
	 */
	public void setImpUltPeriodo(BigDecimal impUltPeriodo) {
		this.impUltPeriodo = impUltPeriodo;
	}
	
	/**
	 * Devuelve el importe de la periodificación total.
	 * 
	 * @return Importe de periodificación total - DEC(17,2)
	 */
	public BigDecimal getImpTotalPeriodo() {
		return impTotalPeriodo;
	}
	
	/**
	 * Asigna el importe de la periodificación total.
	 * 
	 * @param impTotalPeriodo Importe de periodificación total - DEC(17,2)
	 */
	public void setImpTotalPeriodo(BigDecimal impTotalPeriodo) {
		this.impTotalPeriodo = impTotalPeriodo;
	}
	
	/**
	 * Devuelve el usuario.
	 * 
	 * @return Código del usuario - CHAR(30)
	 */
	public String getUsuario() {
		return usuario;
	}
	
	/**
	 * Asigna el usuario.
	 * 
	 * @param usuario Código del usuario - CHAR(30)
	 */
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	
	/**
	 * Devuelve la fecha de última modificación.
	 * 
	 * @return Fecha de última modificación - DATE
	 */
	public LocalDateTime getFechaModificacion() {
		return fechaModificacion;
	}
	
	/**
	 * Asigna la fecha de última modificación.
	 * 
	 * @param fechaModificacion Fecha de última modificación - TIMESTAMP
	 */
	public void setFechaModificacion(LocalDateTime fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	
	/**
	 * Asigna la fecha de última modificación.
	 * 
	 * @param fechaModificacion Fecha de última modificación - TIMESTAMP
	 */
	public void setFechaModificacion(Timestamp fechaModificacion) {
		if (fechaModificacion == null) {
			setFechaModificacion((LocalDateTime)null);
		} else {
			setFechaModificacion(fechaModificacion.toLocalDateTime());
		}
	}
}
