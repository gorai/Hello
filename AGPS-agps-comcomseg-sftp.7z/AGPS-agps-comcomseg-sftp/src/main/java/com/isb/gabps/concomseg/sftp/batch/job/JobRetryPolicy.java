package com.isb.gabps.concomseg.sftp.batch.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.retry.RetryContext;
import org.springframework.retry.policy.SimpleRetryPolicy;

/**
 * Extensión al RetryPolicy para comprobar si paramos cuando el job lo solicita.
 * 
 * @author xIS08485
 * 
 */
public class JobRetryPolicy extends SimpleRetryPolicy {
	// Estaticos
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(JobRetryPolicy.class);
	
	// Identificador del job
	private long jobExecutionId;
	
	// Para buscar el job en ejecucion
	private transient JobExplorer jobExplorer;
	
	/**
	 * Job explorer para buscar la ejecución del job en curso.
	 * 
	 * @param jobExplorer Job explorer
	 */
	public void setJobExplorer(JobExplorer jobExplorer) {
		this.jobExplorer = jobExplorer;
	}
	
	/**
	 * Identificador de la ejecución del job en curso.
	 * 
	 * @param jobExecutionId Identificador
	 */
	public void setJobExecutionId(long jobExecutionId) {
		this.jobExecutionId = jobExecutionId;
	}
	
	/**
	 * Agregamos comprobación del job.
	 * Si se está parando, cortamos los reintentos del Retry.
	 * 
	 * @see SimpleRetryPolicy#canRetry(RetryContext)
	 */
	@Override
	public boolean canRetry(RetryContext context) {
		boolean result = false;
		
		// Si clase padre dice que podemos continuar, comprobamos estado del job
		if (parentCanRetry(context)) {
			if ((jobExplorer != null) && (jobExecutionId > 0)) {
				// Si el job tiene la marca de parar, cortamos los reintentos
				JobExecution jobExec = jobExplorer.getJobExecution(jobExecutionId);
				result = jobExec.getStatus() != BatchStatus.STOPPING;
			} else { 
				result = true;
			}
		}
		
		// true = continuamos con la siguiente itearación
		LOGGER.debug("Resultado retry policy: " + result);
		return result;
	}
	
	// Proxy al método de la superclass, para poder hacer spy con el mockito
	boolean parentCanRetry(RetryContext context) {
		return super.canRetry(context);
	}
}
