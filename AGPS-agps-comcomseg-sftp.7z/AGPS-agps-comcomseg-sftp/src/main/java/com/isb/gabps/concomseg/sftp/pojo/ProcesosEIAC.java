//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantaci?n de la referencia de enlace (JAXB) XML v2.3.0 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perder?n si se vuelve a compilar el esquema de origen. 
// Generado el: 2019.06.25 a las 12:23:50 PM CEST 
//


package com.isb.gabps.concomseg.sftp.pojo;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Cabecera"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="FechaCreacion" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *                   &lt;element name="Emisor"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="CodigoInterno" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                             &lt;element name="CodigoDGS" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="Receptor"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="CodigoInterno" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/&gt;
 *                             &lt;element name="CodigoDGS" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="DatosProcesos"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="DetalleProcesos"&gt;
 *                               &lt;complexType&gt;
 *                                 &lt;complexContent&gt;
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                     &lt;sequence&gt;
 *                                       &lt;element name="DetalleProceso" maxOccurs="unbounded"&gt;
 *                                         &lt;complexType&gt;
 *                                           &lt;complexContent&gt;
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                               &lt;sequence&gt;
 *                                                 &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                                 &lt;element name="Transaccion" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                                 &lt;element name="Periodo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                                 &lt;element name="FechaDesde" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *                                                 &lt;element name="FechaHasta" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *                                               &lt;/sequence&gt;
 *                                             &lt;/restriction&gt;
 *                                           &lt;/complexContent&gt;
 *                                         &lt;/complexType&gt;
 *                                       &lt;/element&gt;
 *                                     &lt;/sequence&gt;
 *                                   &lt;/restriction&gt;
 *                                 &lt;/complexContent&gt;
 *                               &lt;/complexType&gt;
 *                             &lt;/element&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="DatosLote"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="IdLote" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
 *                             &lt;element name="NumeroFicheros" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
 *                             &lt;element name="SecuenciaFichero" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Objetos"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Recibo" maxOccurs="unbounded"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="DatosPoliza"&gt;
 *                               &lt;complexType&gt;
 *                                 &lt;complexContent&gt;
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                     &lt;sequence&gt;
 *                                       &lt;element name="IdPoliza" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
 *                                       &lt;element name="NumeroSuplemento" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
 *                                       &lt;element name="IdMediador" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/&gt;
 *                                       &lt;element name="ProductoDGS" type="{http://www.w3.org/2001/XMLSchema}unsignedShort"/&gt;
 *                                     &lt;/sequence&gt;
 *                                   &lt;/restriction&gt;
 *                                 &lt;/complexContent&gt;
 *                               &lt;/complexType&gt;
 *                             &lt;/element&gt;
 *                             &lt;element name="DatosRecibo"&gt;
 *                               &lt;complexType&gt;
 *                                 &lt;complexContent&gt;
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                     &lt;sequence&gt;
 *                                       &lt;element name="IdRecibo" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
 *                                       &lt;element name="SituacionRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                       &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                       &lt;element name="FraccionPago" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                       &lt;element name="Fechas"&gt;
 *                                         &lt;complexType&gt;
 *                                           &lt;complexContent&gt;
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                               &lt;sequence&gt;
 *                                                 &lt;element name="FechaSituacion" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *                                                 &lt;element name="FechaEfectoActual" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *                                                 &lt;element name="FechaVencimiento" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *                                                 &lt;element name="FechaEmision" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *                                               &lt;/sequence&gt;
 *                                             &lt;/restriction&gt;
 *                                           &lt;/complexContent&gt;
 *                                         &lt;/complexType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="GestionCobro"&gt;
 *                                         &lt;complexType&gt;
 *                                           &lt;complexContent&gt;
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                               &lt;sequence&gt;
 *                                                 &lt;element name="IBAN" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                               &lt;/sequence&gt;
 *                                             &lt;/restriction&gt;
 *                                           &lt;/complexContent&gt;
 *                                         &lt;/complexType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="DatosImportes"&gt;
 *                                         &lt;complexType&gt;
 *                                           &lt;complexContent&gt;
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                               &lt;sequence&gt;
 *                                                 &lt;element name="Importes"&gt;
 *                                                   &lt;complexType&gt;
 *                                                     &lt;complexContent&gt;
 *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                         &lt;sequence&gt;
 *                                                           &lt;element name="PrimaTotal" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *                                                           &lt;element name="PrimaNeta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *                                                           &lt;element name="DatosCargos"&gt;
 *                                                             &lt;complexType&gt;
 *                                                               &lt;complexContent&gt;
 *                                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                   &lt;sequence&gt;
 *                                                                     &lt;element name="Cargo"&gt;
 *                                                                       &lt;complexType&gt;
 *                                                                         &lt;complexContent&gt;
 *                                                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                             &lt;sequence&gt;
 *                                                                               &lt;element name="ClaseCargo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                                                               &lt;element name="Importe" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *                                                                             &lt;/sequence&gt;
 *                                                                           &lt;/restriction&gt;
 *                                                                         &lt;/complexContent&gt;
 *                                                                       &lt;/complexType&gt;
 *                                                                     &lt;/element&gt;
 *                                                                   &lt;/sequence&gt;
 *                                                                 &lt;/restriction&gt;
 *                                                               &lt;/complexContent&gt;
 *                                                             &lt;/complexType&gt;
 *                                                           &lt;/element&gt;
 *                                                         &lt;/sequence&gt;
 *                                                       &lt;/restriction&gt;
 *                                                     &lt;/complexContent&gt;
 *                                                   &lt;/complexType&gt;
 *                                                 &lt;/element&gt;
 *                                               &lt;/sequence&gt;
 *                                             &lt;/restriction&gt;
 *                                           &lt;/complexContent&gt;
 *                                         &lt;/complexType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="DatosComisiones"&gt;
 *                                         &lt;complexType&gt;
 *                                           &lt;complexContent&gt;
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                               &lt;sequence&gt;
 *                                                 &lt;element name="Comision"&gt;
 *                                                   &lt;complexType&gt;
 *                                                     &lt;complexContent&gt;
 *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                         &lt;sequence&gt;
 *                                                           &lt;element name="NumeroOrden" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
 *                                                           &lt;element name="ClaseComision" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                                           &lt;element name="ComisionBruta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *                                                           &lt;element name="ComisionLiquida" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *                                                         &lt;/sequence&gt;
 *                                                       &lt;/restriction&gt;
 *                                                     &lt;/complexContent&gt;
 *                                                   &lt;/complexType&gt;
 *                                                 &lt;/element&gt;
 *                                               &lt;/sequence&gt;
 *                                             &lt;/restriction&gt;
 *                                           &lt;/complexContent&gt;
 *                                         &lt;/complexType&gt;
 *                                       &lt;/element&gt;
 *                                     &lt;/sequence&gt;
 *                                   &lt;/restriction&gt;
 *                                 &lt;/complexContent&gt;
 *                               &lt;/complexType&gt;
 *                             &lt;/element&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cabecera",
    "objetos"
})
@XmlRootElement(name = "ProcesosEIAC")
public class ProcesosEIAC {
	
    @XmlElement(name = "Cabecera", required = true)
    protected ProcesosEIAC.Cabecera cabecera;
    @XmlElement(name = "Objetos", required = true)
    protected ProcesosEIAC.Objetos objetos;

    /**
     * Obtiene el valor de la propiedad cabecera.
     * 
     * @return
     *     possible object is
     *     {@link ProcesosEIAC.Cabecera }
     *     
     */
    public ProcesosEIAC.Cabecera getCabecera() {
        return cabecera;
    }

    /**
     * Define el valor de la propiedad cabecera.
     * 
     * @param value
     *     allowed object is
     *     {@link ProcesosEIAC.Cabecera }
     *     
     */
    public void setCabecera(ProcesosEIAC.Cabecera value) {
        this.cabecera = value;
    }

    /**
     * Obtiene el valor de la propiedad objetos.
     * 
     * @return
     *     possible object is
     *     {@link ProcesosEIAC.Objetos }
     *     
     */
    public ProcesosEIAC.Objetos getObjetos() {
        return objetos;
    }

    /**
     * Define el valor de la propiedad objetos.
     * 
     * @param value
     *     allowed object is
     *     {@link ProcesosEIAC.Objetos }
     *     
     */
    public void setObjetos(ProcesosEIAC.Objetos value) {
        this.objetos = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="FechaCreacion" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
     *         &lt;element name="Emisor"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="CodigoInterno" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                   &lt;element name="CodigoDGS" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="Receptor"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="CodigoInterno" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/&gt;
     *                   &lt;element name="CodigoDGS" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="DatosProcesos"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="DetalleProcesos"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="DetalleProceso" maxOccurs="unbounded"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                                       &lt;element name="Transaccion" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                                       &lt;element name="Periodo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                                       &lt;element name="FechaDesde" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
     *                                       &lt;element name="FechaHasta" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="DatosLote"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="IdLote" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
     *                   &lt;element name="NumeroFicheros" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
     *                   &lt;element name="SecuenciaFichero" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "fechaCreacion",
        "emisor",
        "receptor",
        "datosProcesos",
        "datosLote",
        "version"
    })
    @XmlRootElement
    public static class Cabecera {
    
        @XmlElement(name = "FechaCreacion", required = true)
        @XmlSchemaType(name = "date")
        protected XMLGregorianCalendar fechaCreacion;
        @XmlElement(name = "Emisor", required = true)
        protected ProcesosEIAC.Cabecera.Emisor emisor;
        @XmlElement(name = "Receptor", required = true)
        protected ProcesosEIAC.Cabecera.Receptor receptor;
        @XmlElement(name = "DatosProcesos", required = true)
        protected ProcesosEIAC.Cabecera.DatosProcesos datosProcesos;
        @XmlElement(name = "DatosLote", required = true)
        protected ProcesosEIAC.Cabecera.DatosLote datosLote;
        @XmlElement(name = "Version", required = true)
        protected BigDecimal version;

        /**
         * Obtiene el valor de la propiedad fechaCreacion.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getFechaCreacion() {
            return fechaCreacion;
        }

        /**
         * Define el valor de la propiedad fechaCreacion.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setFechaCreacion(XMLGregorianCalendar value) {
            this.fechaCreacion = value;
        }

        /**
         * Obtiene el valor de la propiedad emisor.
         * 
         * @return
         *     possible object is
         *     {@link ProcesosEIAC.Cabecera.Emisor }
         *     
         */
        public ProcesosEIAC.Cabecera.Emisor getEmisor() {
            return emisor;
        }

        /**
         * Define el valor de la propiedad emisor.
         * 
         * @param value
         *     allowed object is
         *     {@link ProcesosEIAC.Cabecera.Emisor }
         *     
         */
        public void setEmisor(ProcesosEIAC.Cabecera.Emisor value) {
            this.emisor = value;
        }

        /**
         * Obtiene el valor de la propiedad receptor.
         * 
         * @return
         *     possible object is
         *     {@link ProcesosEIAC.Cabecera.Receptor }
         *     
         */
        public ProcesosEIAC.Cabecera.Receptor getReceptor() {
            return receptor;
        }

        /**
         * Define el valor de la propiedad receptor.
         * 
         * @param value
         *     allowed object is
         *     {@link ProcesosEIAC.Cabecera.Receptor }
         *     
         */
        public void setReceptor(ProcesosEIAC.Cabecera.Receptor value) {
            this.receptor = value;
        }

        /**
         * Obtiene el valor de la propiedad datosProcesos.
         * 
         * @return
         *     possible object is
         *     {@link ProcesosEIAC.Cabecera.DatosProcesos }
         *     
         */
        public ProcesosEIAC.Cabecera.DatosProcesos getDatosProcesos() {
            return datosProcesos;
        }

        /**
         * Define el valor de la propiedad datosProcesos.
         * 
         * @param value
         *     allowed object is
         *     {@link ProcesosEIAC.Cabecera.DatosProcesos }
         *     
         */
        public void setDatosProcesos(ProcesosEIAC.Cabecera.DatosProcesos value) {
            this.datosProcesos = value;
        }

        /**
         * Obtiene el valor de la propiedad datosLote.
         * 
         * @return
         *     possible object is
         *     {@link ProcesosEIAC.Cabecera.DatosLote }
         *     
         */
        public ProcesosEIAC.Cabecera.DatosLote getDatosLote() {
            return datosLote;
        }

        /**
         * Define el valor de la propiedad datosLote.
         * 
         * @param value
         *     allowed object is
         *     {@link ProcesosEIAC.Cabecera.DatosLote }
         *     
         */
        public void setDatosLote(ProcesosEIAC.Cabecera.DatosLote value) {
            this.datosLote = value;
        }

        /**
         * Obtiene el valor de la propiedad version.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getVersion() {
            return version;
        }

        /**
         * Define el valor de la propiedad version.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setVersion(BigDecimal value) {
            this.version = value;
        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="IdLote" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
         *         &lt;element name="NumeroFicheros" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
         *         &lt;element name="SecuenciaFichero" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "idLote",
            "numeroFicheros",
            "secuenciaFichero"
        })
        public static class DatosLote {

            @XmlElement(name = "IdLote", required = true)
            @XmlSchemaType(name = "unsignedLong")
            protected BigInteger idLote;
            @XmlElement(name = "NumeroFicheros")
            @XmlSchemaType(name = "unsignedByte")
            protected short numeroFicheros;
            @XmlElement(name = "SecuenciaFichero")
            @XmlSchemaType(name = "unsignedByte")
            protected short secuenciaFichero;

            /**
             * Obtiene el valor de la propiedad idLote.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getIdLote() {
                return idLote;
            }

            /**
             * Define el valor de la propiedad idLote.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setIdLote(BigInteger value) {
                this.idLote = value;
            }

            /**
             * Obtiene el valor de la propiedad numeroFicheros.
             * 
             */
            public short getNumeroFicheros() {
                return numeroFicheros;
            }

            /**
             * Define el valor de la propiedad numeroFicheros.
             * 
             */
            public void setNumeroFicheros(short value) {
                this.numeroFicheros = value;
            }

            /**
             * Obtiene el valor de la propiedad secuenciaFichero.
             * 
             */
            public short getSecuenciaFichero() {
                return secuenciaFichero;
            }

            /**
             * Define el valor de la propiedad secuenciaFichero.
             * 
             */
            public void setSecuenciaFichero(short value) {
                this.secuenciaFichero = value;
            }

        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="DetalleProcesos"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="DetalleProceso" maxOccurs="unbounded"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                             &lt;element name="Transaccion" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                             &lt;element name="Periodo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                             &lt;element name="FechaDesde" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
         *                             &lt;element name="FechaHasta" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "detalleProcesos"
        })
        public static class DatosProcesos {

            @XmlElement(name = "DetalleProcesos", required = true)
            protected ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos detalleProcesos;

            /**
             * Obtiene el valor de la propiedad detalleProcesos.
             * 
             * @return
             *     possible object is
             *     {@link ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos }
             *     
             */
            public ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos getDetalleProcesos() {
                return detalleProcesos;
            }

            /**
             * Define el valor de la propiedad detalleProcesos.
             * 
             * @param value
             *     allowed object is
             *     {@link ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos }
             *     
             */
            public void setDetalleProcesos(ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos value) {
                this.detalleProcesos = value;
            }


            /**
             * <p>Clase Java para anonymous complex type.
             * 
             * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="DetalleProceso" maxOccurs="unbounded"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *                   &lt;element name="Transaccion" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *                   &lt;element name="Periodo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *                   &lt;element name="FechaDesde" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
             *                   &lt;element name="FechaHasta" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "detalleProceso"
            })
            public static class DetalleProcesos {

                @XmlElement(name = "DetalleProceso", required = true)
                protected List<ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos.DetalleProceso> detalleProceso;

                /**
                 * Gets the value of the detalleProceso property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the detalleProceso property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getDetalleProceso().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos.DetalleProceso }
                 * 
                 * 
                 */
                public List<ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos.DetalleProceso> getDetalleProceso() {
                    if (detalleProceso == null) {
                        detalleProceso = new ArrayList<ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos.DetalleProceso>();
                    }
                    return this.detalleProceso;
                }


                /**
                 * <p>Clase Java para anonymous complex type.
                 * 
                 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
                 *         &lt;element name="Transaccion" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
                 *         &lt;element name="Periodo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
                 *         &lt;element name="FechaDesde" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
                 *         &lt;element name="FechaHasta" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "claseRecibo",
                    "transaccion",
                    "periodo",
                    "fechaDesde",
                    "fechaHasta"
                })
                public static class DetalleProceso {

                    @XmlElement(name = "ClaseRecibo", required = true)
                    protected String claseRecibo;
                    @XmlElement(name = "Transaccion", required = true)
                    protected String transaccion;
                    @XmlElement(name = "Periodo", required = true)
                    protected String periodo;
                    @XmlElement(name = "FechaDesde", required = true)
                    @XmlSchemaType(name = "date")
                    protected XMLGregorianCalendar fechaDesde;
                    @XmlElement(name = "FechaHasta", required = true)
                    @XmlSchemaType(name = "date")
                    protected XMLGregorianCalendar fechaHasta;

                    /**
                     * Obtiene el valor de la propiedad claseRecibo.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getClaseRecibo() {
                        return claseRecibo;
                    }

                    /**
                     * Define el valor de la propiedad claseRecibo.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setClaseRecibo(String value) {
                        this.claseRecibo = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad transaccion.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getTransaccion() {
                        return transaccion;
                    }

                    /**
                     * Define el valor de la propiedad transaccion.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setTransaccion(String value) {
                        this.transaccion = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad periodo.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getPeriodo() {
                        return periodo;
                    }

                    /**
                     * Define el valor de la propiedad periodo.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setPeriodo(String value) {
                        this.periodo = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad fechaDesde.
                     * 
                     * @return
                     *     possible object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public XMLGregorianCalendar getFechaDesde() {
                        return fechaDesde;
                    }

                    /**
                     * Define el valor de la propiedad fechaDesde.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public void setFechaDesde(XMLGregorianCalendar value) {
                        this.fechaDesde = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad fechaHasta.
                     * 
                     * @return
                     *     possible object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public XMLGregorianCalendar getFechaHasta() {
                        return fechaHasta;
                    }

                    /**
                     * Define el valor de la propiedad fechaHasta.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public void setFechaHasta(XMLGregorianCalendar value) {
                        this.fechaHasta = value;
                    }

                }

            }

        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="CodigoInterno" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *         &lt;element name="CodigoDGS" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "codigoInterno",
            "codigoDGS"
        })
        public static class Emisor {

            @XmlElement(name = "CodigoInterno", required = true)
            protected String codigoInterno;
            @XmlElement(name = "CodigoDGS", required = true)
            protected String codigoDGS;

            /**
             * Obtiene el valor de la propiedad codigoInterno.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCodigoInterno() {
                return codigoInterno;
            }

            /**
             * Define el valor de la propiedad codigoInterno.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCodigoInterno(String value) {
                this.codigoInterno = value;
            }

            /**
             * Obtiene el valor de la propiedad codigoDGS.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCodigoDGS() {
                return codigoDGS;
            }

            /**
             * Define el valor de la propiedad codigoDGS.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCodigoDGS(String value) {
                this.codigoDGS = value;
            }

        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="CodigoInterno" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/&gt;
         *         &lt;element name="CodigoDGS" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "codigoInterno",
            "codigoDGS"
        })
        public static class Receptor {

            @XmlElement(name = "CodigoInterno")
            @XmlSchemaType(name = "unsignedInt")
            protected String codigoInterno;
            @XmlElement(name = "CodigoDGS", required = true)
            protected String codigoDGS;

            /**
             * Obtiene el valor de la propiedad codigoInterno.
             * 
             */
            public String getCodigoInterno() {
                return codigoInterno;
            }

            /**
             * Define el valor de la propiedad codigoInterno.
             * 
             */
            public void setCodigoInterno(String value) {
                this.codigoInterno = value;
            }

            /**
             * Obtiene el valor de la propiedad codigoDGS.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCodigoDGS() {
                return codigoDGS;
            }

            /**
             * Define el valor de la propiedad codigoDGS.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCodigoDGS(String value) {
                this.codigoDGS = value;
            }

        }

    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Recibo" maxOccurs="unbounded"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="DatosPoliza"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="IdPoliza" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
     *                             &lt;element name="NumeroSuplemento" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
     *                             &lt;element name="IdMediador" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/&gt;
     *                             &lt;element name="ProductoDGS" type="{http://www.w3.org/2001/XMLSchema}unsignedShort"/&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="DatosRecibo"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="IdRecibo" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
     *                             &lt;element name="SituacionRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                             &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                             &lt;element name="FraccionPago" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                             &lt;element name="Fechas"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="FechaSituacion" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
     *                                       &lt;element name="FechaEfectoActual" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
     *                                       &lt;element name="FechaVencimiento" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
     *                                       &lt;element name="FechaEmision" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
 *                                       &lt;element name="GestionCobro"&gt;
 *                                         &lt;complexType&gt;
 *                                           &lt;complexContent&gt;
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                               &lt;sequence&gt;
 *                                                 &lt;element name="IBAN" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                               &lt;/sequence&gt;
 *                                             &lt;/restriction&gt;
 *                                           &lt;/complexContent&gt;
 *                                         &lt;/complexType&gt;
 *                                       &lt;/element&gt;                            
     *                             &lt;element name="DatosImportes"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="Importes"&gt;
     *                                         &lt;complexType&gt;
     *                                           &lt;complexContent&gt;
     *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                               &lt;sequence&gt;
     *                                                 &lt;element name="PrimaTotal" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
     *                                                 &lt;element name="PrimaNeta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
     *                                                 &lt;element name="DatosCargos"&gt;
     *                                                   &lt;complexType&gt;
     *                                                     &lt;complexContent&gt;
     *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                         &lt;sequence&gt;
     *                                                           &lt;element name="Cargo"&gt;
     *                                                             &lt;complexType&gt;
     *                                                               &lt;complexContent&gt;
     *                                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                                   &lt;sequence&gt;
     *                                                                     &lt;element name="ClaseCargo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                                                                     &lt;element name="Importe" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
     *                                                                   &lt;/sequence&gt;
     *                                                                 &lt;/restriction&gt;
     *                                                               &lt;/complexContent&gt;
     *                                                             &lt;/complexType&gt;
     *                                                           &lt;/element&gt;
     *                                                         &lt;/sequence&gt;
     *                                                       &lt;/restriction&gt;
     *                                                     &lt;/complexContent&gt;
     *                                                   &lt;/complexType&gt;
     *                                                 &lt;/element&gt;
     *                                               &lt;/sequence&gt;
     *                                             &lt;/restriction&gt;
     *                                           &lt;/complexContent&gt;
     *                                         &lt;/complexType&gt;
     *                                       &lt;/element&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="DatosComisiones"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="Comision"&gt;
     *                                         &lt;complexType&gt;
     *                                           &lt;complexContent&gt;
     *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                               &lt;sequence&gt;
     *                                                 &lt;element name="NumeroOrden" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
     *                                                 &lt;element name="ClaseComision" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                                                 &lt;element name="ComisionBruta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
     *                                                 &lt;element name="ComisionLiquida" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
     *                                               &lt;/sequence&gt;
     *                                             &lt;/restriction&gt;
     *                                           &lt;/complexContent&gt;
     *                                         &lt;/complexType&gt;
     *                                       &lt;/element&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "recibo"
    })
    public static class Objetos {

        @XmlElement(name = "Recibo", required = true)
        protected List<ProcesosEIAC.Objetos.Recibo> recibo;

        /**
         * Gets the value of the recibo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the recibo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRecibo().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link ProcesosEIAC.Objetos.Recibo }
         * 
         * 
         */
        public List<ProcesosEIAC.Objetos.Recibo> getRecibo() {
            if (recibo == null) {
                recibo = new ArrayList<ProcesosEIAC.Objetos.Recibo>();
            }
            return this.recibo;
        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="DatosPoliza"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="IdPoliza" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
         *                   &lt;element name="NumeroSuplemento" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
         *                   &lt;element name="IdMediador" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/&gt;
         *                   &lt;element name="ProductoDGS" type="{http://www.w3.org/2001/XMLSchema}unsignedShort"/&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="DatosRecibo"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="IdRecibo" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
         *                   &lt;element name="SituacionRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                   &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                   &lt;element name="FraccionPago" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                   &lt;element name="Fechas"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="FechaSituacion" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
         *                             &lt;element name="FechaEfectoActual" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
         *                             &lt;element name="FechaVencimiento" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
         *                             &lt;element name="FechaEmision" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                   
         *                   &lt;element name="GestionCobro"&gt;
 *                                         &lt;complexType&gt;
 *                                           &lt;complexContent&gt;
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                               &lt;sequence&gt;
 *                                                 &lt;element name="IBAN" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                               &lt;/sequence&gt;
 *                                             &lt;/restriction&gt;
 *                                           &lt;/complexContent&gt;
 *                                         &lt;/complexType&gt;
 *                                       &lt;/element&gt;

         *                   &lt;element name="DatosImportes"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="Importes"&gt;
         *                               &lt;complexType&gt;
         *                                 &lt;complexContent&gt;
         *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                     &lt;sequence&gt;
         *                                       &lt;element name="PrimaTotal" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
         *                                       &lt;element name="PrimaNeta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
         *                                       &lt;element name="DatosCargos"&gt;
         *                                         &lt;complexType&gt;
         *                                           &lt;complexContent&gt;
         *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                               &lt;sequence&gt;
         *                                                 &lt;element name="Cargo"&gt;
         *                                                   &lt;complexType&gt;
         *                                                     &lt;complexContent&gt;
         *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                                         &lt;sequence&gt;
         *                                                           &lt;element name="ClaseCargo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                                                           &lt;element name="Importe" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
         *                                                         &lt;/sequence&gt;
         *                                                       &lt;/restriction&gt;
         *                                                     &lt;/complexContent&gt;
         *                                                   &lt;/complexType&gt;
         *                                                 &lt;/element&gt;
         *                                               &lt;/sequence&gt;
         *                                             &lt;/restriction&gt;
         *                                           &lt;/complexContent&gt;
         *                                         &lt;/complexType&gt;
         *                                       &lt;/element&gt;
         *                                     &lt;/sequence&gt;
         *                                   &lt;/restriction&gt;
         *                                 &lt;/complexContent&gt;
         *                               &lt;/complexType&gt;
         *                             &lt;/element&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="DatosComisiones"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="Comision"&gt;
         *                               &lt;complexType&gt;
         *                                 &lt;complexContent&gt;
         *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                     &lt;sequence&gt;
         *                                       &lt;element name="NumeroOrden" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
         *                                       &lt;element name="ClaseComision" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                                       &lt;element name="ComisionBruta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
         *                                       &lt;element name="ComisionLiquida" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
         *                                     &lt;/sequence&gt;
         *                                   &lt;/restriction&gt;
         *                                 &lt;/complexContent&gt;
         *                               &lt;/complexType&gt;
         *                             &lt;/element&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "datosPoliza",
            "datosRecibo"
        })
        public static class Recibo {

            @XmlElement(name = "DatosPoliza", required = true)
            protected ProcesosEIAC.Objetos.Recibo.DatosPoliza datosPoliza;
            @XmlElement(name = "DatosRecibo", required = true)
            protected ProcesosEIAC.Objetos.Recibo.DatosRecibo datosRecibo;

            /**
             * Obtiene el valor de la propiedad datosPoliza.
             * 
             * @return
             *     possible object is
             *     {@link ProcesosEIAC.Objetos.Recibo.DatosPoliza }
             *     
             */
            public ProcesosEIAC.Objetos.Recibo.DatosPoliza getDatosPoliza() {
                return datosPoliza;
            }

            /**
             * Define el valor de la propiedad datosPoliza.
             * 
             * @param value
             *     allowed object is
             *     {@link ProcesosEIAC.Objetos.Recibo.DatosPoliza }
             *     
             */
            public void setDatosPoliza(ProcesosEIAC.Objetos.Recibo.DatosPoliza value) {
                this.datosPoliza = value;
            }

            /**
             * Obtiene el valor de la propiedad datosRecibo.
             * 
             * @return
             *     possible object is
             *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo }
             *     
             */
            public ProcesosEIAC.Objetos.Recibo.DatosRecibo getDatosRecibo() {
                return datosRecibo;
            }

            /**
             * Define el valor de la propiedad datosRecibo.
             * 
             * @param value
             *     allowed object is
             *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo }
             *     
             */
            public void setDatosRecibo(ProcesosEIAC.Objetos.Recibo.DatosRecibo value) {
                this.datosRecibo = value;
            }


            /**
             * <p>Clase Java para anonymous complex type.
             * 
             * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="IdPoliza" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
             *         &lt;element name="NumeroSuplemento" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
             *         &lt;element name="IdMediador" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/&gt;
             *         &lt;element name="ProductoDGS" type="{http://www.w3.org/2001/XMLSchema}unsignedShort"/&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "idPoliza",
                "numeroSuplemento",
                "idMediador",
                "productoDGS"
            })
            public static class DatosPoliza {

                @XmlElement(name = "IdPoliza", required = true)
                @XmlSchemaType(name = "unsignedLong")
                protected String idPoliza;
                @XmlElement(name = "NumeroSuplemento")
                @XmlSchemaType(name = "unsignedByte")
                protected Integer numeroSuplemento;
                @XmlElement(name = "IdMediador")
                @XmlSchemaType(name = "unsignedInt")
                protected String idMediador;
                @XmlElement(name = "ProductoDGS")
                @XmlSchemaType(name = "unsignedShort")
                protected String productoDGS;

                /**
                 * Obtiene el valor de la propiedad idPoliza.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public String getIdPoliza() {
                    return idPoliza;
                }

                /**
                 * Define el valor de la propiedad idPoliza.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setIdPoliza(String value) {
                    this.idPoliza = value;
                }

                /**
                 * Obtiene el valor de la propiedad numeroSuplemento.
                 * 
                 */
                public Integer getNumeroSuplemento() {
                    return numeroSuplemento;
                }

                /**
                 * Define el valor de la propiedad numeroSuplemento.
                 * 
                 */
                public void setNumeroSuplemento(Integer value) {
                    this.numeroSuplemento = value;
                }

                /**
                 * Obtiene el valor de la propiedad idMediador.
                 * 
                 */
                public String getIdMediador() {
                    return idMediador;
                }

                /**
                 * Define el valor de la propiedad idMediador.
                 * 
                 */
                public void setIdMediador(String value) {
                    this.idMediador = value;
                }

                /**
                 * Obtiene el valor de la propiedad productoDGS.
                 * 
                 */
                public String getProductoDGS() {
                    return productoDGS;
                }

                /**
                 * Define el valor de la propiedad productoDGS.
                 * 
                 */
                public void setProductoDGS(String value) {
                    this.productoDGS = value;
                }

            }


            /**
             * <p>Clase Java para anonymous complex type.
             * 
             * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="IdRecibo" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
             *         &lt;element name="SituacionRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *         &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *         &lt;element name="FraccionPago" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *         &lt;element name="Fechas"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="FechaSituacion" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
             *                   &lt;element name="FechaEfectoActual" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
             *                   &lt;element name="FechaVencimiento" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
             *                   &lt;element name="FechaEmision" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *        &lt;element name="GestionCobro"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="IBAN" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="DatosImportes"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="Importes"&gt;
             *                     &lt;complexType&gt;
             *                       &lt;complexContent&gt;
             *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                           &lt;sequence&gt;
             *                             &lt;element name="PrimaTotal" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
             *                             &lt;element name="PrimaNeta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
             *                             &lt;element name="DatosCargos"&gt;
             *                               &lt;complexType&gt;
             *                                 &lt;complexContent&gt;
             *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                     &lt;sequence&gt;
             *                                       &lt;element name="Cargo"&gt;
             *                                         &lt;complexType&gt;
             *                                           &lt;complexContent&gt;
             *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                               &lt;sequence&gt;
             *                                                 &lt;element name="ClaseCargo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *                                                 &lt;element name="Importe" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
             *                                               &lt;/sequence&gt;
             *                                             &lt;/restriction&gt;
             *                                           &lt;/complexContent&gt;
             *                                         &lt;/complexType&gt;
             *                                       &lt;/element&gt;
             *                                     &lt;/sequence&gt;
             *                                   &lt;/restriction&gt;
             *                                 &lt;/complexContent&gt;
             *                               &lt;/complexType&gt;
             *                             &lt;/element&gt;
             *                           &lt;/sequence&gt;
             *                         &lt;/restriction&gt;
             *                       &lt;/complexContent&gt;
             *                     &lt;/complexType&gt;
             *                   &lt;/element&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="DatosComisiones"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="Comision"&gt;
             *                     &lt;complexType&gt;
             *                       &lt;complexContent&gt;
             *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                           &lt;sequence&gt;
             *                             &lt;element name="NumeroOrden" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
             *                             &lt;element name="ClaseComision" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *                             &lt;element name="ComisionBruta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
             *                             &lt;element name="ComisionLiquida" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
             *                           &lt;/sequence&gt;
             *                         &lt;/restriction&gt;
             *                       &lt;/complexContent&gt;
             *                     &lt;/complexType&gt;
             *                   &lt;/element&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "idRecibo",
                "situacionRecibo",
                "claseRecibo",
                "fraccionPago",
                "fechas",
                "gestionCobro",
                "datosImportes",
                "datosComisiones"
            })
            public static class DatosRecibo {

                @XmlElement(name = "IdRecibo", required = true)
                @XmlSchemaType(name = "unsignedLong")
                protected String idRecibo;
                @XmlElement(name = "SituacionRecibo", required = true)
                protected String situacionRecibo;
                @XmlElement(name = "ClaseRecibo", required = true)
                protected String claseRecibo;
                @XmlElement(name = "FraccionPago", required = true)
                protected String fraccionPago;
                @XmlElement(name = "Fechas", required = true)
                protected ProcesosEIAC.Objetos.Recibo.DatosRecibo.Fechas fechas;
                @XmlElement(name = "GestionCobro", required = true)
                protected ProcesosEIAC.Objetos.Recibo.DatosRecibo.GestionCobro gestionCobro;
				@XmlElement(name = "DatosImportes", required = true)
                protected ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes datosImportes;
                @XmlElement(name = "DatosComisiones", required = true)
                protected ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones datosComisiones;

                
                /**
                 * Obtiene el valor de la propiedad gestionCobro.
                 * 
                 * @return
                 *     possible object is
                 *     {@link  ProcesosEIAC.Objetos.Recibo.DatosRecibo.GestionCobro }
                 *     
                 */
               
                public ProcesosEIAC.Objetos.Recibo.DatosRecibo.GestionCobro getGestionCobro() {
					return gestionCobro;
				}
                /**
                 * Obtiene el valor de la propiedad idRecibo.
                 * 
                 * @return
                 *     possible object is
                 *     {@link void }
                 *     
                 */
             
				public void setGestionCobro(ProcesosEIAC.Objetos.Recibo.DatosRecibo.GestionCobro gestionCobro) {
					this.gestionCobro = gestionCobro;
				}
                /**
                 * Obtiene el valor de la propiedad idRecibo.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public String getIdRecibo() {
                    return idRecibo;
                }

                /**
                 * Define el valor de la propiedad idRecibo.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setIdRecibo(String value) {
                    this.idRecibo = value;
                }

                /**
                 * Obtiene el valor de la propiedad situacionRecibo.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getSituacionRecibo() {
                    return situacionRecibo;
                }

                /**
                 * Define el valor de la propiedad situacionRecibo.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setSituacionRecibo(String value) {
                    this.situacionRecibo = value;
                }

                /**
                 * Obtiene el valor de la propiedad claseRecibo.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getClaseRecibo() {
                    return claseRecibo;
                }

                /**
                 * Define el valor de la propiedad claseRecibo.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setClaseRecibo(String value) {
                    this.claseRecibo = value;
                }

                /**
                 * Obtiene el valor de la propiedad fraccionPago.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getFraccionPago() {
                    return fraccionPago;
                }

                /**
                 * Define el valor de la propiedad fraccionPago.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setFraccionPago(String value) {
                    this.fraccionPago = value;
                }

                /**
                 * Obtiene el valor de la propiedad fechas.
                 * 
                 * @return
                 *     possible object is
                 *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.Fechas }
                 *     
                 */
                public ProcesosEIAC.Objetos.Recibo.DatosRecibo.Fechas getFechas() {
                    return fechas;
                }

                /**
                 * Define el valor de la propiedad fechas.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.Fechas }
                 *     
                 */
                public void setFechas(ProcesosEIAC.Objetos.Recibo.DatosRecibo.Fechas value) {
                    this.fechas = value;
                }

                /**
                 * Obtiene el valor de la propiedad datosImportes.
                 * 
                 * @return
                 *     possible object is
                 *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes }
                 *     
                 */
                public ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes getDatosImportes() {
                    return datosImportes;
                }

                /**
                 * Define el valor de la propiedad datosImportes.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes }
                 *     
                 */
                public void setDatosImportes(ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes value) {
                    this.datosImportes = value;
                }

                /**
                 * Obtiene el valor de la propiedad datosComisiones.
                 * 
                 * @return
                 *     possible object is
                 *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones }
                 *     
                 */
                public ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones getDatosComisiones() {
                    return datosComisiones;
                }

                /**
                 * Define el valor de la propiedad datosComisiones.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones }
                 *     
                 */
                public void setDatosComisiones(ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones value) {
                    this.datosComisiones = value;
                }


                /**
                 * <p>Clase Java para anonymous complex type.
                 * 
                 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="Comision"&gt;
                 *           &lt;complexType&gt;
                 *             &lt;complexContent&gt;
                 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                 &lt;sequence&gt;
                 *                   &lt;element name="NumeroOrden" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
                 *                   &lt;element name="ClaseComision" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
                 *                   &lt;element name="ComisionBruta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
                 *                   &lt;element name="ComisionLiquida" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
                 *                 &lt;/sequence&gt;
                 *               &lt;/restriction&gt;
                 *             &lt;/complexContent&gt;
                 *           &lt;/complexType&gt;
                 *         &lt;/element&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "comision"
                })
                public static class DatosComisiones {

                    @XmlElement(name = "Comision", required = true)
                    protected ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones.Comision comision;

                    /**
                     * Obtiene el valor de la propiedad comision.
                     * 
                     * @return
                     *     possible object is
                     *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones.Comision }
                     *     
                     */
                    public ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones.Comision getComision() {
                        return comision;
                    }

                    /**
                     * Define el valor de la propiedad comision.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones.Comision }
                     *     
                     */
                    public void setComision(ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones.Comision value) {
                        this.comision = value;
                    }


                    /**
                     * <p>Clase Java para anonymous complex type.
                     * 
                     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
                     * 
                     * <pre>
                     * &lt;complexType&gt;
                     *   &lt;complexContent&gt;
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *       &lt;sequence&gt;
                     *         &lt;element name="NumeroOrden" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
                     *         &lt;element name="ClaseComision" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
                     *         &lt;element name="ComisionBruta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
                     *         &lt;element name="ComisionLiquida" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
                     *       &lt;/sequence&gt;
                     *     &lt;/restriction&gt;
                     *   &lt;/complexContent&gt;
                     * &lt;/complexType&gt;
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "numeroOrden",
                        "claseComision",
                        "comisionBruta",
                        "comisionLiquida"
                    })
                    public static class Comision {

                        @XmlElement(name = "NumeroOrden")
                        @XmlSchemaType(name = "unsignedByte")
                        protected short numeroOrden;
                        @XmlElement(name = "ClaseComision", required = true)
                        protected String claseComision;
                        @XmlElement(name = "ComisionBruta", required = true)
                        protected BigDecimal comisionBruta;
                        @XmlElement(name = "ComisionLiquida", required = true)
                        protected BigDecimal comisionLiquida;

                        /**
                         * Obtiene el valor de la propiedad numeroOrden.
                         * 
                         */
                        public short getNumeroOrden() {
                            return numeroOrden;
                        }

	                        /**
	                         * Define el valor de la propiedad numeroOrden.
	                         * 
	                         */
                        public void setNumeroOrden(short value) {
                            this.numeroOrden = value;
                        }

                        /**
                         * Obtiene el valor de la propiedad claseComision.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getClaseComision() {
                            return claseComision;
                        }

                        /**
                         * Define el valor de la propiedad claseComision.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setClaseComision(String value) {
                            this.claseComision = value;
                        }

                        /**
                         * Obtiene el valor de la propiedad comisionBruta.
                         * 
                         * @return
                         *     possible object is
                         *     {@link BigDecimal }
                         *     
                         */
                        public BigDecimal getComisionBruta() {
                            return comisionBruta;
                        }

                        /**
                         * Define el valor de la propiedad comisionBruta.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link BigDecimal }
                         *     
                         */
                        public void setComisionBruta(BigDecimal value) {
                            this.comisionBruta = value;
                        }

                        /**
                         * Obtiene el valor de la propiedad comisionLiquida.
                         * 
                         * @return
                         *     possible object is
                         *     {@link BigDecimal }
                         *     
                         */
                        public BigDecimal getComisionLiquida() {
                            return comisionLiquida;
                        }

                        /**
                         * Define el valor de la propiedad comisionLiquida.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link BigDecimal }
                         *     
                         */
                        public void setComisionLiquida(BigDecimal value) {
                            this.comisionLiquida = value;
                        }

                    }

                }


                /**
                 * <p>Clase Java para anonymous complex type.
                 * 
                 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="Importes"&gt;
                 *           &lt;complexType&gt;
                 *             &lt;complexContent&gt;
                 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                 &lt;sequence&gt;
                 *                   &lt;element name="PrimaTotal" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
                 *                   &lt;element name="PrimaNeta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
                 *                   &lt;element name="DatosCargos"&gt;
                 *                     &lt;complexType&gt;
                 *                       &lt;complexContent&gt;
                 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                           &lt;sequence&gt;
                 *                             &lt;element name="Cargo"&gt;
                 *                               &lt;complexType&gt;
                 *                                 &lt;complexContent&gt;
                 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                                     &lt;sequence&gt;
                 *                                       &lt;element name="ClaseCargo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
                 *                                       &lt;element name="Importe" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
                 *                                     &lt;/sequence&gt;
                 *                                   &lt;/restriction&gt;
                 *                                 &lt;/complexContent&gt;
                 *                               &lt;/complexType&gt;
                 *                             &lt;/element&gt;
                 *                           &lt;/sequence&gt;
                 *                         &lt;/restriction&gt;
                 *                       &lt;/complexContent&gt;
                 *                     &lt;/complexType&gt;
                 *                   &lt;/element&gt;
                 *                 &lt;/sequence&gt;
                 *               &lt;/restriction&gt;
                 *             &lt;/complexContent&gt;
                 *           &lt;/complexType&gt;
                 *         &lt;/element&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "importes"
                })
                public static class DatosImportes {

                    @XmlElement(name = "Importes", required = true)
                    protected ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes importes;

                    /**
                     * Obtiene el valor de la propiedad importes.
                     * 
                     * @return
                     *     possible object is
                     *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes }
                     *     
                     */
                    public ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes getImportes() {
                        return importes;
                    }

                    /**
                     * Define el valor de la propiedad importes.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes }
                     *     
                     */
                    public void setImportes(ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes value) {
                        this.importes = value;
                    }


                    /**
                     * <p>Clase Java para anonymous complex type.
                     * 
                     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
                     * 
                     * <pre>
                     * &lt;complexType&gt;
                     *   &lt;complexContent&gt;
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *       &lt;sequence&gt;
                     *         &lt;element name="PrimaTotal" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
                     *         &lt;element name="PrimaNeta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
                     *         &lt;element name="DatosCargos"&gt;
                     *           &lt;complexType&gt;
                     *             &lt;complexContent&gt;
                     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                 &lt;sequence&gt;
                     *                   &lt;element name="Cargo"&gt;
                     *                     &lt;complexType&gt;
                     *                       &lt;complexContent&gt;
                     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                           &lt;sequence&gt;
                     *                             &lt;element name="ClaseCargo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
                     *                             &lt;element name="Importe" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
                     *                           &lt;/sequence&gt;
                     *                         &lt;/restriction&gt;
                     *                       &lt;/complexContent&gt;
                     *                     &lt;/complexType&gt;
                     *                   &lt;/element&gt;
                     *                 &lt;/sequence&gt;
                     *               &lt;/restriction&gt;
                     *             &lt;/complexContent&gt;
                     *           &lt;/complexType&gt;
                     *         &lt;/element&gt;
                     *       &lt;/sequence&gt;
                     *     &lt;/restriction&gt;
                     *   &lt;/complexContent&gt;
                     * &lt;/complexType&gt;
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "primaTotal",
                        "primaNeta",
                        "datosCargos"
                    })
                    public static class Importes {

                        @XmlElement(name = "PrimaTotal", required = true)
                        protected BigDecimal primaTotal;
                        @XmlElement(name = "PrimaNeta", required = true)
                        protected BigDecimal primaNeta;
                        @XmlElement(name = "DatosCargos", required = true)
                        protected ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos datosCargos;

                        /**
                         * Obtiene el valor de la propiedad primaTotal.
                         * 
                         * @return
                         *     possible object is
                         *     {@link BigDecimal }
                         *     
                         */
                        public BigDecimal getPrimaTotal() {
                            return primaTotal;
                        }

                        /**
                         * Define el valor de la propiedad primaTotal.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link BigDecimal }
                         *     
                         */
                        public void setPrimaTotal(BigDecimal value) {
                            this.primaTotal = value;
                        }

                        /**
                         * Obtiene el valor de la propiedad primaNeta.
                         * 
                         * @return
                         *     possible object is
                         *     {@link BigDecimal }
                         *     
                         */
                        public BigDecimal getPrimaNeta() {
                            return primaNeta;
                        }

                        /**
                         * Define el valor de la propiedad primaNeta.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link BigDecimal }
                         *     
                         */
                        public void setPrimaNeta(BigDecimal value) {
                            this.primaNeta = value;
                        }

                        /**
                         * Obtiene el valor de la propiedad datosCargos.
                         * 
                         * @return
                         *     possible object is
                         *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos }
                         *     
                         */
                        public ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos getDatosCargos() {
                            return datosCargos;
                        }

                        /**
                         * Define el valor de la propiedad datosCargos.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos }
                         *     
                         */
                        public void setDatosCargos(ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos value) {
                            this.datosCargos = value;
                        }


                        /**
                         * <p>Clase Java para anonymous complex type.
                         * 
                         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
                         * 
                         * <pre>
                         * &lt;complexType&gt;
                         *   &lt;complexContent&gt;
                         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *       &lt;sequence&gt;
                         *         &lt;element name="Cargo"&gt;
                         *           &lt;complexType&gt;
                         *             &lt;complexContent&gt;
                         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *                 &lt;sequence&gt;
                         *                   &lt;element name="ClaseCargo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
                         *                   &lt;element name="Importe" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
                         *                 &lt;/sequence&gt;
                         *               &lt;/restriction&gt;
                         *             &lt;/complexContent&gt;
                         *           &lt;/complexType&gt;
                         *         &lt;/element&gt;
                         *       &lt;/sequence&gt;
                         *     &lt;/restriction&gt;
                         *   &lt;/complexContent&gt;
                         * &lt;/complexType&gt;
                         * </pre>
                         * 
                         * 
                         */
                        @XmlAccessorType(XmlAccessType.FIELD)
                        @XmlType(name = "", propOrder = {
                            "cargo"
                        })
                        public static class DatosCargos {

                            @XmlElement(name = "Cargo", required = true)
                            protected ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos.Cargo cargo;

                            /**
                             * Obtiene el valor de la propiedad cargo.
                             * 
                             * @return
                             *     possible object is
                             *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos.Cargo }
                             *     
                             */
                            public ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos.Cargo getCargo() {
                                return cargo;
                            }

                            /**
                             * Define el valor de la propiedad cargo.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos.Cargo }
                             *     
                             */
                            public void setCargo(ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos.Cargo value) {
                                this.cargo = value;
                            }


                            /**
                             * <p>Clase Java para anonymous complex type.
                             * 
                             * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
                             * 
                             * <pre>
                             * &lt;complexType&gt;
                             *   &lt;complexContent&gt;
                             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                             *       &lt;sequence&gt;
                             *         &lt;element name="ClaseCargo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
                             *         &lt;element name="Importe" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
                             *       &lt;/sequence&gt;
                             *     &lt;/restriction&gt;
                             *   &lt;/complexContent&gt;
                             * &lt;/complexType&gt;
                             * </pre>
                             * 
                             * 
                             */
                            @XmlAccessorType(XmlAccessType.FIELD)
                            @XmlType(name = "", propOrder = {
                                "claseCargo",
                                "importe"
                            })
                          
                            
                            public static class Cargo {

                                @XmlElement(name = "ClaseCargo", required = true)
                                protected String claseCargo;
                                @XmlElement(name = "Importe", required = true)
                                protected BigDecimal importe;

                                /**
                                 * Obtiene el valor de la propiedad claseCargo.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getClaseCargo() {
                                    return claseCargo;
                                }

                                /**
                                 * Define el valor de la propiedad claseCargo.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setClaseCargo(String value) {
                                    this.claseCargo = value;
                                }

                                /**
                                 * Obtiene el valor de la propiedad importe.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link BigDecimal }
                                 *     
                                 */
                                public BigDecimal getImporte() {
                                    return importe;
                                }

                                /**
                                 * Define el valor de la propiedad importe.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link BigDecimal }
                                 *     
                                 */
                                public void setImporte(BigDecimal value) {
                                    this.importe = value;
                                }

                            }

                        }

                    }

                }


                /**
                 * <p>Clase Java para anonymous complex type.
                 * 
                 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="FechaSituacion" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
                 *         &lt;element name="FechaEfectoActual" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
                 *         &lt;element name="FechaVencimiento" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
                 *         &lt;element name="FechaEmision" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "fechaSituacion",
                    "fechaEfectoInicial",
                    "fechaEfectoActual",
                    "fechaVencimiento",
                    "fechaEmision"
                })
                public static class Fechas {

                    @XmlElement(name = "FechaSituacion", required = true)
                    @XmlSchemaType(name = "date")
                    protected XMLGregorianCalendar fechaSituacion;                 
                    @XmlElement(name = "FechaEfectoInicial", required = true)
                    @XmlSchemaType(name = "date")
                    protected XMLGregorianCalendar fechaEfectoInicial;
                    @XmlElement(name = "FechaEfectoActual", required = true)
                    @XmlSchemaType(name = "date")
                    protected XMLGregorianCalendar fechaEfectoActual;
                    @XmlElement(name = "FechaVencimiento", required = true)
                    @XmlSchemaType(name = "date")
                    protected XMLGregorianCalendar fechaVencimiento;
                    @XmlElement(name = "FechaEmision", required = true)
                    @XmlSchemaType(name = "date")
                    protected XMLGregorianCalendar fechaEmision;

                    /**
                     * Obtiene el valor de la propiedad fechaSituacion.
                     * 
                     * @return
                     *     possible object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public XMLGregorianCalendar getFechaSituacion() {
                        return fechaSituacion;
                    }

                    /**
                     * Define el valor de la propiedad fechaSituacion.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public void setFechaSituacion(XMLGregorianCalendar value) {
                       this.fechaSituacion = value;
                   }
                    
                    
                    /**
                     * Obtiene el valor de la propiedad fechaEfectoActual.
                     * 
                     * @return
                     *     possible object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public XMLGregorianCalendar getFechaEfectoInicial() {
                        return fechaEfectoInicial;
                    }
                    
                

                /**
                 * Define el valor de la propiedad fechaEfectoInicial.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link XMLGregorianCalendar }
                 *     
                 */
                public void setFechaEfectoInicial(XMLGregorianCalendar value) {
                    this.fechaEfectoInicial = value;
                }

                    /**
                     * Obtiene el valor de la propiedad fechaEfectoActual.
                     * 
                     * @return
                     *     possible object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public XMLGregorianCalendar getFechaEfectoActual() {
                        return fechaEfectoActual;
                    }

                    /**
                     * Define el valor de la propiedad fechaEfectoActual.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public void setFechaEfectoActual(XMLGregorianCalendar value) {
                        this.fechaEfectoActual = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad fechaVencimiento.
                     * 
                     * @return
                     *     possible object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public XMLGregorianCalendar getFechaVencimiento() {
                        return fechaVencimiento;
                    }

                    /**
                     * Define el valor de la propiedad fechaVencimiento.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public void setFechaVencimiento(XMLGregorianCalendar value) {
                        this.fechaVencimiento = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad fechaEmision.
                     * 
                     * @return
                     *     possible object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public XMLGregorianCalendar getFechaEmision() {
                        return fechaEmision;
                    }

                    /**
                     * Define el valor de la propiedad fechaEmision.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public void setFechaEmision(XMLGregorianCalendar value) {
                        this.fechaEmision = value;
                    }

                }
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "claseGestion",
                	"datosFormaPago"
                })
                public static class GestionCobro {

                    public String getClaseGestion() {
						return claseGestion;
					}
					public void setClaseGestion(String claseGestion) {
						this.claseGestion = claseGestion;
					}
					public DatosFormaPago getDatosFormaPago() {
						return datosFormaPago;
					}
					public void setDatosFormaPago(DatosFormaPago datosFormaPago) {
						this.datosFormaPago = datosFormaPago;
					}
					@XmlElement(name = "ClaseGestion", required = true)
                    protected String claseGestion;
                    @XmlElement(name = "DatosFormaPago", required = true)
                    protected DatosFormaPago datosFormaPago;
                }
                
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "claseFormaPago",
                    "datosCuentaCorriente"
                })
                public static class DatosFormaPago {

                    @XmlElement(name = "ClaseFormaPago", required = true)
                    protected String claseFormaPago;
                    @XmlElement(name = "DatosCuentaCorriente", required = true)
                    protected DatosCuentaCorriente datosCuentaCorriente;
					public DatosCuentaCorriente getDatosCuentaCorriente() {
						return datosCuentaCorriente;
					}

					public void setDatosCuentaCorriente(DatosCuentaCorriente datosCuentaCorriente) {
						this.datosCuentaCorriente = datosCuentaCorriente;
					}

					public String getClaseFormaPago() {
						return claseFormaPago;
					}

					public void setClaseFormaPago(String claseFormaPago) {
						this.claseFormaPago = claseFormaPago;
					}
                }
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "entidad",
                    "oficina",
                    "dc",
                    "cuenta",
                    "iban"
                })
                public static class DatosCuentaCorriente {

                   
					@XmlElement(name = "Entidad", required = true)
                    protected String entidad;
                    @XmlElement(name = "Oficina", required = true)
                    protected String oficina;
                    @XmlElement(name = "DC", required = true)
                    protected String dc;
                    @XmlElement(name = "Cuenta", required = true)
                    protected String cuenta;
                    @XmlElement(name = "IBAN", required = true)
                    protected String iban;

                    public String getEntidad() {
						return entidad;
					}
					public void setEntidad(String entidad) {
						this.entidad = entidad;
					}
					public String getOficina() {
						return oficina;
					}
					public void setOficina(String oficina) {
						this.oficina = oficina;
					}
					public String getDc() {
						return dc;
					}
					public void setDc(String dc) {
						this.dc = dc;
					}
					public String getCuenta() {
						return cuenta;
					}
					public void setCuenta(String cuenta) {
						this.cuenta = cuenta;
					}
					public String getIban() {
						return iban;
					}
					public void setIban(String iban) {
						this.iban = iban;
					}
                }

            }

        }

    }

}
