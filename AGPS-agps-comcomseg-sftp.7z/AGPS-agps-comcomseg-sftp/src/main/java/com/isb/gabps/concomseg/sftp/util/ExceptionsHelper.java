package com.isb.gabps.concomseg.sftp.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.isb.gabps.concomseg.sftp.SFTPException;
import com.isb.gabps.concomseg.sftp.SFTPException.ERROR_TYPE;

/**
 * Clase helper para generar excepciones.
 * 
 * @author xIS08485
 */
public final class ExceptionsHelper {


	
    // Constructor privado para que no pueda crearse desde fuera (patrón singleton)
    private ExceptionsHelper() {}
    
    

   
    /**
     * @param cause
     * @return SFTPException
     */
    public static SFTPException connectionError(Throwable cause) {
    	ERROR_TYPE errorType = ERROR_TYPE.CONNECTION_ERROR;
    	String errorCode = "ERROR_CONNECTION";
    	String errorMessage = "Error en conexión al servidor sftp";
    	return new SFTPException(errorType, errorCode, errorMessage, cause);
    }
    
    /**
     * Cuando ha ocurrido un error durante 
     * 
     * @param cause Excepción que provoca el error
     * @throws SFTPException Excepción a devolver
     * @return SFTPException
     */
    public static SFTPException communicationError(Throwable cause) {
    	ERROR_TYPE errorType = ERROR_TYPE.CONNECTION_ERROR;
    	String errorCode = "ERROR_COMMUNICATION";
    	String errorMessage = "Error de comunicación con el servidor sftp";
			return new SFTPException(errorType, errorCode, errorMessage, cause);
    }
    
    /**
     * Cuando se intenta ejecutar un comando sin existir conexión.
     * 
     * @throws SFTPException Excepción a devolver
     * @return SFTPException
     */
    public static SFTPException notConnectedError() {
    	ERROR_TYPE errorType = ERROR_TYPE.CONNECTION_ERROR;
    	String errorCode = "ERROR_NOT_CONNECTED";
    	String errorMessage = "Error al realizar operación sobre el servidor sftp sin estar conectado";
		return new SFTPException(errorType, errorCode, errorMessage);
    }
    
    /**
     * Error al intentar crear una carpeta.
     * 
     * @param system Donde ocurre el error (sftp, filesystem, etc)
     * @param dir Carpeta que se intenta crear
     * @throws SFTPException Excepción a devolver
     * @return SFTPException
     */
    public static SFTPException mkdirError(String system, String dir) {
    	ERROR_TYPE errorType = ERROR_TYPE.TECHNICAL_ERROR;
    	String errorCode = "ERROR_MKDIR";
    	String errorMessage = "Error en " + system + ", no se puede crear la carpeta: " + dir;
	   	return new SFTPException(errorType, errorCode, errorMessage);	
    }
    
    /**
     * Cuando la ruta no existe.
     * 
     * @param system Donde ocurre el error (sftp, filesystem, etc)
     * @param path Ruta que ha provocado el error
     * @throws SFTPException Excepción a devolver
     * @return SFTPException
     */
    public static SFTPException pathNonExistentError(String system, String path) {
    	ERROR_TYPE errorType = ERROR_TYPE.CONFIGURATION_ERROR;
    	String errorCode = "ERROR_PATH_NON_EXISTENT";
    	String errorMessage = "Error de configuración, la ruta '" + path + "' en " + system + " no existe";
    	return new SFTPException(errorType, errorCode, errorMessage);
    }
    
    /**
     * Cuando el recurso buscado no es encontrado.
     * 
     * @param system Donde ocurre el error (sftp, filesystem, etc)
     * @param resource Recurso buscado (póliza, recibo, etc)
     * @throws SFTPException Excepción a devolver
     * @return SFTPException
     */
    public static SFTPException resNotFoundError(String system, String resource) {
    	ERROR_TYPE errorType = ERROR_TYPE.OPERATION_ERROR;
    	String errorCode = "ERROR_RESOURCE_NOT_FOUND";
    	String errorMessage = "Error de operación, no se han encontrado " + resource + " en " + system;
    	return new SFTPException(errorType, errorCode, errorMessage);
    }
    
    /**
     * Ha ocurrido un error inesperado.
     * 
     * @param message Información adicional sobre el error
     * @throws SFTPException Excepción a devolver
     * @return SFTPException
     */
    public static SFTPException unexpectedError(String message) {
    	ERROR_TYPE errorType = ERROR_TYPE.TECHNICAL_ERROR;
    	String errorCode = "ERROR_UNEXPECTED";
    	String errorMessage = "Ha ocurrido un error inesperado: " + message;
    	return new SFTPException(errorType, errorCode, errorMessage);
    }
    
    /**
     * Cuando ocurre un error al procesar un fichero xml.
     * 
     * @param message Información adicional sobre el error
     * @throws SFTPException Excepción a devolver
     * @return SFTPException
     */
    public static SFTPException xmlProcessingError(String message) {
    	ERROR_TYPE errorType = ERROR_TYPE.TECHNICAL_ERROR;
    	String errorCode = "ERROR_XML_PROCESSING";
    	String errorMessage = "Ha ocurrido un error durante el procesamiento del XML: " + message;
    	return new SFTPException(errorType, errorCode, errorMessage);
    }
    
    /**
     * Cuando ocurre un error al procesar un fichero xml.
     * 
     * @param message Información adicional sobre el error
     * @param cause Excepción que provoca el error
     * @throws SFTPException Excepción a devolver
     * @return SFTPException
     */
    public static SFTPException xmlProcessingError(String message, Throwable cause) {
    	ERROR_TYPE errorType = ERROR_TYPE.TECHNICAL_ERROR;
    	String errorCode = "ERROR_XML_PROCESSING";
    	String errorMessage = "Ha ocurrido un error durante el procesamiento del XML: " + message;
		return new SFTPException(errorType, errorCode, errorMessage, cause);
    }
}
