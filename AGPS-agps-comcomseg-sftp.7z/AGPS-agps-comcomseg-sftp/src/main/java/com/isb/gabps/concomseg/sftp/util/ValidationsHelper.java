package com.isb.gabps.concomseg.sftp.util;

import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Clase helper para realizar las validaciones de los datos de entrada.
 * 
 * @author xIS08485
 */
public final class ValidationsHelper {
	// Logger
	private static final Logger LOGGER = LoggerFactory.getLogger(ValidationsHelper.class);
	
    // Constantes
    private static final String TEMPLATE_MESSAGE = "Error en %s, el campo '%s' %s";
    
    
    
    // Evitar que se inicialice
    private ValidationsHelper() {
    }
    
    /**
     * Valida que un campo no sea nulo.
     * 
     * @param field Nombre del campo
     * @param value Valor del campo
     */
    public static void notNull(String source, String field, Object value) {
    	if (value == null) {
    		String mensaje = String.format(TEMPLATE_MESSAGE,
    				source, field, "no puede ser nulo.");
    		LOGGER.error(mensaje);
    		throw new IllegalArgumentException(mensaje);
    	}
    }
    
    /**
     * Valida que un string no sea nulo o esté vacío.
     * 
     * @param field Nombre del campo
     * @param value Valor del campo
     */
    public static void notEmpty(String source, String field, String value) {
    	if (value == null) {
    		String mensaje = String.format(TEMPLATE_MESSAGE, 
    				source, field, "no puede ser nulo.");
    		LOGGER.error(mensaje);
    		throw new IllegalArgumentException(mensaje);
    	} else if (value.isEmpty()) {
    		String mensaje = String.format(TEMPLATE_MESSAGE, 
    				source, field, "no puede estar vacío.");
    		LOGGER.error(mensaje);
    		throw new IllegalArgumentException(mensaje);
    	}
    }
    
    /**
     * Valida que una lista no sea nula o no tenga elementos.
     * 
     * @param field Nombre del campo
     * @param value Lista a validar
     */
    public static void notEmpty(String source, String field, Collection<?> list) {
    	if (list == null) {
    		String mensaje = String.format(TEMPLATE_MESSAGE, 
    				source, field, "no puede ser nulo.");
    		LOGGER.error(mensaje);
    		throw new IllegalArgumentException(mensaje);
    	} else if (list.isEmpty()) {
    		String mensaje = String.format(TEMPLATE_MESSAGE, 
    				source, field, "no puede estar vacío.");
    		LOGGER.error(mensaje);
    		throw new IllegalArgumentException(mensaje);
    	}
    }
    
    /**
     * Valida que un número no sea nulo y mayor a 0.
     * 
     * @param field Nombre del campo
     * @param value Valor del campo
     */
    public static void isPositive(String source, String field, Number value) {
    	if (value == null) {
    		String mensaje = String.format(TEMPLATE_MESSAGE, 
    				source, field, "no puede ser nulo.");
    		LOGGER.error(mensaje);
    		throw new IllegalArgumentException(mensaje);
    	} else if (value.intValue() < 1) {
    		String mensaje = String.format(TEMPLATE_MESSAGE, 
    				source, field, "debe ser mayor a 0.");
    		LOGGER.error(mensaje);
    		throw new IllegalArgumentException(mensaje);
    	}
    }
    
    /**
     * Valida que un número se encuentre entre un rango de valores.
     * 
     * @param field Nombre del campo
     * @param min Valor mínimo permitido
     * @param max Valor máximo permitido
     * @param value Valor del campo
     */
    public static void inRange(String source, String field,
    		Number min, Number max, Number value) {
    	if (value == null) {
    		String mensaje = String.format(TEMPLATE_MESSAGE, 
    				source, field, "no puede ser nulo.");
    		LOGGER.error(mensaje);
    		throw new IllegalArgumentException(mensaje);
    	} else if (value.intValue() < min.intValue()) {
    		String mensaje = String.format(TEMPLATE_MESSAGE, 
    				source, field, "debe ser al menos: " + min);
    		LOGGER.error(mensaje);
    		throw new IllegalArgumentException(mensaje);
    	} else if (value.intValue() > max.intValue()) {
    		String mensaje = String.format(TEMPLATE_MESSAGE, 
    				source, field, "debe ser como máximo: " + max);
    		LOGGER.error(mensaje);
    		throw new IllegalArgumentException(mensaje);
    	}
    }
}
