package com.isb.gabps.concomseg.sftp;

import java.nio.file.Path;
import java.nio.file.Paths;

import javax.sql.DataSource;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.support.RetryTemplate;

import com.isb.conector.S3Repository;
import com.isb.conector.S3RepositoryImpl;
import com.isb.conector.S3RepositoryImplDummie;
import com.isb.gabps.concomseg.sftp.batch.job.JobRetryPolicy;
import com.jcraft.jsch.JSch;

/**
 * Resuelve las configuraciondes definidas en el properties, y genera spring beans
 * de las dependencias que requieran inyectarse v�a {@code @Autowired}.
 * 
 * @author xIS08485
 * @param <S3Repository>
 */
@Configuration
@EnableRetry
@EnableBatchProcessing
public class SFTPConfig {
	// Constantes
	private static final String PLACEHOLDER_DATE = "{date}";
	private static final String PLACEHOLDER_JOB_ID = "{jobid}";
	private static final Logger log = LoggerFactory.getLogger(SFTPConfig.class);
	// Configuraci�n relativa a las conexiones al servidor sftp
	@Value("${bucket.name}")
	private String bucketName;
	@Value("${bucket.kms}")
	private String bucketKms;
	@Value("${app.sftp.server}")
	private String sftpServer;
	@Value("#{new Integer('${app.sftp.port}')}")
	private int sftpPort;
	@Value("${app.sftp.login}")
	private String sftpLogin;
	@Value("${app.sftp.secret}")
	private String sftpSecret;
	@Value("${app.sftp.path-in}")
	private String sftpInPath;
	@Value("${app.sftp.filename-policies}")
	private String sftpInPolicies;
	@Value("${app.sftp.filename-collections}")
	private String sftpInCollections;
	@Value("${app.sftp.path-out}")
	private String sftpOutPath;
	@Value("#{new Integer('${app.sftp.connect-timeout}')}")
	private int connectTimeout;
	@Value("#{new Integer('${app.sftp.retry-attempts}')}")
	private int retryAttempts;
	@Value("#{new Long('${app.sftp.retry-delay}')}")
	private long retryDelay;
	
	// Configuraci�n relativa al filesystem local dentro del PaaS
	@Value("${app.filesystem.path-in}")
	private String fsInPath;
	@Value("${app.filesystem.filename-in}")
	private String fsInFile;
	@Value("${app.filesystem.path-out}")
	private String fsOutPath;
	@Value("${app.filesystem.filename-out}")
	private String fsOutFile;
	@Value("${app.filesystem.path-temp}")
	private String fsTempPath;
	@Value("${app.filesystem.filename-policies}")
	private String fsTempPolicies;
	@Value("${app.filesystem.filename-collections}")
	private String fsTempCollections;

	
	
	// Configuraci�n relativa a la activaci�n/desactivaci�n de features de la aplicaci�n .
	@Value("${app.feat.async}")
	private Boolean featAsync;
	@Value("${app.feat.cleanup}")
	private Boolean featCleanup;
	
	// Spring Batch
	@Autowired
	private JobRepository jobRepository;
	@Autowired
	private JobExplorer jobExplorer;
	
	@Value("${spring.datasource.url}")
	private String url;
	@Value("${spring.datasource.username}")
	private String user;
	@Value("${spring.datasource.password}")
	private String pass;
	@Value("${spring.datasource.driver-class-name}")
	private String driver;
	
	// ##############################################
	// ###     GETTERS APPLICATION.PROPERTIES     ###
	// ##############################################
	
	
	public String getBucketName() {
		return bucketName;
	}

	public void setBucketName(String bucketName) {
	
		this.bucketName = bucketName;
	}

	public String getBucketKms() {
		return bucketKms;
	}

	public void setBucketKms(String bucketKms) {
		
		this.bucketKms = bucketKms;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	/**
	 * Direcci�n/IP del servidor sftp.
	 */
	public String getSFTPServer() {
		return sftpServer;
	}
	
	/**
	 * Puerto donde est� levantado el servidor sftp.
	 */
	public int getSFTPPort() {
		return sftpPort;
	}
	
	/**
	 * Login para la conexi�n al servidor sftp.
	 */
	public String getSFTPLogin() {
	
		return sftpLogin;
	}
	
	/**
	 * Contrase�a para la conexi�n al servidor sftp.
	 */
	public String getSFTPSecret() {
		return sftpSecret;
	}
	
	/**
	 * Ruta en el servidor sftp a los ficheros de entrada.
	 */
	public String getSFTPInPath() {
		return sftpInPath;
	}
	
	/**
	 * Patr�n de los ficheros de p�lizas a descargar del servidor sftp.
	 * 
	 * @param date Fecha a sustituir en el patr�n devuelto
	 */
	public String getSFTPInPoliciesPattern(String date) {
		//CAMBIO EN POLITICAS DE BUSQUEDA JMLO
		return sftpInPolicies.replace(PLACEHOLDER_DATE, date);
	}
	
	/**
	 * Patr�n de los ficheros de recibos a descargar del servidor sftp.
	 * 
	 * @param date Fecha a sustituir en el patr�n devuelto
	 */
	public String getSFTPInCollectionsPattern(String date) {
		return sftpInCollections.replace(PLACEHOLDER_DATE, date);
	}
	
	/**
	 * Ruta en el servidor sftp a los ficheros de salida.
	 */
	public String getSFTPOutPath() {
		return sftpOutPath;
	}
	
	/**
	 * Timeout a esperar (en ms) durante conexi�n al servidor sftp.
	 */
	public int getConnectTimeout() {
		return connectTimeout;
	}
	
	/**
	 * N�mero de reintentos para conexi�n al servidor sftp.
	 */
	public int getRetryAttempts() {
		return retryAttempts;
	}
	
	/**
	 * Tiempo a esperar (en ms) entre cada reintento de conexi�n.
	 */
	public long getRetryDelay() {
		return retryDelay;
	}

	/**
	 * Ruta en el filesystem local al fichero de entrada, con los recibos mensuales.
	 * 
	 * @param date Fecha a sustituir en el nombre del fichero
	 * return path Retorno del path obtenido
	 */
	public String getFSInFile(String date) {
		return FilenameUtils.getName(fsInFile.replace(PLACEHOLDER_DATE, date));
	} 
	
	public String getFSOutPath() {
		return fsOutPath;
	}

	/**
	 * Ruta en el filesystem local al fichero de entrada, con los recibos mensuales.
	 * 
	 * @param date Fecha a sustituir en el nombre del fichero
	 * return path Retorno del path obtenido
	 */
	public String getFSInFileError(String date) {
		return FilenameUtils.getName("NOTFOUND_"+fsInFile.replace(PLACEHOLDER_DATE, date));
	}
	/**
	 * Ruta en el filesystem local al fichero de salida, el de los movimientos contables del mes.
	 * return path Retorno del path obtenido
	 */
	public String getFSOutFile() {
		return fsOutPath+"_"+FilenameUtils.getName(fsOutFile);	
	}
	
	public String getFSOutFile2() {
		return FilenameUtils.getName(fsOutFile);	
	}
	/**
	 * Ruta en el filesystem local al fichero de entrada, con los recibos mensuales.
	 * 
	 * @param String Fecha a sustituir en el nombre del fichero
	 * return path
	 */
	public String getFSReportFile(String reportOut) {
		return fsOutPath+"_"+FilenameUtils.getName(reportOut);
	}
	
	/**
	 * Ruta en el filesystem local a la carpeta temporal (carpeta de trabajo).
	 * 
	 * @param jobid Identificador del job a sustituir en el nombre de la carpeta
	 * return path Retorno del path obtenido
	 */
	public String getFSTempPath(String jobid) {
	//	return Paths.get(fsTempPath.replace(PLACEHOLDER_JOB_ID, FilenameUtils.getName(jobid)));
	 return FilenameUtils.getName(jobid);
	}
	
	public String getFSTempPathOut(String jobid) {
		return fsTempPath.replace(PLACEHOLDER_JOB_ID, FilenameUtils.getName(jobid));
	
	}
	
	
	/**
	 * Ruta en el filesystem local al fichero de p�lizas mensuales.
	 * 
	 * @param jobid Identificador del job de la carpeta temporal
	 * return path Retorno del path obtenido
	 */
	public String getFSTempPoliciesFile(String jobid) {
		return jobid+"_"+fsTempPolicies;
	}
	
	/**
	 * Ruta en el filesystem local al fichero de recibos mensuales.
	 * 
	 * @param jobid Identificador del job de la carpeta temporal
	 * return path Retorno del path obtenido
	 */
	public String getFSTempCollectionsFile(String jobid) {
		return jobid+"_"+fsTempCollections;
	}
	
	/**
	 * Indicador {@code true/false} de si los jobs se ejecutan as�ncronamente.
	 * 
	 */
	public Boolean isFeatAsync() {
		return featAsync;
	}
	
	/**
	 * Indicador {@code true/false} de si la carpeta de trabajo se borra al completar el job.
	 */
	public Boolean isFeatCleanup() {
		return featCleanup;
	}
	
	
	
	// ##########################################
	// ###     CONFIGURACION SPRING BEANS     ###
	// ##########################################
	
	/**
	 * Creamos bean para JSch (cliente sftp), para que spring pueda inyectarlo donde se necesite.
	 * 
	 * @return Cliente JSch
	 */
	@Bean
	public JSch jschClient() {
		return new JSch();
	}
	
	/**
	 * Si ({@code app.feat.async = true}), se configura el {@link JobLauncher}
	 * para ejecutar los jobs de forma as�ncrona.
	 * 
	 * @return Job launcher as�ncrono
	 */
	@Bean
	@Primary
	@ConditionalOnProperty("app.feat.async")
	public JobLauncher asyncJobLauncher() {
		// Sustituir job launcher por uno as�ncrono
		SimpleJobLauncher asyncLauncher = new SimpleJobLauncher();
		asyncLauncher.setJobRepository(jobRepository);
		asyncLauncher.setTaskExecutor(new SimpleAsyncTaskExecutor());
		return asyncLauncher;
	}
	
	/**
	 * Creamos bean para S3Repository (cliente sftp), para que spring pueda inyectarlo donde se necesite.
	 * 
	 * @return Cliente S3Repository
	 */

	public S3Repository getS3Repository() {
		return (S3Repository)  new S3RepositoryImplDummie();//new S3RepositoryImplDummie(); S3RepositoryImpl()
	}
	
	/**
	 * Retry template configurado para que revise antes de cada retry
	 * si el job ha sido cancelado.
	 *  
	 * @param jobExecutionId Identificador de la ejecuci�n del job
	 * @return Retry template
	 */
	public RetryTemplate connectRetrier(long jobExecutionId) {
		RetryTemplate template = new RetryTemplate();
        
        FixedBackOffPolicy delayPolicy = new FixedBackOffPolicy();
        delayPolicy.setBackOffPeriod(getRetryDelay());
        template.setBackOffPolicy(delayPolicy);
 
        JobRetryPolicy retryPolicy = new JobRetryPolicy();
        retryPolicy.setMaxAttempts(getRetryAttempts() + 1); // +1 porque 0 = ningun intento
        retryPolicy.setJobExecutionId(jobExecutionId);
        retryPolicy.setJobExplorer(jobExplorer);
        template.setRetryPolicy(retryPolicy);
        
        return template;
	}
}