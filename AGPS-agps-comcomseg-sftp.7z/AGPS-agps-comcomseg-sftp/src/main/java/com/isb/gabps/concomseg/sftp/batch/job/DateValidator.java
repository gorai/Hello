package com.isb.gabps.concomseg.sftp.batch.job;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.JobParametersValidator;
import org.springframework.stereotype.Component;

import com.isb.gabps.concomseg.sftp.batch.BatchGlobals;
import com.isb.gabps.concomseg.sftp.util.ValidationsHelper;

/**
 * Valida el parámetro 'date' del job.
 * 
 * @author xIS08485
 */
@Component(BatchGlobals.VALIDATOR_DATE)
public class DateValidator implements JobParametersValidator {
	// Logger
	private static final Logger LOGGER = LoggerFactory.getLogger(DateValidator.class);

	/**
	 * Validaciones de los parámetros del job antes de ejecutarlo.
	 * En este caso se validará que la fecha del job sea válida. 
	 */
	@Override
	public void validate(JobParameters parameters) throws JobParametersInvalidException {
		// Validar datos de entrada
		ValidationsHelper.notNull("datos de entrada", "parameters", parameters);
		String date = parameters.getString(BatchGlobals.JOB_PARAM_DATE);
		ValidationsHelper.notEmpty("parámetros del job", BatchGlobals.JOB_PARAM_DATE, date);
		
		// Validar que viene en el formato correcto (AAAAMMDD)
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		sdf.setLenient(false);
		try {
			sdf.parse(date);
		} catch (ParseException e) {
			LOGGER.error("La fecha del job no parece haberse recibido en un formato válido.", e);
			throw new JobParametersInvalidException("La fecha del job (" + date
					+ ") no se recibió en un formato válido (" + sdf.toPattern() + ")");
		}
	}
}
