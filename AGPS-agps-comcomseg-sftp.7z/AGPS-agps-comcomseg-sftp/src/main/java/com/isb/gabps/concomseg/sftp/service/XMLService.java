package com.isb.gabps.concomseg.sftp.service;

import java.io.InputStream;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

import javax.xml.transform.stream.StreamResult;

import com.isb.gabps.concomseg.sftp.SFTPException;

/**
 * Servicio para el tratamiento de ficheros XMLs, permitiendo hacer merge entre varios ficheros.
 * 
 * @author xIS08485
 */
public interface XMLService {
	
	/**
	 * Une varios XMLs en uno, haciendo un merge de tipo uni�n.
	 * Crecen verticalmente, todos los nodos del cuerpo se a�aden al final del XML final.
	 * 
	 * @param sources Lista con las rutas a los ficheros XMLs a copiar
	 * @param target Ruta al XML generado
	 * @param date Fecha, para a�adirse en la cabecera del XML destino
	 * @param cycle Ciclo de ejecuci�n, para a�adise en la cabecera del XML destino
	 * 
	 * @throws SFTPException Tipos de errores:
	 * <ul>
	 * <li>INPUT_DATA_ERROR: Falta dato de entrada
	 * <li>CONFIGURATION_ERROR: Error de configuraci�n</li>
	 * <li>TECHNICAL_ERROR: Error durante el procesamiento de los XMLs
	 * </ul>
	 */
	public void mergeUnion(List<String> sources, String target, LocalDate date, long cycle)
			throws SFTPException;
	
	/**
	 * Une varios XMLs en uno, haciendo un merge de tipo join.
	 * Crecen horizontalmente, se une los nodos del XML de recibos con los de p�liza.
	 * 
	 * @param policyXML Ruta al XML con las p�lizas
	 * @param collectionXML Ruta al XML con los recibos
	 * @param target Ruta al XML generado
	 * 
	 * @throws SFTPException Tpos de errores:
	 * <ul>
	 * <li>INPUT_DATA_ERROR: Falta dato de entrada</li>
	 * <li>CONFIGURATION_ERROR: Error de configuraci�n</li>
	 * <li>TECHNICAL_ERROR: Error durante el procesamiento de los XMLs</li>
	 * </ul>
	 */
	public InputStream mergeJoin(String policyXML, String collectionXML, String target,String jobId)
			throws SFTPException;

	boolean enviarFicheroCompleto(byte[] input, String target);
}
