package com.isb.gabps.concomseg.support.db;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isb.gabps.concomseg.sftp.SFTPConfig;
import com.isb.gabps.concomseg.sftp.repository.TratComDao;


//import com.isb.gabps.concomseg.support.sftp.SFTPServerController;

/**
 * Herramienta de desarrollo para hacer queries en BBDD que se encuentran dentro del PaaS.
 * Para usarse requiere activar el perfil spring: dev-tools.
 * 
 * @author xIS08485
 */
//@Profile("feat-db")
@RestController
@RequestMapping("/db") 
public class DBQueryController {
	// Para lanzar las quieries al SQL
	@Autowired
	private JdbcTemplate template;
	private static final Logger LOGGER = LoggerFactory.getLogger(DBQueryController.class);
	@Autowired
	private TratComDao repository;
	@Autowired
	private DataSource dataSource;
	@Autowired
	private SFTPConfig config;
	/**
	 * Servicio REST para buscar los registros de recibos guardados por el proceso contable.
	 * Permite filtrar por: pÃ³liza, producto, recibo, situaciÃ³n, tipo o fecha.
	 * 
	 * <p>
	 * URL acceso: GET .../db/collections
	 * 
	 * @param policy ID pÃ³liza para filtrar resultados (opcional)
	 * @param product ID producto para filtrar resultados (opcional)
	 * @param collection ID recibo para filtrar resultados (opcional)
	 * @param status situaciÃ³n recibo para filtrar resultados (opcional)
	 * @param type tipo de recibo para filtrar resultados (opcional)
	 * @param date fecha efecto para filtrar resultados (opcional)
	 * @return Lista de registros encontrados
	 */
	@GetMapping("collections")//List<CollectionEntity>
	public Object findCollections(
			@RequestParam(required = false) String query,
			@RequestParam(required = false) String policy,
			@RequestParam(required = false) String product,
			@RequestParam(required = false) String collection,
			@RequestParam(required = false) String status,
			@RequestParam(required = false) String type,
			@RequestParam(required = false) String date
			) {
	
		template.setDataSource(dataSource);
		LOGGER.debug("JMLO DB LIST");
		
		List<Object> params = new ArrayList<>();
		StringJoiner where = new StringJoiner(" AND ", " WHERE ", "").setEmptyValue("");
		if (informado(policy)) {
			params.add(policy);
	        where.add("co_poliza = ?");
	    }
		if (informado(product)) {
			params.add(product);
	        where.add("co_producto = ?");
	    }
		if (informado(collection)) {
			params.add(collection);
	        where.add("co_recibo = ?");
	    }
		if (informado(status)) {
			params.add(status);
	        where.add("co_sit_recibo = ?");
	    }
		if (informado(type)) {
			params.add(type);
	        where.add("co_tipo_recibo = ?");
	    }
		if (informado(date)) {
			params.add(date);
	        where.add("fh_efe_act_rec = ?");
	    }
		
		// Ejecutar query
		List<String> resultado = new ArrayList<>();
		List<Map<String, Object>> rows = null;
		
		int totalUpdate=0;
		
		if(query.toUpperCase().startsWith("SELECT"))
			rows = template.queryForList(query);
		else {
			totalUpdate= template.update(query);
	
			return String.valueOf(totalUpdate);
		}
		if(rows !=null) {
		int i=0;	
		// Devolver resultados
		for (Map<String, Object> row : rows) {
			i++;
			String linea ="";
			if(i==1) {
				String cabecera=row.keySet().toString();
			resultado.add(cabecera);	
			}
						
				resultado.add(row.values().toString());
		
		}
		resultado.add(String.valueOf((i)));
		return resultado;
		}
		return null;
		// FIN OK
		
	}
	
	public boolean informado(String dato) {
		
		if ((dato!= null) && !dato.isEmpty()) 
			
			return true;
		else
			return false;
				
	}
	
	/**
	 * Servicio REST para aÃ±adir un registro de recibo en la tabla consultada por el proceso contable.
	 * Todos los campos de entrada son obligatorios.
	 * 
	 * <p>
	 * Situaciones de recibos:
	 * <ul>
	 * <li>Pendiente
	 * <li>Cobrado
	 * <li>Devuelto
	 * <li>Anulado
	 * <li>Liquidado
	 * <li>Rehabilitado
	 * </ul>
	 * 
	 * <p>
	 * Tipos de recibos:
	 * <ul>
	 * <li>Cartera
	 * <li>Extorno
	 * <li>Pago anticipado (seguro decenal y transportes)
	 * <li>Movimientos
	 * <li>Nueva producciÃ³n
	 * <li>ParticipaciÃ³n en beneficios
	 * <li>Suplemento
	 * <li>AportaciÃ³n extraordinaria
	 * <li>Traspaso
	 * </ul>
	 * 
	 * <p>
	 * Forma de pago:
	 * <ul>
	 * <li>Mensual
	 * <li>Bimestral
	 * <li>Trimestral
	 * <li>Cuatrimestral
	 * <li>Semestral
	 * <li>Anual
	 * <li>Ãšnica
	 * <li>Extraordinaria
	 * </ul>
	 * 
	 * <p>
	 * URL acceso: POST .../db/collections
	 * 
	 * @param policy ID pÃ³liza
	 * @param amendment NÃºmero de suplemento (0 si no es un suplemento)
	 * @param agency Mediador
	 * @param product ID producto
	 * @param collection ID recibo
	 * @param status SituaciÃ³n del recibo (PE/CO/DE/AN/LI/RE)
	 * @param type Tipo del recibo (CA/EX/PA/MO/NP/PB/SU/AE/TR)
	 * @param payment Forma/periodicidad de pago (ME/BI/TR/CU/SE/AN/UN/EX)
	 * @param statusDate Fecha de situaciÃ³n actual
	 * @param effectiveDate Fecha efecto
	 * @param expiryDate Fecha de vencimiento
	 * @param emissionDate Fecha de emisiÃ³n
	 * @param totalPremAmount Importe de la prima total
	 * @param netPremAmount Importe de la prima neta
	 * @param costsAmount Importe de los cargos
	 * @param totalCommisAmount Importe de la comisiÃ³n total
	 * @param netCommisAmount Importe de la comisiÃ³n neta
	 * @param statusInternal SituaciÃ³n interna
	 * @param retroSwitch Indicador de retrocesiÃ³n
	 * @param commisDate Fecha de la comisiÃ³n
	 * @param retroDate Fecha de retrocesiÃ³n
	 * @param lastPeriodDate Fecha Ãºltima periodificaciÃ³n
	 * @param lastPeriodAmount Importe de Ãºltima periodificaciÃ³n
	 * @param totalPeriodAmount Importe periodificaciÃ³n total 
	 * @param user ID usuario
	 * @param modificationDate Timestamp de Ãºltima modificaciÃ³n
	 * @return OK/KO
	 */
	@PostMapping("collections")
	public String addCollection(
			@RequestParam String policy,
			@RequestParam Integer amendment,
			@RequestParam String agency,
			@RequestParam String product,
			@RequestParam String collection,
			@RequestParam String status,
			@RequestParam String type,
			@RequestParam String payment,
			@RequestParam Date statusDate,
			@RequestParam Date effectiveDate,
			@RequestParam Date expiryDate,
			@RequestParam Date emissionDate,
			@RequestParam BigDecimal totalPremAmount,
			@RequestParam BigDecimal netPremAmount,
			@RequestParam BigDecimal costsAmount,
			@RequestParam BigDecimal totalCommisAmount,
			@RequestParam BigDecimal netCommisAmount,
			@RequestParam String statusInternal,
			@RequestParam String retroSwitch,
			@RequestParam Date commisDate,
			@RequestParam Date retroDate,
			@RequestParam Date lastPeriodDate,
			@RequestParam BigDecimal lastPeriodAmount,
			@RequestParam BigDecimal totalPeriodAmount,
			@RequestParam String user,
			@RequestParam Date modificationDate
			) {
		LOGGER.debug("JMLO DB SELECT");
		// SELECT...
		String query =
				"INSERT INTO seguros_comis_contab "
			  + "           (co_poliza, num_suplemento, co_mediador, co_producto, co_recibo"
			  + "          , co_sit_recibo, co_tipo_recibo, co_period_pago, fh_sit_rec, fh_efe_act_rec"
			  + "          , fh_vto_rec, fh_emis_rec, im_prim_tot_pol, im_prim_net_pol, im_cargo"
			  + "          , com_bruta, com_liquida, ci_est_interno, ci_retr_contab, fh_alta_com"
			  + "          , fh_retr_com, fh_ult_period, im_ult_period, im_tot_period, co_usuario"
			  + "          , fh_modif) "
			  + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		// EjecuciÃ³n del insert
		int numRegistros = template.update(query, policy, amendment, agency, product, collection, status
				, type, payment, statusDate, effectiveDate, expiryDate, emissionDate, totalPremAmount
				, netPremAmount, costsAmount, totalCommisAmount, netCommisAmount, statusInternal, retroSwitch
				, commisDate, retroDate, lastPeriodDate, lastPeriodAmount, totalPeriodAmount, user
				, modificationDate);
		
		// FIN OK
		return "Registros aÃ±adidos: " + numRegistros;
	}
	
	/**
	 * Servicio REST para borrar un registro de recibos guardado por el proceso contable.
	 * 
	 * <p>
	 * URL acceso: DELETE .../db/collections/{policy}/{amendment}/{collection}
	 * 
	 * @param policy ID pÃ³liza del registro a borrar
	 * @param amendment NÃºmero del suplemento del registro a borrar
	 * @param collection ID recibo del registro a borrar
	 * 
	 * @return OK/KO
	 */
	@DeleteMapping("collections/{policy}/{amendment}/{collection}")
	public String deleteCollection(
			@PathVariable String policy,
			@PathVariable Integer amendment,
			@PathVariable String collection) {
		LOGGER.debug("JMLO DB Collections");
		// SELECT...
		String query =
				"DELETE FROM seguros_comis_contab "
			  + "WHERE co_poliza = ?"
			  + "  AND num_suplemento = ?"
			  + "  AND co_recibo = ?";
		
		// EjecuciÃ³n del delete
		int numRegistros = template.update(query, policy, amendment, collection);
		
		// FIN OK
		return "Registros eliminados: " + numRegistros;
	}
	
	/**
	 * Servicio REST para buscar los registros de productos guardados por el proceso contable.
	 * Permite filtrar por: producto o concepto de liquidaciÃ³n.
	 * 
	 * <p>
	 * URL acceso: GET .../db/products
	 * 
	 * @param product ID producto para filtrar resultados (opcional)
	 * @param settlement ID del concepto de liquidaciÃ³n para filtrar resultados (opcional)
	 * @return Lista de registros encontrados
	 */
	@GetMapping("products")
	public List<ProductEntity> findProducts(
			@RequestParam(required = false) String product,
			@RequestParam(required = false) String settlement
			) {
		LOGGER.debug("JMLO DB Products");
		// SELECT...
		String query =
				"SELECT * FROM seguros_conv_productos";
		
		// WHERE...
		List<Object> params = new ArrayList<>();
		StringJoiner where = new StringJoiner(" AND ", " WHERE ", "").setEmptyValue("");
		if ((product != null) && !product.isEmpty()) {
			params.add(product);
	        where.add("co_producto = ?");
	    }
		if ((settlement != null) && !settlement.isEmpty()) {
			params.add(settlement);
	        where.add("co_coconcli = ?");
	    }
		
		// Ejecutar query
		List<ProductEntity> resultado = new ArrayList<>();
		List<Map<String, Object>> rows;
		if (where.length() > 0) {
			rows = template.queryForList(query + where, params.toArray());
		} else {
			rows = template.queryForList(query);
		}
		
		// Devolver resultados
		for (Map<String, Object> row : rows) {
			ProductEntity producto = new ProductEntity();
			producto.setProducto((String)row.get("co_producto"));
			producto.setConcepLiquidacion((String)row.get("co_coconcli"));
			producto.setCtaDebe((String)row.get("co_cta_debe"));
			producto.setCtaHaber((String)row.get("co_cta_haber"));
			producto.setUsuario((String)row.get("co_usuario"));
			producto.setFechaModificacion((Timestamp)row.get("fh_modif"));
			resultado.add(producto);
		}
		
		// FIN OK
		return resultado;
	}
	
	/**
	 * Servicio REST para aÃ±adir un registro de producto en la tabla consultada por el proceso contable.
	 * Todos los campos de entrada son obligatorios.
	 * 
	 * <p>
	 * Conceptos de liquidaciÃ³n:
	 * <ul>
	 * <li>CS0 - ComisiÃ³n por alta de hogar
	 * <li>CS1 - ComisiÃ³n por alta de robo
	 * <li>CS2 - ComisiÃ³n por alta de vida
	 * <li>CS3 - ComisiÃ³n por alta de vida prÃ©stamo
	 * <li>CS4 - ComisiÃ³n por alta de autos
	 * </ul>
	 * 
	 * <p>
	 * URL acceso: POST .../db/products
	 * 
	 * @param product ID producto
	 * @param settlement ID concepto de liquidaciÃ³n (CS0/CS1/CS2/CS3/CS4)
	 * @param accountDebit NÃºmero de cuenta DEBE
	 * @param accountCredit NÃºmero de cuenta HABER
	 * @param user ID usuario
	 * @param modificationDate Timestamp de Ãºltima modificaciÃ³n
	 * @return OK/KO
	 */
	@PostMapping("products")
	public String addProduct(
			@RequestParam String product,
			@RequestParam String settlement,
			@RequestParam String accountDebit,
			@RequestParam String accountCredit,
			@RequestParam String user,
			@RequestParam Date modificationDate
			) {
		LOGGER.debug("JMLO DB Products");
		// SELECT...
		String query =
				"INSERT INTO seguros_conv_productos "
			  + "           (co_producto, co_coconcli, co_cta_debe, co_cta_haber"
			  + "          , co_usuario, fh_modif)"
			  + "VALUES (?, ?, ?, ?, ?, ?)";
		
		// EjecuciÃ³n del insert
		int numRegistros = template.update(query, product, settlement, accountDebit, accountCredit
				, user, modificationDate);
		
		// FIN OK
		return "Registros aÃ±adidos: " + numRegistros;
	}
	
	/**
	 * Servicio REST para borrar un registro de producto guardado por el proceso contable.
	 * 
	 * <p>
	 * URL acceso: DELETE .../db/products/{product}
	 * 
	 * @param product ID producto
	 * 
	 * @return OK/KO
	 */
	@DeleteMapping("products/{product}")
	public String deleteProduct(
			@PathVariable String product) {
		LOGGER.debug("JMLO DB Delete");
		// SELECT...
		String query =
				"DELETE FROM seguros_conv_productos "
			  + "WHERE co_producto = ?";
		
		// EjecuciÃ³n del delete
		int numRegistros = template.update(query, product);
		
		// FIN OK
		return "Registros eliminados: " + numRegistros;
	}
}
