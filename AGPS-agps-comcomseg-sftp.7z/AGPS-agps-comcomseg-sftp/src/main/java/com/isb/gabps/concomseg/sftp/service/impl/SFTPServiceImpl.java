package com.isb.gabps.concomseg.sftp.service.impl;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.isb.conector.S3Repository;
import com.isb.conector.S3RepositoryImpl;
import com.isb.conector.S3RepositoryImplDummie;
import com.isb.gabps.concomseg.sftp.SFTPConfig;
import com.isb.gabps.concomseg.sftp.SFTPException;
import com.isb.gabps.concomseg.sftp.service.SFTPService;
import com.isb.gabps.concomseg.sftp.util.ExceptionsHelper;
import com.isb.gabps.concomseg.sftp.util.ValidationsHelper;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.UserInfo;

/**
 * Servicio que realiza las conexiones SSH para el envio y recepcion de los ficheros
 * al servidor sftp.
 * 
 * @author xIS08485
 */
@Primary
@Service

public class SFTPServiceImpl implements SFTPService {
	// Logger

	private static final Logger LOGGER = LoggerFactory.getLogger(SFTPServiceImpl.class);
	
	// Libreria conexi�n ssh (clase principal)
	@Autowired
	private JSch ssh = null;
	
	// Libreria conexi�n ssh (sesi�n de una conexi�n)
	private Session session = null;
	
	// Libreria conexi�n ssh (canal sftp de la conexi�n)
	private ChannelSftp channel = null;
	
	// Timeout para establecer conexi�n al servidor sftp
	private int connectTimeout = 0;
	
	// Configuraci�n (del properties)
	@Autowired
	private SFTPConfig config;
	
	// Define timeout de la conexi�n (milisegundos)
	@Override
	public void setTimeout(int timeout) {
		connectTimeout = timeout;
	}
	
	private S3Repository repository;
	// Abre conexi�n al servidor sftp
	
	@Override
	public List<String> limpiaS3() {
		
		String pattern="*";
		if(repository==null)
			repository= config.getS3Repository(); //if(false)S3RepositoryImplDummie()S3RepositoryImpl()
		// Validar que carpeta est� definida en el properties
		
		// Validar que fichero exista en la carpeta
		if ((pattern == null) || (pattern.isEmpty())) {
			Resource error = new ByteArrayResource(("ERROR: La URL del recurso es incompleta").getBytes());
			return new ArrayList<String>();
		}
		List<String> retorno=repository.deleteByPatter( config.getBucketName(),pattern);
				// Fichero existe, devolverlo en la salida
	//	Resource contenido = new FileSystemResource(result);
		return retorno;
	}
	
	@Override
	public void connect(String server, int port, String login, String secret) throws SFTPException {
		repository =  config.getS3Repository(); //if(false)S3RepositoryImplDummie()S3RepositoryImpl()
		// Validaciones
		ValidationsHelper.notEmpty("datos de entrada", "server", server);
		ValidationsHelper.inRange("datos de entrada", "port", 1, 65535, port);
		ValidationsHelper.notEmpty("datos de entrada", "login", login);
		
		// Comprobar si ya hay conexi�n
		if ((channel != null) && channel.isConnected()) {
			LOGGER.debug("Nada que hacer, ya exist�a conexi�n");
			return;
		}
		
		// Abrir conexi�n
		try {
			LOGGER.debug("Servidor sftp: " + login + "@" + server + ":" + port);
			session = ssh.getSession(login, server, port);
			//session.setConfig("StrictHostKeyChecking", "no");
			
			java.util.Properties config = new java.util.Properties(); 
			config.put("StrictHostKeyChecking", "no");
			UserInfo ui = new MyUserInfo(secret, null);
			session.setUserInfo(ui);
			session.setConfig(
			    "PreferredAuthentications", 
			    "publickey,keyboard-interactive,password");
			session.setPassword(secret);
			session.connect(connectTimeout);
			
			Channel newChannel = session.openChannel("sftp");
			newChannel.connect(connectTimeout);
			channel = (ChannelSftp) newChannel;
		} catch (JSchException e) {
			LOGGER.error("Error t�cnico al abrir la conexi�n con el servidor", e);
			throw ExceptionsHelper.connectionError(e);
		}
		
	}
	
	// Desconectarse del servidor sftp.
	@Override
	public void disconnect() {
		
		// Comprobar si todav�a hay conexi�n
		if ((channel != null) && channel.isConnected()) {
			channel.disconnect();
			session.disconnect();
			
			LOGGER.debug("Conexi�n finalizada");
		} else {
			LOGGER.debug("Nada que hacer, no exist�a conexi�n");
		}
		
		channel = null;
		session = null;
	}
	
	public String incrementarMes(String mes) {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		String mesActual="";
		try {
			Date date = sdf.parse(mes);
			Calendar cal = Calendar.getInstance();
			cal. setTime(date);
			cal.add(Calendar.MONTH, 1);
			SimpleDateFormat format1 = new SimpleDateFormat("yyyyMM");
			mesActual = format1.format(cal.getTime());
		
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			LOGGER.error("Error al obtener las fechas");
			return "";
		}
return mesActual;
	}
	
	// Descarga ficheros de p�lizas y recibos diarios al local
	@Override
	public List<String> downloadFiles(String pattern, String destination,String mes) throws SFTPException {
		// Validaciones
		ValidationsHelper.notEmpty("datos de entrada", "pattern", pattern);
		ValidationsHelper.notNull("datos de entrada", "destination", destination);
		
		// Comprobamos si existe la carpeta destino
	if(false) {}//	if (!Files.exists(destination)) {
			// No existe, la creamos
		//	try {
		//		Files.createDirectories(destination);
				
		//	} catch (IOException e) {
		//		LOGGER.error("Error al crear la carpeta '" + destination + "'", e);
		//		throw ExceptionsHelper.mkdirError("filesystem local", destination.toString());
		//	}
	//	}
		
		// Verificar que se est� conectado
		if ((channel == null) || !channel.isConnected()) {
			LOGGER.error("No se puede continuar, se perdi� (o nunca se tuvo) la conexi�n con el servidor");
			throw ExceptionsHelper.notConnectedError();
		}
		
		// Buscar y descargar los ficheros del servidor
		
		
		try {
			List<String> salida = sftpDownloadFiles(pattern, destination,false);
			
			String mesSiguiente=incrementarMes(mes);
		
			if(mesSiguiente.length()==6) {
			String pattern2=pattern.replaceAll(mes,mesSiguiente);
			
			List<String> salida2 = sftpDownloadFiles(pattern2, destination,true);
		
			for(int i=0;i<salida2.size();i++) {
				salida.add(salida2.get(i));
			}
			}
			
			LOGGER.debug("Ficheros descargados con �xito.");
			return salida;
		} catch (SftpException e) {
			LOGGER.error("Error t�cnico en la descarga de ficheros", e);
			throw ExceptionsHelper.communicationError(e);
		}
	}
	
	@Override
	public InputStream  getFichero(String rutaFichero) throws SFTPException {
		InputStream streamFile = null;
		try {
			streamFile = channel.get(rutaFichero);
		} catch (SftpException e) {
			// TODO Auto-generated catch block
			LOGGER.debug("Error t�cnico en la descarga de ficheros", e);
			throw ExceptionsHelper.communicationError(e);
		}
		
		return streamFile;
	}
	
	// Sube fichero contable al servidor sftp
	@Override
	public void uploadFile(String file, String destination) throws SFTPException {
	
		// Validaciones
		ValidationsHelper.notEmpty("datos de entrada", "file", file);
		ValidationsHelper.notEmpty("datos de entrada", "destination", destination);
		
		// Verificar que se est� conectado
		if ((channel == null) || !channel.isConnected()) {
		
			throw ExceptionsHelper.notConnectedError();
		}
	//	List<String> files=repository.listingPattenObjectosBucket(config.getBucketName(),file);
		// Subir los ficheros
	//	for (String fichero: files) {
			// Comprobar que exista el fichero
			
			
			// Enviar el fichero
			try {
			InputStream ficheroStream=repository.getFromS3(file, config.getBucketName());
				channel.put(ficheroStream, destination+"/"+file);
			} catch (SftpException e) {
			
				throw ExceptionsHelper.communicationError(e);
			}
		//}
	}
	
	
	 private static String convertInputStreamToString(InputStream is) throws IOException {
		 int DEFAULT_BUFFER_SIZE = 8192;
	        ByteArrayOutputStream result = new ByteArrayOutputStream();
	        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
	        int length;
	        while ((length = is.read(buffer)) != -1) {
	            result.write(buffer, 0, length);
	        }

	        // Java 1.1
	        return result.toString(StandardCharsets.UTF_8.name());

	        // Java 10
	        // return result.toString(StandardCharsets.UTF_8);

	    }
	
	public Vector<String> obtenerExcepciones(){
		
		Vector<String> salida= new Vector<String>();
		InputStream ficheroExcepciones = null;
		try {
			ficheroExcepciones = getFichero(config.getSFTPOutPath()+"/"+"FicherosExcepcion.txt");
		} catch (SFTPException e1) {
			// TODO Auto-generated catch block
			//e1.printStackTrace();
			return salida;
		}
		
		 try {
			String text = convertInputStreamToString(ficheroExcepciones);
			String[] listaLineas=text.split((String)System.getProperty("line.separator"));
			for(int i=0; i<listaLineas.length;i++)
				salida.add(listaLineas[i]);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    	      //  .lines().collect(Collectors.joining("\n"));
		
		/*BufferedReader reader = new BufferedReader(new InputStreamReader(ficheroExcepciones));
		
		try {
			while(reader.ready()) {
			     String line = reader.readLine();
			     salida.add(line);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return salida;
	}
	
	
	/**
	 * Ejecutar la descarga de los ficheros utilizando la libreria de sftp.
	 * 
	 * @param pattern M�scara de los ficheros a descargar
	 * @param destination Ubicaci�n de la carpeta donde descargar los ficheros
	 * 
	 * @return Lista de ficheros descargados
	 * @throws SftpException Error en descarga
	 */
	
	public boolean estaEnExcepcion(String nombreFichero, Vector<String>listaExcepciones) {
		
		for(int i=0;i<listaExcepciones.size();i++) {
			if(listaExcepciones.get(i).contains(nombreFichero))
		//	if(listaExcepciones.get(i).equalsIgnoreCase(nombreFichero))
				return true;
		}
		return false;
	}
	public List<String> sftpDownloadFiles(String pattern, String destination,boolean nuevo) throws SftpException {
		// Descubrir la carpeta remota, donde est�n los ficheros a descargar
		int finCarpeta = pattern.lastIndexOf("/");
		String carpeta = ".";
		if (finCarpeta >= 0) {
			carpeta = pattern.substring(0, finCarpeta);
		}
		
		// Descargar ficheros 
		List<String> ficheros = new ArrayList<>();
		Vector<LsEntry> listaFichero=channel.ls(pattern);
		
		/*BORRADO PARA GAP DE FICHEROS	
		for(int i=0; i<listaFichero.size();i++) {
			
			if(listaFichero.get(i).getFilename().equalsIgnoreCase("EIAC-ENV-E0189-0000099879-20211212064048-003.XML")||listaFichero.get(i).getFilename().equalsIgnoreCase("EIAC-ENV-E0189-0000099879-20211212060500-002.XML")) {													   																				   
				listaFichero.remove(i);
				i=0;
			}
		}
		*/
		Collections.sort(listaFichero, new Comparator() {
			  public int compare(Object a, Object b) {
			    return ( new String(((LsEntry) a).getFilename()) ).compareTo( new String(((LsEntry) b).getFilename()));
			  }
			});
		
		Vector<String> listaExcepciones=obtenerExcepciones();
		if(listaExcepciones.size()>0) {
		for(int i=0;i<listaFichero.size();i++) {
			
			if(estaEnExcepcion(listaFichero.get(i).getFilename(), listaExcepciones)) {
				listaFichero.removeElementAt(i);
				i=0;
			}
		}
		}
		for (LsEntry fichero: listaFichero) {
			String ruta = carpeta + "/" + fichero.getFilename();
			if (!fichero.getAttrs().isReg()) {
				// El origen no es un fichero (regular)
				LOGGER.warn("La ruta '" + ruta + "' en servidor sftp no es un archivo regular, lo ignoramos");
			} else {
				// Descargar fichero
				OutputStream ficheroTemp= new ByteArrayOutputStream();
				
				channel.get(ruta, ficheroTemp);
				LOGGER.info("JMLO Bucket name: "+config.getBucketName()+" Bucketkms "+config.getBucketKms());
				LOGGER.info("JMLO TAMA�O DEL FICHERO"+ fichero.getFilename()+" "+((ByteArrayOutputStream)ficheroTemp).size());
				String tipoFichero="";
				try {
					String out = new String(((ByteArrayOutputStream)ficheroTemp).toByteArray(), "UTF-8");
					if(out.contains("<Recibo>"))
						tipoFichero="RECIBOS";
					else if(out.contains("<Poliza>"))
						tipoFichero="POLIZAS";
				} catch (UnsupportedEncodingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(nuevo) {
					if(fichero.getFilename().startsWith(listaFichero.get(0).getFilename().substring(0,34))) {
							repository.putToS3(destination+"_"+fichero.getFilename()+"_"+tipoFichero,config.getBucketName(), null,((ByteArrayOutputStream)ficheroTemp).toByteArray() , false,config.getBucketKms());
							ficheros.add(fichero.getFilename()+"_"+tipoFichero);
					}
				}else {
					repository.putToS3(destination+"_"+fichero.getFilename()+"_"+tipoFichero,config.getBucketName(), null,((ByteArrayOutputStream)ficheroTemp).toByteArray() , false,config.getBucketKms());
				InputStream retorno=repository.getFromS3(destination+"_"+fichero.getFilename()+"_"+tipoFichero, config.getBucketName());
				ficheros.add(fichero.getFilename()+"_"+tipoFichero);
				try {
					
					LOGGER.info("JMLO TAMA�O DEL FICHERO Recuperado "+retorno.available());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}
				
			}
		}
		
		// FIN
		return ficheros;
	}
	
	public ByteArrayOutputStream sftpDownloadFile(String rutaFichero) throws SftpException {
		// Descubrir la carpeta remota, donde est�n los ficheros a descargar
		
		ByteArrayOutputStream output=new ByteArrayOutputStream();
		// Descargar ficheros 
			
				channel.get(rutaFichero, output);
		
		// FIN
		return output;
	}
	
	
	
	public List<String> sftpListFiles(String pattern) throws SftpException {
		// Descubrir la carpeta remota, donde est�n los ficheros a descargar
		int finCarpeta = pattern.lastIndexOf("/");
		String carpeta = ".";
		if (finCarpeta >= 0) {
			carpeta = pattern.substring(0, finCarpeta);
		}
		
		// Descargar ficheros 
		List<String> ficheros = new ArrayList<>();
		LOGGER.debug("sftp> ls " + pattern);
		for (LsEntry fichero: (Vector<LsEntry>)channel.ls(pattern)) {
			String ruta = carpeta + "/" + fichero.getFilename();
			if (!fichero.getAttrs().isReg()) {
				// El origen no es un fichero (regular)
				LOGGER.warn("La ruta '" + ruta + "' en servidor sftp no es un archivo regular, lo ignoramos");
			} else {
				// Descargar fichero
				
				
				ficheros.add(fichero.getFilename());
			}
		}
		
		// FIN
		return ficheros;
	}
	
	@Override
	public void sftpRenameFiles(String pattern, Path destination) {
		// Descubrir la carpeta remota, donde est�n los ficheros a descargar
		int finCarpeta = pattern.lastIndexOf("/");
		String carpeta = ".";
		if (finCarpeta >= 0) {
			carpeta = pattern.substring(0, finCarpeta);
		}		
		// Descargar ficheros	
		try {
			for (LsEntry fichero: (Vector<LsEntry>)channel.ls(pattern)) {
				String ruta = carpeta + "/" + fichero.getFilename();
				if (!fichero.getAttrs().isReg()) {
					// El origen no es un fichero (regular)
					LOGGER.warn("La ruta '" + ruta + "' en servidor sftp no es un archivo regular, lo ignoramos");
				} else {
					// Descargar fichero
				
					
				channel.rename(ruta, carpeta + "/READ_" + fichero.getFilename());
				}
			}
		} catch (SftpException e) {
			// TODO Auto-generated catch block
			LOGGER.error("Error tecnico renombrado", e);
		
		}
		
		// FIN
	
		
	}
	
	@Override
	public void uploadBinaryFiles(InputStream fichero, String destination,String nombre) throws SFTPException {
	
		// Validaciones
		ValidationsHelper.notEmpty("datos de entrada", "destination", destination);
		
		// Verificar que se est� conectado
		if ((channel == null) || !channel.isConnected()) {
		
			throw ExceptionsHelper.notConnectedError();
		}
		
		// Subir los ficheros
		
			if (fichero==null) {
	
				throw ExceptionsHelper.pathNonExistentError("local", null);
			}else {
			
			// Enviar el fichero
			try {
			if(fichero!=null)
				channel.put(fichero, destination+nombre);
			} catch (SftpException e) {
			
				throw ExceptionsHelper.communicationError(e);
			}
		}
			
	}
	
	
	@Override
	public void deleteFile(String file, String destination) throws SFTPException {
	
		// Validaciones
		ValidationsHelper.notEmpty("datos de entrada", "file", file);
		ValidationsHelper.notEmpty("datos de entrada", "destination", destination);
		
		// Verificar que se est� conectado
		if ((channel == null) || !channel.isConnected()) {
		
			throw ExceptionsHelper.notConnectedError();
		}
	//	List<String> files=repository.listingPattenObjectosBucket(config.getBucketName(),file);
		// Subir los ficheros
	//	for (String fichero: files) {
			// Comprobar que exista el fichero
			
			
			// Enviar el fichero
			try {
		
				channel.rm(destination+"/"+file);
			} catch (SftpException e) {
			
				throw ExceptionsHelper.communicationError(e);
			}
		//}
	}
	
}