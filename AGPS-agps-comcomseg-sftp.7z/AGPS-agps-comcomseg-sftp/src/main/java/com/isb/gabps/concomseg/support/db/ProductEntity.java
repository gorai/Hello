package com.isb.gabps.concomseg.support.db;

import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * Un registro de BBDD de la tabla de productos (seguros_conv_productos).
 * 
 * @author xIS08485
 */
public class ProductEntity {
	// Columnas de la tabla
	private String producto;
	private String coconcli;
	private String ctaDebe;
	private String ctaHaber;
	private String usuario;
	private LocalDateTime modif;
	
	
	
	/**
	 * Devuelve el producto.
	 * 
	 * @return Código del producto - CHAR(5)
	 */
	public String getProducto() {
		return producto;
	}
	
	/**
	 * Asigna el producto.
	 * 
	 * @param producto Código del producto - CHAR(5)
	 */
	public void setProducto(String producto) {
		this.producto = producto;
	}
	
	/**
	 * Devuelve el concepto de liquidación.
	 * 
	 * @return Concepto de liquidación
	 */
	public String getConcepLiquidacion() {
		return coconcli;
	}

	/**
	 * Devuelve el concepto de liquidación.
	 * 
	 * @param concepLiquidacion Concepto de liquidación
	 */
	public void setConcepLiquidacion(String concepLiquidacion) {
		this.coconcli = concepLiquidacion;
	}
	
	/**
	 * Devuelve la cuenta DEBE.
	 * 
	 * @return Número de cuenta DEBE
	 */
	public String getCtaDebe() {
		return ctaDebe;
	}
	
	/**
	 * Asigna la cuenta DEBE.
	 * 
	 * @param ctaDebe Número de cuenta DEBE
	 */
	public void setCtaDebe(String ctaDebe) {
		this.ctaDebe = ctaDebe;
	}
	
	/**
	 * Devuelve la cuenta HABER.
	 * 
	 * @return Número de cuenta HABER
	 */
	public String getCtaHaber() {
		return ctaHaber;
	}
	
	/**
	 * Asigna la cuenta HABER.
	 * 
	 * @param ctaHaber Número de cuenta HABER
	 */
	public void setCtaHaber(String ctaHaber) {
		this.ctaHaber = ctaHaber;
	}
	
	/**
	 * Devuelve el usuario.
	 * 
	 * @return Código del usuario - CHAR(30)
	 */
	public String getUsuario() {
		return usuario;
	}
	
	/**
	 * Asigna el usuario.
	 * 
	 * @param usuario Código del usuario - CHAR(30)
	 */
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	
	/**
	 * Devuelve la fecha de última modificación.
	 * 
	 * @return Fecha de última modificación - DATE
	 */
	public LocalDateTime getFechaModificacion() {
		return modif;
	}
	
	/**
	 * Asigna la fecha de última modificación.
	 * 
	 * @param fechaModificacion Fecha de última modificación - TIMESTAMP
	 */
	public void setFechaModificacion(LocalDateTime fechaModificacion) {
		this.modif = fechaModificacion;
	}
	
	/**
	 * Asigna la fecha de última modificación.
	 * 
	 * @param fechaModificacion Fecha de última modificación - TIMESTAMP
	 */
	public void setFechaModificacion(Timestamp fechaModificacion) {
		if (fechaModificacion == null) {
			setFechaModificacion((LocalDateTime)null);
		} else {
			setFechaModificacion(fechaModificacion.toLocalDateTime());
		}
	}
}
