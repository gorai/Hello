//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantaci�n de la referencia de enlace (JAXB) XML v2.3.0 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perder�n si se vuelve a compilar el esquema de origen. 
// Generado el: 2019.06.25 a las 12:23:50 PM CEST 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.tirea.es/EIAC/ProcesosEIAC", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.isb.gabps.concomseg.sftp.pojo;
