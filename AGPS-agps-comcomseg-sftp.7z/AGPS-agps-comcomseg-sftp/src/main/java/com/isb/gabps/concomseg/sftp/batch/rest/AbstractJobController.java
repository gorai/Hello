package com.isb.gabps.concomseg.sftp.batch.rest;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobExecutionNotRunningException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.NoSuchJobExecutionException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.isb.gabps.concomseg.sftp.batch.BatchGlobals;

import static com.isb.gabps.concomseg.sftp.batch.rest.ControllerGlobals.*;

/**
 * Clase padre del controller de un job, contiene las funcionalidades repetidas/comunes.
 * 
 * <ul>
 * <li>GET: Devuelve el estado del job
 * <li>POST: Ejecuta el job
 * <li>DELETE: Detiene un job en ejecución
 * </ul>
 * 
 * @author xIS08485
 */
public abstract class AbstractJobController {
	// Logger
	protected final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	
	// Locale del sistema
	private Locale locale = Locale.getDefault();
	
	// Textos del messages.properties
	@Autowired
	private MessageSource messages;
	
	// Beans del spring batch
	@Autowired
	private JobRepository repo;
	@Autowired
	private JobOperator jobOperator;
	@Autowired
	private JobLauncher launcher;
	
	// Configuración relativa al job (a ser definido por la clase hija)
	protected Job job = null;
	protected String jobPath = null;
	
	
	
	/**
	 * POST - Lanza el job, o retoma uno que no ha finalizado.
	 * 
	 * <p>
	 * Si el job está configurado en modo asíncrono (propiedad {@code app.feat.async}),
	 * devolverá el estado {@code STARTING} y hay que estar comprobando su estado a través del
	 * método GET.
	 * 
	 * @param date Fecha del fichero mensual a generar
	 * @param newCycle Crea una nueva ejecución del job si éste ya ha finalizado previamente
	 * @return Estado del job
	 */
	@PostMapping
	public String post(@PathVariable String date,
			@RequestParam(required=false, name=PARAM_REQUEST_CYCLE) boolean newCycle) {
		// Inicio
		String resultado;
		String path = jobPath.replace(PARAM_URL_DATE, date);
		LOGGER.info(String.format(TEMPLATE_LOG_REQUEST, "POST", path));
		
		// Creamos parámetros del job con la fecha y ciclo
		JobParameters params = buildJobParams(job, date);
		
		// Lanzamiento del job
		if (newCycle) {
			// Nuevo ciclo
			resultado = launchNewJob(job, params);
		} else {
			// Relanzamos el último ciclo
			resultado = launchJob(job, params);
		}
		
		// Fin
		LOGGER.info(String.format(TEMPLATE_LOG_RESPONSE, resultado));
		return resultado;
	}
	
	/**
	 * Devuelve el último estado del job.
	 * 
	 * @param date Fecha del job
	 * @return Estado del job
	 */
	@GetMapping
	public String get(@PathVariable String date) {
		// Inicio
		String resultado;
		String path = jobPath.replace(PARAM_URL_DATE, date);
		LOGGER.info(String.format(TEMPLATE_LOG_REQUEST, "GET", path));
		
		// Creamos parámetros del job con la fecha y ciclo
		JobParameters params = buildJobParams(job, date);
		LOGGER.info("JMLO "+params);
		// Buscar última ejecución del job y devolver su estado
		JobExecution lastJob = repo.getLastJobExecution(job.getName(), params);
		LOGGER.info("JMLO lastJob "+params);
		resultado = getJobMessage(lastJob);
		
		// Fin
		LOGGER.info(String.format(TEMPLATE_LOG_RESPONSE, resultado));
		return resultado;
	}
	
	/**
	 * Detiene un job que se encuentre en ejecución.
	 * 
	 * @param date Fecha del job
	 * @return Nuevo estado del job
	 */
	@DeleteMapping
	public String delete(@PathVariable String date) {
		// Inicio
		String resultado;
		String path = jobPath.replace(PARAM_URL_DATE, date);
		LOGGER.info(String.format(TEMPLATE_LOG_REQUEST, "DELETE", path));
		
		// Creamos parámetros del job con la fecha y ciclo
		JobParameters params = buildJobParams(job, date);
		
		// buscar job y detener
		resultado = stopJob(job, params);
		
		// Fin
		LOGGER.info(String.format(TEMPLATE_LOG_RESPONSE, resultado));
		return resultado;
	}
	
	
	
	/**
	 * Crea los parámetros del job con la fecha de entrada, luego busca la última ejecución de esta instancia del job.
	 * A los parámetros se añade el ciclo, para permitir crear una nueva instancia de un job terminado.
	 * Se devuelve los parámetros con el último ciclo encontrado (o primer ciclo si es nuevo).
	 * 
	 * @param job Job (para determinar el número de ciclo)
	 * @param date Fecha del job
	 * @return Parámetros del job (fecha + ciclo)
	 */
	private JobParameters buildJobParams(Job job, String date) {
		// Creamos parámetros del job con ciclo 1
		long ciclo = 1L;
		JobParametersBuilder builder = new JobParametersBuilder();
		builder.addString(BatchGlobals.JOB_PARAM_DATE, date);
		builder.addLong(BatchGlobals.JOB_PARAM_CYCLE, ciclo);
		JobParameters params = builder.toJobParameters();
		
		// Si ya existe, buscamos el último ciclo que exista
		JobParameters nextParams = params;
		while (repo.isJobInstanceExists(job.getName(), nextParams)) {
			params = nextParams;
			builder.addLong(BatchGlobals.JOB_PARAM_CYCLE, ++ciclo);
			nextParams = builder.toJobParameters();
		}
		
		// Devolver nuevos parámetros
		LOGGER.debug("Parámetros del job: " + params);
		return params;
	}
	
	/**
	 * Ejecuta el job con los parámetros recibidos de entrada, y controla todos los posibles
	 * errores devolviendo en la salida un string con el mensaje de error.
	 * 
	 * @param job Job a ejecutar
	 * @param params Parámetros del job a ejecutar
	 * @return Mensaje de ok/ko en formato '(estado):(mensaje)'
	 */
	private String launchJob(Job job, JobParameters params) {
		// Ejecutar job
		String resultado;
		try {
			// Lanzar el job
			LOGGER.debug("Lanzando ejecución del job: " + job.getName());
			resultado = getJobMessage(launcher.run(job, params));
		} catch (JobExecutionAlreadyRunningException e) {
			// Job en curso
			String messageKey = MESSAGES_REJECTED_PREFIX + "running";
			String backupMessage = String.format(TEMPLATE_NOT_FOUND, messageKey);
			resultado = String.format(TEMPLATE_RESPONSE, STATUS_REJECTED
					, messages.getMessage(messageKey, null, backupMessage, locale));
			LOGGER.warn("Job ya se encuentra en ejecución", e);
		} catch (JobRestartException e) {
			// Job abandonado o desconocido
			String messageKey = MESSAGES_REJECTED_PREFIX + "restart";
			String backupMessage = String.format(TEMPLATE_NOT_FOUND, messageKey);
			resultado = String.format(TEMPLATE_RESPONSE, STATUS_REJECTED
					, messages.getMessage(messageKey, null, backupMessage, locale));
			LOGGER.error("No se puede retomar el job en el estado actual", e);
		} catch (JobInstanceAlreadyCompleteException e) {
			// Job finalizado
			String messageKey = MESSAGES_REJECTED_PREFIX + "completed";
			String backupMessage = String.format(TEMPLATE_NOT_FOUND, messageKey);
			resultado = String.format(TEMPLATE_RESPONSE, STATUS_REJECTED
					, messages.getMessage(messageKey, null, backupMessage, locale));
			LOGGER.error("Job ya se encuentra completado", e);
		} catch (JobParametersInvalidException e) {
			// Error parámetros
			String messageKey = MESSAGES_REJECTED_PREFIX + "params";
			String backupMessage = String.format(TEMPLATE_NOT_FOUND, messageKey);
			resultado = String.format(TEMPLATE_RESPONSE, STATUS_REJECTED
					, messages.getMessage(messageKey, null, backupMessage, locale));
			LOGGER.error("Error validando parámetros del job", e);
		}
		
		// Devolver resultado
		return resultado;
	}
	
	/**
	 * Lanza el job en un nuevo ciclo de ejecución.
	 * 
	 * <p>
	 * De los parámetros del job, recupera el número de ciclo y lo incrementa.
	 * Al menos que esté nunca se haya lanzado o se encuentre en ejecución.
	 * 
	 * @param job Job a lanzar
	 * @param params Parámetros del job
	 * @return Estado del job
	 */
	private String launchNewJob(Job job, JobParameters params) {
		// Ver estado último job
		JobExecution lastJob = repo.getLastJobExecution(job.getName(), params);
		if ((lastJob != null) && !lastJob.isRunning() && !lastJob.isStopping()) {
			// Job existe y está parado, procedemos a lanzar nuevo ciclo
			LOGGER.debug("Creando nuevo ciclo del job");
			JobParametersBuilder builder = new JobParametersBuilder(params);
			long ciclo = params.getLong(BatchGlobals.JOB_PARAM_CYCLE);
			builder.addLong(BatchGlobals.JOB_PARAM_CYCLE, ciclo + 1L);
			return launchJob(job, builder.toJobParameters());
		} else {
			// Si el job es nuevo ya tendrá el ciclo 1, lo lanzamos
			
			// Si el job no es nuevo y está en ejecución, lo lanzamos de todas formas
			// y dejamos que sea el spring que decida que hacer, que debería lanzar
			// la excepción JobExecutionAlreadyRunningException
			LOGGER.warn("Job sin ejecución previa o se encuentra en curso");
			return launchJob(job, params);
		}
	}
	
	/**
	 * Busca la última ejecución de un job, y lo detiene.
	 * Si el job no se encuentra en ejecución, no modifica su estado.
	 * 
	 * @param job Job a detener
	 * @param params Parámetros del job
	 * @return Nuevo estado del job
	 */
	private String stopJob(Job job, JobParameters params) {
		// Mensaje a devolver
		String resultado;
		
		// Buscar job y parar
		JobExecution jobExec = repo.getLastJobExecution(job.getName(), params);
		if (jobExec == null) {
			// El job nunca se ha lanzado
			resultado = getJobMessage(null);
			LOGGER.error("Job no encontrado");
		} else {
			try {
				// Paramos el job
				LOGGER.debug("Deteniendo job: " + job.getName());
				jobOperator.stop(jobExec.getId());
				jobExec = repo.getLastJobExecution(job.getName(), params);
				resultado = getJobMessage(jobExec);
			} catch (NoSuchJobExecutionException e) {
				// El job nunca se ha lanzado, en teoría no debería ocurrir (porque jobExec sería nulo)
				String messageKey = MESSAGES_PREFIX + "not-found";
				String backupMessage = String.format(TEMPLATE_NOT_FOUND, messageKey);
				resultado = String.format(TEMPLATE_RESPONSE, STATUS_NOT_FOUND
						, messages.getMessage(messageKey, null, backupMessage, locale));
				LOGGER.error("Job no encontrado", e);
			} catch (JobExecutionNotRunningException e) {
				// Job ya parado
				String messageKey = MESSAGES_REJECTED_PREFIX + "not-running";
				String backupMessage = String.format(TEMPLATE_NOT_FOUND, messageKey);
				resultado = String.format(TEMPLATE_RESPONSE, STATUS_REJECTED
						, messages.getMessage(messageKey, null, backupMessage, locale));
				LOGGER.error("Job no está en curso", e);
			}
		}
		
		// Devolver mensaje
		return resultado;
	}
	
	/**
	 * Recupera el texto de la respuesta en el messages.properties.
	 * 
	 * @param jobExecution Ejecución del job
	 * @return Mensaje de texto encontrado (o su id si no existe)
	 */
	private String getJobMessage(JobExecution jobExecution) {
		// Mensaje a devolver
		LOGGER.debug("JMLO JobMessage, ");
		String resultado;
		if (jobExecution == null) {
			// Job nunca se ha ejecutado
			String messageKey = MESSAGES_PREFIX + "not-found";
			String backupMessage = String.format(TEMPLATE_NOT_FOUND, messageKey);
			LOGGER.debug("JMLO JobMessage, es null");
			resultado = String.format(TEMPLATE_RESPONSE, STATUS_NOT_FOUND
					, messages.getMessage(messageKey, null, backupMessage, locale));
			LOGGER.debug("JMLO JobMessage, "+resultado);
		} else {
			// Ver el resultado del job
			LOGGER.debug("JMLO JobMessage, No es null");
			ExecutionContext contexto = jobExecution.getExecutionContext();
			BatchStatus status = jobExecution.getStatus();
			LOGGER.debug("JMLO JobMessage, status"+status);
			if ((status == BatchStatus.FAILED) &&
					(contexto.containsKey(BatchGlobals.JOB_CTX_JOB_ACTION))) {
				LOGGER.debug("JMLO JobMessage, StatusFailed");
				// Job ko (generado por la aplicación)
				String messageKey = MESSAGES_FAILED_PREFIX
						+ contexto.getString(BatchGlobals.JOB_CTX_JOB_ACTION);
				String backupMessage = String.format(TEMPLATE_NOT_FOUND, messageKey);
				resultado = String.format(TEMPLATE_RESPONSE, status
						, messages.getMessage(messageKey, null, backupMessage, locale));
				LOGGER.debug("JMLO JobMessage, resultado"+resultado);
			} else {
				LOGGER.debug("JMLO JobMessage, Status no failed");
				// Para ko (por otro motivo) o cualquier otro estado 
				String messageKey = MESSAGES_PREFIX + status.toString().toLowerCase();
				String backupMessage = String.format(TEMPLATE_NOT_FOUND, messageKey);
				resultado = String.format(TEMPLATE_RESPONSE, status
						, messages.getMessage(messageKey, null, backupMessage, locale));
				LOGGER.debug("JMLO JobMessage, resultado"+resultado);
			}
		}
		
		// Devolver mensaje
		LOGGER.debug("Estado actual del job, " + resultado);
		return resultado;
	}
}
