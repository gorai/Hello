//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantaci?n de la referencia de enlace (JAXB) XML v2.3.0 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perder?n si se vuelve a compilar el esquema de origen. 
// Generado el: 2019.06.25 a las 12:23:50 PM CEST 
//


package com.isb.gabps.concomseg.sftp.pojo;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the javas package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: javas
     * 
     */
    public ObjectFactory() {
    }

    /**
     * @return ProcesosEIAC
     */
    public ProcesosEIAC createProcesosEIAC() {
        return new ProcesosEIAC();
    }

    /**
     * @return ProcesosEIAC.Objetos
     */
    public ProcesosEIAC.Objetos createProcesosEIACObjetos() {
        return new ProcesosEIAC.Objetos();
    }

    /**
     * @return ProcesosEIAC.Objetos.Recibo
     */
    public ProcesosEIAC.Objetos.Recibo createProcesosEIACObjetosRecibo() {
        return new ProcesosEIAC.Objetos.Recibo();
    }

    /**
     * @return ProcesosEIAC.Objetos.Recibo.DatosRecibo
     */
    public ProcesosEIAC.Objetos.Recibo.DatosRecibo createProcesosEIACObjetosReciboDatosRecibo() {
        return new ProcesosEIAC.Objetos.Recibo.DatosRecibo();
    }

    /**
     * @return ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones
     */
    public ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones createProcesosEIACObjetosReciboDatosReciboDatosComisiones() {
        return new ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones();
    }

    /**
     * @return ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes
     */
    public ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes createProcesosEIACObjetosReciboDatosReciboDatosImportes() {
        return new ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes();
    }

    /**
     * @return ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes
     */
    public ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes createProcesosEIACObjetosReciboDatosReciboDatosImportesImportes() {
        return new ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes();
    }

    /**
     * @return ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos
     */
    public ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos createProcesosEIACObjetosReciboDatosReciboDatosImportesImportesDatosCargos() {
        return new ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos();
    }

    /**
     * @return ProcesosEIAC.Cabecera
     */
    public ProcesosEIAC.Cabecera createProcesosEIACCabecera() {
        return new ProcesosEIAC.Cabecera();
    }

    /**
     * @return ProcesosEIAC.Cabecera.DatosProcesos
     */
    public ProcesosEIAC.Cabecera.DatosProcesos createProcesosEIACCabeceraDatosProcesos() {
        return new ProcesosEIAC.Cabecera.DatosProcesos();
    }

    /**
     * @return ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos
     */
    public ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos createProcesosEIACCabeceraDatosProcesosDetalleProcesos() {
        return new ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos();
    }

    /**
     * @return  ProcesosEIAC.Objetos.Recibo.DatosPoliza 
     */
    public ProcesosEIAC.Objetos.Recibo.DatosPoliza createProcesosEIACObjetosReciboDatosPoliza() {
        return new ProcesosEIAC.Objetos.Recibo.DatosPoliza();
    }

    /**
     * @return ProcesosEIAC.Objetos.Recibo.DatosRecibo.Fechas
     */
    public ProcesosEIAC.Objetos.Recibo.DatosRecibo.Fechas createProcesosEIACObjetosReciboDatosReciboFechas() {
        return new ProcesosEIAC.Objetos.Recibo.DatosRecibo.Fechas();
    }
    /**
     * @return ProcesosEIAC.Objetos.Recibo.DatosRecibo.GestionCobro
     */
    public ProcesosEIAC.Objetos.Recibo.DatosRecibo.GestionCobro createProcesosEIACObjetosReciboDatosReciboGestionCobro() {
        return new ProcesosEIAC.Objetos.Recibo.DatosRecibo.GestionCobro();
    }

    /**
     * @return ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones.Comision
     */
    public ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones.Comision createProcesosEIACObjetosReciboDatosReciboDatosComisionesComision() {
        return new ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosComisiones.Comision();
    }

    /**
     * @return ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos.Cargo
     */
    public ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos.Cargo createProcesosEIACObjetosReciboDatosReciboDatosImportesImportesDatosCargosCargo() {
        return new ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes.Importes.DatosCargos.Cargo();
    }

    /**
     * @return ProcesosEIAC.Cabecera.Emisor
     */
    public ProcesosEIAC.Cabecera.Emisor createProcesosEIACCabeceraEmisor() {
        return new ProcesosEIAC.Cabecera.Emisor();
    }

    /**
     * @return ProcesosEIAC.Cabecera.Receptor
     */
    public ProcesosEIAC.Cabecera.Receptor createProcesosEIACCabeceraReceptor() {
        return new ProcesosEIAC.Cabecera.Receptor();
    }

    /**
     * @return ProcesosEIAC.Cabecera.DatosLote
     */
    public ProcesosEIAC.Cabecera.DatosLote createProcesosEIACCabeceraDatosLote() {
        return new ProcesosEIAC.Cabecera.DatosLote();
    }

    /**
     * @return  ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos.DetalleProceso
     */
    public ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos.DetalleProceso createProcesosEIACCabeceraDatosProcesosDetalleProcesosDetalleProceso() {
        return new ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos.DetalleProceso();
    }

}
