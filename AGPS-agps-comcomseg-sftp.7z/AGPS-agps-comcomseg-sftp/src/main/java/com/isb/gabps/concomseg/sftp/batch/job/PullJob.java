package com.isb.gabps.concomseg.sftp.batch.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParametersValidator;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.isb.gabps.concomseg.sftp.batch.BatchGlobals;

/**
 * Configuración del job que descarga del servidor sftp los archivos de contabilidad
 * y luego fusiona los ficheros diarios en uno mensual.
 * 
 * @author xIS08485
 */
@Configuration
public class PullJob {
	// Para crear los jobs de esta configuración
	@Autowired
	private JobBuilderFactory jobs;
	
	// Para crear los steps de esta configuración
	@Autowired
    private StepBuilderFactory steps;
	
	/**
	 * Configura, crea y devuelve el job que se encarga de descargar los ficheros
	 * diarios del servidor sftp, y luego los fusiona en uno mensual.
	 * 
	 * @return La configuración del job
	 */
	@Bean(BatchGlobals.JOB_PULL_NAME)
	public Job pullFilesJob(@Qualifier(BatchGlobals.VALIDATOR_DATE)JobParametersValidator dateValidator
			, @Qualifier(BatchGlobals.LISTENER_WORKDIR) JobExecutionListener workdirListener
			, @Qualifier(BatchGlobals.STEP_DOWNLOAD) Step downloadStep
			, @Qualifier(BatchGlobals.STEP_MERGE_UNION) Step xmlUnionStep
			, @Qualifier(BatchGlobals.STEP_MERGE_JOIN) Step xmlJoinStep) {
		return jobs
				.get(BatchGlobals.JOB_PULL_NAME)
				.validator(dateValidator)
				.listener(workdirListener)
				.start(downloadStep)
				.next(xmlUnionStep)
				.next(xmlJoinStep)
				.build();
	}
	
	/**
	 * Crea el paso para la descarga de los ficheros diarios del servidor sftp.
	 * 
	 * @return La configuración del step
	 */
	@Bean(BatchGlobals.STEP_DOWNLOAD)
    protected Step downloadFilesStep(@Qualifier(BatchGlobals.TASKLET_DOWNLOAD) Tasklet tasklet) {
        return steps
        		.get(BatchGlobals.STEP_DOWNLOAD)
        		.tasklet(tasklet)
        		.build();
    }
	
	/**
	 * Crea el paso para la fusión de los XMLs diarios en uno mensual.
	 * 
	 * @return La configuración del step
	 */
	@Bean(BatchGlobals.STEP_MERGE_UNION)
    protected Step xmlUnionStep(@Qualifier(BatchGlobals.TASKLET_MERGE_UNION) Tasklet tasklet) {
        return steps
        		.get(BatchGlobals.STEP_MERGE_UNION)
        		.tasklet(tasklet)
        		.build();
    }
	
	/**
	 * Crea el paso para la fusión de los XMLs de pólizas y recibos en uno.
	 * 
	 * @return La configuración del step
	 */
	@Bean(BatchGlobals.STEP_MERGE_JOIN)
    protected Step xmlJoinStep(@Qualifier(BatchGlobals.TASKLET_MERGE_JOIN) Tasklet tasklet) {
        return steps
        		.get(BatchGlobals.STEP_MERGE_JOIN)
        		.tasklet(tasklet)
        		.build();
    }
}
