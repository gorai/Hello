package com.isb.gabps.concomseg.sftp.batch.rest;

import org.springframework.batch.core.Job;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isb.gabps.concomseg.sftp.batch.BatchGlobals;

/**
 * Controlador de servicios REST para gestionar el pull-files job, que se encarga
 * de descargar los ficheros del servidor sftp.
 * 
 * <p>
 * Más detalles del funcionamiento en {@link AbstractJobController}
 * 
 * @author xIS08485
 */
@RestController
@RequestMapping(ControllerGlobals.URL_PULL_JOB)
public class PullJobController extends AbstractJobController {
	/**
	 * Constructor
	 */
	public PullJobController() {
		this.jobPath = ControllerGlobals.URL_PULL_JOB;
	}
	
	/**
	 * Define el job asociado al controller.
	 * 
	 * @param job Job
	 */
	@Autowired
	@Qualifier(BatchGlobals.JOB_PULL_NAME)
	public void setJob(Job job) {
		this.job = job;
	}
}
