package com.isb.gabps.concomseg.sftp.health;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

import com.isb.gabps.concomseg.sftp.SFTPConfig;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

/**
 * Monitoriza si hay visibilidad con el servidor sftp.
 * 
 * @author xIS08485
 */
@Component
public class SFTPHealthIndicator implements HealthIndicator {
	// Logger
	private static final Logger LOGGER = LoggerFactory.getLogger(SFTPHealthIndicator.class);
	
	// Configuración (del properties)
	@Autowired
	private SFTPConfig config;
	
	// Libreria conexión ssh (clase principal)
	@Autowired
	private JSch ssh;
	
	/**
	 * Comproueba que se puede conectar al servidor sftp.
	 */
	@Override
	public Health health() {
		// Datos de conexión
		String server = config.getSFTPServer();
		int port = config.getSFTPPort();
		String login = config.getSFTPLogin();
		String secret = config.getSFTPSecret();
		
		try {
			// Iniciando conexión
			LOGGER.debug(String.format("Comprobando conexión con el servidor sftp: %s@%s:%d",
					login, server, port));
			Session session = ssh.getSession(login, server, port);
			session.setConfig("StrictHostKeyChecking", "no");
			session.setPassword(secret);
			session.connect();
			
			// Desconectando del servidor
			LOGGER.debug("Desconectando del servidor.");
			session.disconnect();
			
			// Prueba superada
			LOGGER.debug("Conexión al sftp es visible");
			return Health.up().build();
		} catch (JSchException e) {
			LOGGER.error("Error en comprobación del conexión al sftp.", e);
			return Health.down().withDetail("Cause", e.getMessage()).build();
		}
	}
}
