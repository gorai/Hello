package com.isb.gabps.concomseg.sftp;

/**
 * Excepcion generica de la aplicacion, dispone de campo adicional para definir el
 * tipo de excepcion (error de configuracion, error tecnico, etc).
 * 
 * @author xIS08485
 */
public class SFTPException extends Exception {
	// Version de la clase serial
	private static final long serialVersionUID = 1L;
	
	// Tipo de error (configuraci�n, t�cnico, etc)
	private final ERROR_TYPE errorType;
	
	// C�digo del error
	private final String errorCode;

	/**
	 * Tipo de errores permitidos
	 * 
	 * <ul>
	 * <li>INPUT_DATA_ERROR:</b> Relativos a errores en los datos de entrada</li>
	 * <li>CONFIGURATION_ERROR:</b> Relativos a los archivos de configuraci�n</li>
	 * <li>CONNECTION_ERROR:</b> Relativos a errores de conexi�n</li>
	 * <li>OPERATION_ERROR:</b> Relativos a errores funcionales en la ejecuci�n de una operaci�n</li>
	 * <li>TECHNICAL_ERROR:</b> Error t�cnico</li>
	 * <li>UNDEFINED_ERROR:</b> Error desconocido</li>
	 * </ul>
	 */
	public enum ERROR_TYPE {
			INPUT_DATA_ERROR,
			CONFIGURATION_ERROR,
			CONNECTION_ERROR,
			OPERATION_ERROR,
			TECHNICAL_ERROR,
			UNDEFINED_ERROR
	}
	
	
	
	/**
	 * Error provocado por la aplicacion.
	 * 
	 * @param errorType Tipo de error (CONFIGURATION_ERROR, TECHNICAL_ERROR, etc)
	 * @param errorCode Codigo del error
	 * @param message Mensaje del error 
	 * @see SFTPException.ERROR_TYPE
	 */
	public SFTPException(ERROR_TYPE errorType, String errorCode, String message) {
		this(errorType, errorCode, message, null);
	}
	
	/**
	 * Error provocado por una excepcion externa.
	 * 
	 * @param errorType Tipo de error (CONFIGURATION_ERROR, TECHNICAL_ERROR, etc)
	 * @param errorCode Codigo del error
	 * @param message Mensaje del error
	 * @param cause Excepcion que provoca el error 
	 * @see SFTPException.ERROR_TYPE
	 */
	public SFTPException(ERROR_TYPE errorType, String errorCode, String message, Throwable cause) {
		super(message, cause);
		this.errorType = errorType;
		this.errorCode = errorCode;
	}
	
	
	
	/**
	 * Devuelve el tipo de error (error de configuracion, error tecnico, etc).
	 * 
	 * @return Tipo de error
	 * @see SFTPException.ERROR_TYPE
	 */
	public ERROR_TYPE getErrorType() {
		return errorType;
	}
	
	/**
	 * Devuelve el codigo del error.
	 * 
	 * @return Codigo del error
	 */
	public String getErrorCode() {
		return errorCode;
	}
}
