package com.isb.gabps.concomseg.support.files;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
//package com.isb.gabps.concomseg.support.files;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.isb.conector.S3Repository;
import com.isb.conector.S3RepositoryImpl;
import com.isb.conector.S3RepositoryImplDummie;
import com.isb.gabps.concomseg.sftp.SFTPConfig;
import com.isb.gabps.concomseg.support.files.ListFilesResponse;

/**
 * Herramienta de desarrollo para la subida/baja de ficheros que se encuentran dentro del PaaS.
 * Para usarse requiere activar el perfil spring: dev-tools.
 * 
 * @author xIS08485
 *
 */
//@Profile("feat-files")
@RestController
@RequestMapping("/files")
public class FileManagerController {
	// Logger
	private static final Logger LOGGER = LoggerFactory.getLogger(FileManagerController.class);
	
	// Constantes
	private static final String PROP_PATH_PREFIX = "app.filesystem.path-";
	
	// Usamos environment en lugar de la propiedad final, porque la vamos a buscar din�micamente:
	// app.filesystem.(dato de entrada)
	@Autowired
	private Environment env;
	
	// Configuraci�n (del properties)
	@Autowired
	private SFTPConfig config;
	
	public S3Repository repositoryS3;
	
	public FileManagerController() {
		super();
	
		
	}
	
	/**
	 * Devuelve una lista de los ficheros en una carpeta determinada.
	 * 
	 * <p>
	 * A trav�s del ID de entrada, buscamos la ruta a la carpeta definida en el properties.
	 * La ruta buscada ser�: app.filesystem.path-(identificador de entrada).
	 * Por ejemplo: {@code app.filesystem.path-in} o {@code app.filesystem.path-out}
	 * 
	 * <p>
	 * URL acceso: GET .../files/{pathId}
	 * 
	 * @param pathId Identificador de la carpeta
	 * @return Una lista con los nombres de ficheros encontrados
	 */
	@GetMapping("{pathId}")
	public ListFilesResponse listFiles(@PathVariable String pathId) {
		ListFilesResponse response = new ListFilesResponse();
		if(repositoryS3==null)
		repositoryS3= config.getS3Repository(); //if(false)S3RepositoryImplDummie()S3RepositoryImpl()
	
	    List<String> listado=repositoryS3.listingPattenObjectosBucket(config.getBucketName(),pathId);
if(listado==null) {
	response.setResult("KO");
	return response;
}
else {
	 
	 for(int i=0;i<listado.size();i++) {
		 
		 response.getFilesList().add(listado.get(i));
		

	 }
	        
				response.setResult("OK");
				return response;
}

			}
		
	
	/**
	 * Sube un fichero a una carpeta determinada.
	 * 
	 * <p>
	 * A trav�s del ID de entrada, buscamos la ruta a la carpeta definida en el properties.
	 * La ruta buscada ser�: app.filesystem.path-(identificador de entrada).
	 * Por ejemplo: {@code app.filesystem.path-in} o {@code app.filesystem.path-out}
	 * 
	 * <p>
	 * URL acceso: POST .../files/{pathId}
	 * 
	 * @param pathId Identificador de la carpeta
	 * @param file Fichero a subir (formato multipart de un form http)
	 * @param overwrite Si {@code true}, sobreescribe el fichero en caso de ya existir con el mismo nombre
	 * @return OK/KO
	 */
	@PostMapping("{pathId}")
	public String putFile(@PathVariable String pathId,
			@RequestParam("file") MultipartFile file,
			@RequestParam(value = "overwrite", required = false) Boolean overwrite) {
		// Validar parametro id
		LOGGER.debug("JMLO DB Path");
		String valor = env.getProperty(PROP_PATH_PREFIX + pathId);
				
		// Crear carpeta si no existe
		
		
		// Validar parametro file
		if ((file == null) || (file.isEmpty())) {
			return "Parametro 'file' nulo o vacio";
		}
		
		// Validar nombre del fichero
		String nombre = file.getOriginalFilename();
				
		// Validar fichero
		
		
		
		try {
			repositoryS3.putToS3(file.getName(),config.getBucketName(), null,file.getBytes() , false,config.getBucketKms());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return "OK";
	}
	
	public boolean informado(String dato) {
		
		if ((dato!= null) && !dato.isEmpty()) 
			
			return true;
		else
			return false;
				
	}
	
	/**
	 * Devuelve un fichero de una carpeta determinada.
	 * 
	 * <p>
	 * A trav�s del ID de entrada, buscamos la ruta a la carpeta definida en el properties.
	 * La ruta buscada ser�: app.filesystem.path-(identificador de entrada).
	 * Por ejemplo: {@code app.filesystem.path-in} o {@code app.filesystem.path-out}
	 * 
	 * <p>
	 * URL acceso: GET .../files/{pathId}/{fileId}
	 * 
	 * @param pathId Identificador de la carpeta
	 * @param fileId Nombre del fichero
	 * @return Fichero encontrado (o descripci�n del error)
	 */
	@GetMapping("/fichero/{fileId}")
	public String getFile(@PathVariable String fileId) {
	
		
		if(repositoryS3==null)
			repositoryS3= config.getS3Repository(); //if(false)S3RepositoryImplDummie()S3RepositoryImpl()
		// Validar que carpeta est� definida en el properties
		
		// Validar que fichero exista en la carpeta
		if ((fileId == null) || (fileId.isEmpty())) {
			Resource error = new ByteArrayResource(("ERROR: La URL del recurso es incompleta").getBytes());
			return "Error en datos";
		}
		InputStream retorno=repositoryS3.getFromS3(fileId, config.getBucketName());
		String result ="";
   	 try {
   		 
		   	 result = IOUtils.toString(retorno, StandardCharsets.UTF_8);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
      
				// Fichero existe, devolverlo en la salida
	//	Resource contenido = new FileSystemResource(result);
		return result;
	}
	
	/**
	 * Devuelve un fichero de una carpeta determinada.
	 * 
	 * <p>
	 * A trav�s del ID de entrada, buscamos la ruta a la carpeta definida en el properties.
	 * La ruta buscada ser�: app.filesystem.path-(identificador de entrada).
	 * Por ejemplo: {@code app.filesystem.path-in} o {@code app.filesystem.path-out}
	 * 
	 * <p>
	 * URL acceso: GET .../files/borrado/{fileId}
	 * 
	 * @param pathId Identificador de la carpeta
	 * @param fileId Nombre del fichero
	 * @return Fichero encontrado (o descripci�n del error)
	 */
	@GetMapping("/borrado/{pattern}")
	public List <String> deleteFile(@PathVariable String pattern) {
	
			
		if(repositoryS3==null)
			repositoryS3= config.getS3Repository(); //if(false)S3RepositoryImplDummie()S3RepositoryImpl()
		// Validar que carpeta est� definida en el properties
		
		// Validar que fichero exista en la carpeta
		if ((pattern == null) || (pattern.isEmpty())) {
			Resource error = new ByteArrayResource(("ERROR: La URL del recurso es incompleta").getBytes());
			return new ArrayList<String>();
		}
		List<String> retorno=repositoryS3.deleteByPatter( config.getBucketName(),pattern);
				// Fichero existe, devolverlo en la salida
	//	Resource contenido = new FileSystemResource(result);
		return retorno;
	}
	
	
	/**
	 * Borra un fichero de una carpeta determinada.
	 * 
	 * <p>
	 * A trav�s del ID de entrada, buscamos la ruta a la carpeta definida en el properties.
	 * La ruta buscada ser�: app.filesystem.path-(identificador de entrada).
	 * Por ejemplo: {@code app.filesystem.path-in} o {@code app.filesystem.path-out}
	 * 
	 * <p>
	 * URL acceso: GET .../files/{pathId}/{fileId}
	 * 
	 * @param pathId Identificador de la carpeta
	 * @param fileId Nombre del fichero
	 * @return OK/KO
	 */
	@DeleteMapping("{pathId}/{fileId}")
	public String deleteFile(@PathVariable String pathId, @PathVariable String fileId) {
		LOGGER.debug("JMLO DB CPath");
		// Validar que carpeta est� definida en el properties
		if ((pathId == null) || (pathId.isEmpty())) {
			return "ERROR: La URL del recurso es incompleta";
		}
		String path = env.getProperty(PROP_PATH_PREFIX + pathId);
		if ((path == null) || (path.isEmpty())) {
			return "ERROR: No existe el recurso '" + pathId + "'";
		}
		
		// Validar que fichero exista en la carpeta
		if ((fileId == null) || (fileId.isEmpty())) {
			return "ERROR: La URL del recurso es incompleta";
		}
		File fichero = new File(path, fileId);
		if (!fichero.exists()) {
			return "ERROR: No existe el recurso '" + fileId + "'";
		}
		
		// Fichero existe, devolverlo en la salida
		if (fichero.delete()) {
			return "OK";
		} else {
			return "ERROR: Error t�cnico al borrar el fichero. ";
		}
	}
}
