package com.isb.gabps.concomseg.sftp.batch.step;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StringReader;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import org.junit.Test;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

import com.isb.gabps.concomseg.sftp.SFTPConfig;
import com.isb.gabps.concomseg.sftp.SFTPException;
import com.isb.gabps.concomseg.sftp.batch.BatchGlobals;
import com.isb.gabps.concomseg.sftp.pojo.ProcesosEIAC;
import com.isb.gabps.concomseg.sftp.pojo.ProcesosEIACPoliza;
import com.isb.gabps.concomseg.sftp.pojo.ProcesosEIAC.Objetos.Recibo;
import com.isb.gabps.concomseg.sftp.pojo.ProcesosEIACPoliza.Objetos.Poliza;
import com.isb.gabps.concomseg.sftp.pojo.ProcesosEIACPoliza.Objetos.Poliza.DatosPoliza;
import com.isb.gabps.concomseg.sftp.service.SFTPService;
import com.isb.gabps.concomseg.sftp.util.ExceptionsHelper;
import com.isb.gabps.concomseg.support.files.DatosPersonaJuridico;
import com.isb.gabps.concomseg.support.files.ListFilesResponse;
import com.jcraft.jsch.SftpException;





/**
 * Step para descargar los ficheros del servidor sftp al local.
 * 
 * @author xIS08485
 */
@Component(BatchGlobals.TASKLET_DOWNLOAD)
public class DownloadTasklet implements Tasklet {
	// Logger
	private static final Logger LOGGER = LoggerFactory.getLogger(DownloadTasklet.class);
	
	private String ficheroSalidaPlano="DatosPolizaPlano.txt";
	private String ficheroDaily="DatosDaily.txt";
	private String ficherosDiarios="FicherosDaily.txt";
	List<DatosPersonaJuridico> listaDatosPoliza =new ArrayList<>();
	private static final String PROP_PATH_PREFIX = "app.sftp.path-";

	List<String> ficherosDia =new ArrayList<>();
	
	@Autowired
	private Environment env;
	// Servicio para descargar los ficheros del servidor sftp
	@Autowired
	private SFTPService service;
	
	// Configuraci�n (del properties)
	@Autowired
	private SFTPConfig config;
	
	// Para reintenta abrir conexiones al servidor sftp si �ste falla 
	private RetryTemplate connectRetrier;
	
	/**
	 * Descarga los ficheros diarios de p�lizas y recibos del sftp al local.
	 * Adem�s guarda las rutas a estos ficheros para que sean tratados por steps posteriores.
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
	
		
		// Recuperamos fecha de ejecuci�n
		String fecha = (String)chunkContext.getStepContext().getJobParameters()
				.get(BatchGlobals.JOB_PARAM_DATE);
		LocalDate localDate = LocalDate.parse(fecha, DateTimeFormatter.BASIC_ISO_DATE);
		String mes = localDate.format(DateTimeFormatter.ofPattern("yyyyMM"));
		LOGGER.debug("Se descargar�n aquellos correspondientes al mes: " + mes);
		
		// Recuperamos el contexto de ejecuci�n, lo usaremos para guardar datos
		// de la ejecuci�n que usaremos en otras clases (como el id del job,
		// o el estado actual del proceso)
		StepExecution stepExec = chunkContext.getStepContext().getStepExecution();
		ExecutionContext contexto = stepExec.getJobExecution().getExecutionContext();
		
		// El job-id determina la ubicaci�n de los archivos temporales
		String jobId = contexto.getString(BatchGlobals.JOB_CTX_JOB_ID);
		//service.limpiaS3();
		// Nos conectamos al sftp
		// Usamos Spring Retry para reintentar varias veces la conexi�n
		contexto.putString(BatchGlobals.JOB_CTX_JOB_ACTION, BatchGlobals.ACTION_CONNECT);
		service.setTimeout(config.getConnectTimeout());
		connectRetrier = config.connectRetrier(stepExec.getJobExecutionId());
		connectRetrier.execute(retryContext -> {
			service.connect(config.getSFTPServer(), config.getSFTPPort(),
					config.getSFTPLogin(), config.getSFTPSecret());
		    return null;
		});
		contexto.remove(BatchGlobals.JOB_CTX_JOB_ACTION);
		
		
		
		// Descargamos los ficheros de p�lizas diarios
		// Solo descargaremos aquellos correspondientes al mes que estamos ejecutando
		contexto.putString(BatchGlobals.JOB_CTX_JOB_ACTION, BatchGlobals.ACTION_DOWNLOAD_POL);
		LOGGER.debug("Iniciando descarga de ficheros de p�lizas diarios");
		String workdir = config.getFSTempPath(jobId);//JMLOV1  Cambio a ruta FTP ///comisioneseguros/areaintercambio/ficherosUnion
		String rutaBusqueda = config.getSFTPInPath() + "/" + config.getSFTPInPoliciesPattern(mes);
 
		List<String> ficheros = service.downloadFiles(rutaBusqueda, workdir,mes);
		contexto.putInt(BatchGlobals.JOB_CTX_DOWNLOAD_POL, ficheros.size());
		if (ficheros.isEmpty()) {
					return RepeatStatus.FINISHED;
		}
	
		contexto.remove(BatchGlobals.JOB_CTX_JOB_ACTION);
		
		// Lo mismo pero para los ficheros de recibos
		contexto.putString(BatchGlobals.JOB_CTX_JOB_ACTION, BatchGlobals.ACTION_DOWNLOAD_COL);
		LOGGER.debug("Iniciando descarga de ficheros de recibos diarios");
		rutaBusqueda = config.getSFTPInPath() + "/" + config.getSFTPInCollectionsPattern(mes);
		ficheros = service.downloadFiles(rutaBusqueda, workdir,mes);
		contexto.putInt(BatchGlobals.JOB_CTX_DOWNLOAD_COL, ficheros.size());
		if (ficheros.isEmpty()) {
			LOGGER.debug("La b�squeda ha devuelto " + 0 + " recibos en el servidor sftp");
			throw ExceptionsHelper.resNotFoundError("servidor sftp", "recibos");
		}
		contexto.remove(BatchGlobals.JOB_CTX_JOB_ACTION);
		
		// Desconectando del servidor sftp
		LOGGER.debug("Finalizando conexi�n al servidor sftp.");	
	//	service.sftpRenameFiles(rutaBusqueda, workdir);
		service.disconnect();
		
		// FIN OK
		LOGGER.debug("Fin exitoso del step");
		
		exportDaily(fecha);
		
		
		
		return RepeatStatus.FINISHED;
	}
		
	public String exportDaily(String fecha) {
		
		ListFilesResponse response = new ListFilesResponse();
		listaDatosPoliza =new ArrayList<>();
		ficherosDia =new ArrayList<>();
	
				try {
					service.connect(config.getSFTPServer(), config.getSFTPPort(),
							config.getSFTPLogin(), config.getSFTPSecret());
					
				} catch (SFTPException e) {
					// TODO Auto-generated catch block
					response.setResult("Error al conectar a la base de datos");
					return "KO";			
			}
		obtenerFicherosDiarios(ficherosDiarios);	
		obtenerPlanos(ficheroDaily);		
		LOGGER.debug("JMLO DB File");
	
		String valor = env.getProperty(PROP_PATH_PREFIX + "in");
		if ((valor == null) || (valor.isEmpty())) {
			valor="in";	
		}
		Path ruta =Paths.get(valor);
		
		List<String>listaRutas =null;
		try {
			listaRutas = service.sftpListFiles(valor+"/*");
	/*BORRADO PARA GAP DE FICHEROS		
			for(int i=0; i<listaRutas.size();i++) {
				if(listaRutas.get(i).trim().equalsIgnoreCase("EIAC-ENV-E0189-0000099879-20211212064048-003.XML")||listaRutas.get(i).trim().equalsIgnoreCase("EIAC-ENV-E0189-0000099879-20211212060500-002.XML")) {
					listaRutas.remove(i);
					i=0;
				}
			}
				*/
		} catch (SftpException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
		}
		
		Collections.sort(listaRutas, new Comparator<String>() {
		    @Override
		    public int compare(String o1, String o2) {
		        return o1.compareTo(o2);
		    }
		});
	
		List<ProcesosEIAC> listaRecibos= new ArrayList<ProcesosEIAC>();
		List<ProcesosEIACPoliza> listaPolizas= new ArrayList<ProcesosEIACPoliza>();
		for(int i=0;i<listaRutas.size();i++) {
		
			if(existeDiario(listaRutas.get(i))|| !compruebaFormato(listaRutas.get(i))) {	
				continue;
				
			}else {
				
			String fichero=obtenerFicheroLocal(valor+"/"+listaRutas.get(i));
			if(fichero.contains("<Recibo>")) {
				JAXBContext jaxbContext;
				
				LOGGER.debug("FicheroEIACRECIBO  "+i+" "+listaRutas.size()+" "+listaRutas.get(i));				
				LOGGER.info("FicheroEIACRECIBO  "+i+" "+listaRutas.size()+" "+listaRutas.get(i));
				try
				{
				    jaxbContext = JAXBContext.newInstance(ProcesosEIAC.class);              
				 
				    Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
				 
				    ProcesosEIAC eiac = (ProcesosEIAC) jaxbUnmarshaller.unmarshal(new StringReader(fichero)); 			  
				    ficherosDia.add(listaRutas.get(i));
				    listaRecibos.add(eiac);
				//    int retorno=-1;
				//    if((retorno=listaRecibosEstaLista(eiac))>=0) {
				//    listaDatosPoliza.remove(retorno);
				   // obtenerDatosPersonaJuridicoDummie(eiac,listaRutas.get(i));
				  
				}
				catch (JAXBException e) 
				{
				
					LOGGER.debug("Fichero con error "+listaRutas.get(i));
					
					LOGGER.info("Fichero con error "+listaRutas.get(i));
				//    e.printStackTrace();
				}	
				
			
				continue;
			}
			else
			if(fichero.contains("<Poliza>")){
		//	fichero=fichero.substring(fichero.indexOf("\">")+3,fichero.length());
			JAXBContext jaxbContext;
			
			LOGGER.debug("FicheroEIAC "+i+" "+listaRutas.size()+" "+listaRutas.get(i));
		
			LOGGER.info("FicheroEIAC "+i+" "+listaRutas.size()+" "+listaRutas.get(i));
			
			try
			{
			    jaxbContext = JAXBContext.newInstance(ProcesosEIACPoliza.class);              
			
			    Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
				 
			    ProcesosEIACPoliza eiac = (ProcesosEIACPoliza) jaxbUnmarshaller.unmarshal(new StringReader(fichero));
		 

			    ficherosDia.add(listaRutas.get(i));
			    listaPolizas.add(eiac);
			//    obtenerDatosPersonaJuridico(eiac,listaRutas.get(i));
			    int posicion=-1;
			  
			}
			catch (JAXBException e) 
			{
				LOGGER.debug("Fichero con error "+listaRutas.get(i));		
				LOGGER.info("Fichero con error "+listaRutas.get(i));
			//    e.printStackTrace();
			}
			}
			}
		}
				
	//	List<DatosPersonaJuridico> listaJunta=juntarListas(listaPolizas,listaRecibos);
		for(int i=0; i<listaPolizas.size();i++) {
			List<Poliza> nuevaListaPoliza=listaPolizas.get(i).getObjetos().getPoliza();
			insertarPoliza(nuevaListaPoliza);
		}
		
		for(int i=0;i<listaRecibos.size();i++) {
			List<Recibo> nuevaListaRecibo= listaRecibos.get(i).getObjetos().getRecibo();
			
			insertarRecibo(nuevaListaRecibo);
		}
		String valorSalida = env.getProperty(PROP_PATH_PREFIX + "out")+"/";
		LOGGER.debug("Obtenemos los datos de base de datos");
		
		LOGGER.info("Obtenemos los datos de base de datos");	
	//	ByteArrayInputStream ficheroSalida=obtenerDatosBD();
		
		LOGGER.debug("JMLOBD Datos ya obtenidos");
		LOGGER.debug("JMLOBD Datos ya obtenidos");
		LOGGER.debug("JMLOBD Datos ya obtenidos");
		
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
		    ObjectOutputStream oos = new ObjectOutputStream(baos);
		  //  ordenarLista();
			for(int i=0;i<listaDatosPoliza.size();i++) {				
			    oos.writeObject(listaDatosPoliza.get(i));
			    oos.flush();
		}
			
			LOGGER.debug("JMLODEBUG SUBIDA FICHERO");
			
			LOGGER.info("JMLODEBUG SUBIDA FICHERO");
			
            oos.close();
            InputStream is = new ByteArrayInputStream(baos.toByteArray());
			service.uploadBinaryFiles(is, valorSalida,ficheroDaily);
		
			generarFicheroDiario();
			generarFicheroDiarioCompleto();
			generaFicheros();
			
			LOGGER.debug("JMLODEBUG SUBIDA FICHERO2");
			
			LOGGER.info("JMLODEBUG SUBIDA FICHERO2");
		} catch (IOException | SFTPException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
		LOGGER.debug("Datos ya obtenidos, enviamso");
		
		LOGGER.info("Datos ya obtenidos, enviamso");
		
		
		String nombreFichero="CONCOMSEG_REPORT";
		Date objDate = new Date(); // Sistema actual La fecha y la hora se asignan a objDate 
		 
  
        String strDateFormat = "yyyyMMdd"; // El formato de fecha est� especificado  
        SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); // La cadena de formato de fecha se pasa como un argumento al objeto 
        nombreFichero=nombreFichero+"_"+objSDF.format(objDate)+".csv";
    	LOGGER.debug("Datos ya obtenidos, enviamso2");
		
		LOGGER.info("Datos ya obtenidos, enviamso2");
     
		
	//	response.setFilesList(listaRutas);
        LOGGER.debug("salimosJMLO");
		
		LOGGER.info("salimosJMLO");
	    return "OK";

	
	}	
	
	public void obtenerFicherosDiarios(String fichero){
		
		String rutaFichero = env.getProperty(PROP_PATH_PREFIX + "out")+"/"+fichero;
		try {
		ByteArrayOutputStream ficheroPlano=	service.sftpDownloadFile(rutaFichero);
		if(ficheroPlano!=null) {
			
			ByteArrayInputStream bis = new ByteArrayInputStream(ficheroPlano.toByteArray());
	         ObjectInputStream in = new ObjectInputStream(bis);
	         
	         while (in.available()>=0) {
	         
	        	 String dato = (String) in.readObject();
	        	 ficherosDia.add(dato);
	        	 
	         }
			
		}
		} catch (SftpException | IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace();
		}
	}	
	
public void obtenerPlanos(String fichero){
		
		String rutaFichero = env.getProperty(PROP_PATH_PREFIX + "out")+"/"+fichero;
		try {
		ByteArrayOutputStream ficheroPlano=	service.sftpDownloadFile(rutaFichero);
		if(ficheroPlano!=null) {
			
			ByteArrayInputStream bis = new ByteArrayInputStream(ficheroPlano.toByteArray());
	         ObjectInputStream in = new ObjectInputStream(bis);
	         
	         while (in.available()>=0) {
	         
	        	 DatosPersonaJuridico dato = (DatosPersonaJuridico) in.readObject();
	           	 listaDatosPoliza.add(dato);
	        	 
	         }
			
		}
		} catch (SftpException | IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace();
		}
	}
public boolean existeDiario(String nombreFichero) {
	
	for(int i=0;i< ficherosDia.size();i++) {
		if(nombreFichero.equals(ficherosDia.get(i)))
			return true;
	}
	return false;
}
public boolean compruebaFormato(String nombre) {
	
	if(nombre.startsWith("EIAC-ENV-E0189")) 
		return true;
	else return false;
}

public  String  obtenerFicheroLocal(String ruta) {
	try {
	service.connect(config.getSFTPServer(), config.getSFTPPort(),
			config.getSFTPLogin(), config.getSFTPSecret());
} catch (SFTPException e) {
	// TODO Auto-generated catch block
}
try {
ByteArrayOutputStream salida = service.sftpDownloadFile(ruta);


return salida.toString();

} catch (SftpException e) {
String excep= e.getMessage();
return excep;

}


}
public void insertarPoliza(List<Poliza> listaPolizas) {
	try {
	for(int i=0;i<listaPolizas.size();i++) {
		
	
	String idPolizaNuevo=listaPolizas.get(i).getDatosPoliza().getIdPoliza();
	int numSuplementoNuevo=listaPolizas.get(i).getDatosPoliza().getNumeroSuplemento();
	int num=-1;
	
	if((num=estaPolizaLista(idPolizaNuevo,numSuplementoNuevo))>=0){
		
		
		DatosPersonaJuridico datoPersonaJuridico=actualizaDatoPersonaJuridicoPoliza(listaDatosPoliza.get(num), listaPolizas.get(i));
		listaDatosPoliza.set(num,  datoPersonaJuridico); 
	//	listaDatosPoliza.add(datoPersonaJuridico);
					
	}else {
		
		DatosPersonaJuridico datoPersonaJuridico=generaDatoPersonaJuridicoPoliza(listaPolizas.get(i));
		listaDatosPoliza.add(datoPersonaJuridico);
		
	}
	}
	}catch (Exception e) {
		LOGGER.error(e.toString());
	}

}

public void insertarRecibo(List<Recibo> listaRecibos) {
	try {
	for(int i=0;i<listaRecibos.size();i++) {
	
	String idReciboNuevo=listaRecibos.get(i).getDatosRecibo().getIdRecibo();
	
	String idPolizaNuevo=listaRecibos.get(i).getDatosPoliza().getIdPoliza();	
	
	if(listaRecibos.get(i)!=null &&(listaRecibos.get(i).getDatosPoliza()==null || listaRecibos.get(i).getDatosPoliza().getNumeroSuplemento()==null)) {
		DatosPersonaJuridico datoPersonaJuridico=generaDatoPersonaJuridicoRecibo(listaRecibos.get(i));
		listaDatosPoliza.add(datoPersonaJuridico);
	}else {

	int numSuplementoNuevo=listaRecibos.get(i).getDatosPoliza().getNumeroSuplemento();
	int num=-1;
 
	if((num=estaLista(idReciboNuevo,idPolizaNuevo,numSuplementoNuevo))>=0){
					
		DatosPersonaJuridico datoPersonaJuridico=actualizaDatoPersonaRecibo(listaDatosPoliza.get(num), listaRecibos.get(i));
		listaDatosPoliza.set(num, datoPersonaJuridico);
	//	listaDatosPoliza.add(datoPersonaJuridico);
					
	}else {
		
		DatosPersonaJuridico datoPersonaJuridico=generaDatoPersonaJuridicoRecibo(listaRecibos.get(i));
		listaDatosPoliza.add(datoPersonaJuridico);
		
	}
	}
	}
	}catch (Exception e) {
		LOGGER.error(e.getMessage());
	}

}

public boolean generarFicheroDiario() {
	
	   StringBuffer fichero= new StringBuffer();
	   StringBuffer ficheroTemp= new StringBuffer();
 	 String cabecera="idPoliza|numSuplemento|ramoDgs|ramoEntidad|descripcionRamo|modalidadRamo|situacionPoliza|clasePoliza|fechaSituacion|fechaEfectoInicial|fechaEfectoActual|fechaVencimiento|duracionPoliza|primaTotal|PrimaNeta|fraccionPago|iban|tipoIdentificacionTomador|idPersonaTomador|tipoIdentificacionAsegurado|idPersonaAsegurado|fechaAnulacion"+"\n";
 	// String cabecera="co_poliza|num_suplemento|co_mediador|co_producto|co_recibo|tip_documento|cod_documento|co_sit_recibo|co_tipo_recibo|co_period_pago|situacion_poliza|fecha_efecto_actual|prima_neta|prima_total|fecha_inicial|fecha_fin|fecha_emision"+"\n";

 	 String cabeceraRecibo="idPoliza|numSuplemento|idRecibo|situacionRecibo|periodo|claseRecibo|fechaSituacion|fechaEfectoInicial|fechaEfectoActual|fechaVencimiento|fechaEmision|primaTotal|primaNeta\n";
 	 
 	 StringBuffer ficheroRecibo= new StringBuffer();
 	 ficheroRecibo.append(cabeceraRecibo);
 	 fichero.append(cabecera);
 	 ficheroTemp.append(cabecera);
 	 NumberFormat formatter = new DecimalFormat("+#000000000000000.00;-#000000000000000.00");     

 	 for (int i = 0; i <listaDatosPoliza.size(); i++) {
     	 String linea="";
     	 String lineaRecibo="";
  
     	 linea+=listaDatosPoliza.get(i).getNumPoliza()+"|";
     	 linea+=listaDatosPoliza.get(i).getNumeroSuplemento()+"|";
     	 linea+=listaDatosPoliza.get(i).getRamoDGS()+"|";
   
     	 linea+=listaDatosPoliza.get(i).getRamoEntidad()+"|";
     	 linea+=listaDatosPoliza.get(i).getDescripcionRamo()+"|";
     	 linea+=listaDatosPoliza.get(i).getModalidadRamo()+"|";
     	 linea+=listaDatosPoliza.get(i).getSituacionPoliza()+"|";
     	 linea+=listaDatosPoliza.get(i).getClasePoliza()+"|";
     	
     	if(listaDatosPoliza.get(i).getPolizaFechaSituacion()==null)
    		 linea+=""+"|";
     		else {
    			 linea+=listaDatosPoliza.get(i).getPolizaFechaSituacion().substring(0,10)+"|";
    	}
    	if(listaDatosPoliza.get(i).getPolizaFechaEmision()==null)
    		 linea+=""+"|";
    		else {
    			 linea+=listaDatosPoliza.get(i).getPolizaFechaEmision().substring(0,10)+"|";
    	}   	     	
        if(listaDatosPoliza.get(i).getPolizaFechaEfectoActual()==null)
    		 linea+=""+"|";
        	else {
    			 linea+=listaDatosPoliza.get(i).getPolizaFechaEfectoActual().substring(0,10)+"|";
    	}
         if(listaDatosPoliza.get(i).getPolizaFechaVencimiento()==null)
    		  linea+=""+"|";
         	else {
    		     linea+=listaDatosPoliza.get(i).getPolizaFechaVencimiento().substring(0,10)+"|";
    	}   	
       
		 linea+=listaDatosPoliza.get(i).getDuracionPoliza()+"|";

		 if(listaDatosPoliza.get(i).getImporteRecibo()==null)
	     		linea+=""+"|";
		 	else {
		 		linea+=listaDatosPoliza.get(i).getImporteRecibo().replace(".", ",")+"|"; 
	     }
		 
		 if(listaDatosPoliza.get(i).getPrimaNeta()==null)
	     		linea+=""+"|";
		 else {
	     	linea+=listaDatosPoliza.get(i).getPrimaNeta().replace(".", ",")+"|"; 
	     }
		 if(listaDatosPoliza.get(i).getFraccionPago()==null)
			 linea+=""+"|";
		 else
			 linea+=listaDatosPoliza.get(i).getFraccionPago()+"|";
		 
		 if(listaDatosPoliza.get(i).getIban()==null)
				 linea+="|";
		 else
			 linea+=listaDatosPoliza.get(i).getIban()+"|";
		 
		 if(listaDatosPoliza.get(i).getTipoTomador()==null)
			 linea+="|";
		 else
			 linea+=listaDatosPoliza.get(i).getTipoTomador()+"|";
		 
		 if(listaDatosPoliza.get(i).getDatoTomador()==null)
			 linea+="|";
		 else
			 linea+=listaDatosPoliza.get(i).getDatoTomador()+"|";
		 
		 if(listaDatosPoliza.get(i).getTipoAsegurado()==null)
			 linea+="|";
		 else
			 linea+=listaDatosPoliza.get(i).getTipoAsegurado()+"|";
		 
		 if(listaDatosPoliza.get(i).getDatoAsegurado()==null)
			 linea+="|";
		 else
			 linea+=listaDatosPoliza.get(i).getDatoAsegurado()+"|";
		 
		  if(listaDatosPoliza.get(i).getFechaAnulacion()==null)
	    		 linea+=""+"\n";else {
	    			 linea+=listaDatosPoliza.get(i).getFechaAnulacion().substring(0,10)+"\n";
	    		 }   
		 	 
		 lineaRecibo=listaDatosPoliza.get(i).getNumPoliza()+"|";
		 lineaRecibo+=listaDatosPoliza.get(i).getNumeroSuplemento()+"|";
		 lineaRecibo+=listaDatosPoliza.get(i).getRecibo()+"|";
		 lineaRecibo+=listaDatosPoliza.get(i).getSitRecibo()+"|";
		 lineaRecibo+=listaDatosPoliza.get(i).getPeridoPago()+"|";
		 lineaRecibo+=listaDatosPoliza.get(i).getClaseRecibo()+"|";
		
		 
		 if(listaDatosPoliza.get(i).getFechaSituacion()==null)
			 lineaRecibo+=""+"|";else {
				 lineaRecibo+=listaDatosPoliza.get(i).getFechaSituacion().substring(0,10)+"|";
    		 }
		 
		 if(listaDatosPoliza.get(i).getFecInicioPoliza()==null)
			 lineaRecibo+=""+"|";else {
				 lineaRecibo+=listaDatosPoliza.get(i).getFecInicioPoliza().substring(0,10)+"|";
    		 }
		 if(listaDatosPoliza.get(i).getFechaEfectoActual()==null)
			 lineaRecibo+=""+"|";else {
				 lineaRecibo+=listaDatosPoliza.get(i).getFechaEfectoActual().substring(0,10)+"|";
    		 }
		 if(listaDatosPoliza.get(i).getFecFinSeg()==null)
			 lineaRecibo+=""+"|";else {
				 lineaRecibo+=listaDatosPoliza.get(i).getFecFinSeg().substring(0,10)+"|";
    		 }
		 if(listaDatosPoliza.get(i).getFechaEmision()==null)
			 lineaRecibo+=""+"|";else {
				 lineaRecibo+=listaDatosPoliza.get(i).getFechaEmision().substring(0,10)+"|";
    		 }
		 
		 if(listaDatosPoliza.get(i).getImporteRecibo()==null)
			 lineaRecibo+=""+"|";else {
				 lineaRecibo+=listaDatosPoliza.get(i).getImporteRecibo().replace(".", ",")+"|"; 
	     		}
		 
		 if(listaDatosPoliza.get(i).getPrimaNeta()==null)
			 lineaRecibo+=""+"\n";else {
				 lineaRecibo+=listaDatosPoliza.get(i).getPrimaNeta().replace(".", ",")+"\n"; 
	     		}
		 
		 
		 
     
     	// if(listaDatosPoliza.get(i).getStatus().trim().equalsIgnoreCase(""))
     	 fichero.append(linea);
     	 ficheroTemp.append(cambiaLinea(linea));
     	 if(!(listaDatosPoliza.get(i).getRecibo()==null) && listaDatosPoliza.get(i).getRecibo().trim().length()>0)
     	ficheroRecibo.append(lineaRecibo);
     	 
      }
      String valorSalida = env.getProperty(PROP_PATH_PREFIX + "out")+"/";
      
      String nombreFichero="CONCOMSEG_REPORT_DOC_POL";
      String nombreFicheroRecibo="CONCOMSEG_REPORT_DOC_REC";
      String nombreFicheroTemp="TEMP_CONCOMSEG_REPORT_DOC";
		Date objDate = new Date(); // Sistema actual La fecha y la hora se asignan a objDate 
		 

      String strDateFormat = "yyyyMMdd"; // El formato de fecha est� especificado  
      SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); // La cadena de formato de fecha se pasa como un argumento al objeto 
      nombreFichero=nombreFichero+"_"+objSDF.format(objDate)+".csv";
      nombreFicheroRecibo=nombreFicheroRecibo+"_"+objSDF.format(objDate)+".csv";
      nombreFicheroTemp=nombreFicheroTemp+"_"+objSDF.format(objDate)+".csv";
	/*		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		    ObjectOutputStream oos;
			try {
				oos = new ObjectOutputStream(baos);
				oos.write(fichero.toString().getBytes());
			    oos.flush();
			
			    oos.close();*/
			    InputStream is = new ByteArrayInputStream( fichero.toString().getBytes());
			    InputStream isRecibo = new ByteArrayInputStream( ficheroRecibo.toString().getBytes());
			   InputStream isTemp = new ByteArrayInputStream( ficheroTemp.toString().getBytes());
			
			try {
				service.uploadBinaryFiles(is, valorSalida,nombreFichero);
				service.uploadBinaryFiles(isRecibo, valorSalida,nombreFicheroRecibo);
				service.uploadBinaryFiles(isTemp, valorSalida,nombreFicheroTemp);
				return true;
			} catch (SFTPException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
			
			
 
		  //  ordenarLista();		
}



public void generarFicheroDiarioCompleto() {
	
 StringBuffer fichero= new StringBuffer();
 StringBuffer ficheroTemp= new StringBuffer();
 String cabecera="co_poliza|num_suplemento|co_mediador|co_producto|co_recibo|tip_documento|cod_documento|co_sit_recibo|co_tipo_recibo|co_period_pago|situacion_poliza|fecha_efecto_actual|prima_neta|prima_total|fecha_inicial|fecha_fin|fecha_emision|fechaAnulacion"+"\n";
 fichero.append(cabecera);
 ficheroTemp.append(cabecera);
 NumberFormat formatter = new DecimalFormat("+#000000000000000.00;-#000000000000000.00");     

   for (int i = 0; i <listaDatosPoliza.size(); i++) {
  	 String linea="";
//if(listaDatosPoliza.get(i).getNumPoliza().contains("119659647"))
	//System.out.println("dentro 119659647");
  	 linea+=listaDatosPoliza.get(i).getNumPoliza()+"|";
  	 linea+=listaDatosPoliza.get(i).getNumeroSuplemento()+"|";
  	 if(listaDatosPoliza.get(i).getMediador()!=null)
  	 linea+=listaDatosPoliza.get(i).getMediador()+"|";
  	 else
  		 linea+=""+"|";
  	 String prod=listaDatosPoliza.get(i).getProducto();
  	 if(prod!=null && prod.contains(" "))
  		 prod=prod.substring(0,prod.indexOf(" "));
  	 if (prod==null)
  		 prod="";
  	 linea+=prod+"|";
  	 linea+=listaDatosPoliza.get(i).getRecibo()+"|";
  	 linea+=listaDatosPoliza.get(i).getTipoDoc()+"|";
  	 linea+=listaDatosPoliza.get(i).getCodDoc()+"|";
  	 if(listaDatosPoliza.get(i).getSitRecibo()!=null)
  		 linea+=listaDatosPoliza.get(i).getSitRecibo()+"|";
  	 else
  		 linea+=""+"|";
  	 if(listaDatosPoliza.get(i).getTipoRecibo()!=null)
  		 linea+=listaDatosPoliza.get(i).getTipoRecibo()+"|";
  	 else
  		 linea+=""+"|";
  	 if(listaDatosPoliza.get(i).getPeridoPago()!=null)
  	 linea+=listaDatosPoliza.get(i).getPeridoPago()+"|";
  	 else
  		 linea+=""+"|";
  	// linea+=listaDatosPoliza.get(i).getStatus()+"\n";
  	 if(listaDatosPoliza.get(i).getSituacionPoliza()==null)
  		 linea+=""+"|";else
  	 linea+=listaDatosPoliza.get(i).getSituacionPoliza()+"|";
  	 if(listaDatosPoliza.get(i).getFechaEfectoActual()==null)
  		 linea+=""+"|";else
  			 linea+=listaDatosPoliza.get(i).getFechaEfectoActual().substring(0,10)+"|";
  	 if(listaDatosPoliza.get(i).getPrimaNeta()==null)
  		linea+=""+"|";else
  	 linea+=listaDatosPoliza.get(i).getPrimaNeta()+"|";//.replace(".", ",")
  	 
  	if(listaDatosPoliza.get(i).getImporteRecibo()==null)
  		linea+=""+"|";else
  	 linea+=listaDatosPoliza.get(i).getImporteRecibo()+"|";//.replace(".", ",")
  	
  	 if(listaDatosPoliza.get(i).getPolizaFechaEfectoActual()==null)
  		 linea+=""+"|";else
  			 linea+=listaDatosPoliza.get(i).getPolizaFechaEfectoActual().substring(0,10)+"|";
  	
  	 if(listaDatosPoliza.get(i).getPolizaFechaVencimiento()==null)
  		 linea+=""+"|";else
  			 linea+=listaDatosPoliza.get(i).getPolizaFechaVencimiento().substring(0,10)+"|";
  	
  	 if(listaDatosPoliza.get(i).getPolizaFechaEmision()==null)
  		 linea+="|";else
  			 linea+=listaDatosPoliza.get(i).getPolizaFechaEmision().substring(0,10)+"|";
  	
  	  if(listaDatosPoliza.get(i).getFechaAnulacion()==null)
 		 linea+=""+"\n";else {
 			 linea+=listaDatosPoliza.get(i).getFechaAnulacion().substring(0,10)+"\n";
 		 }   
  	 
  	 
  	// if(listaDatosPoliza.get(i).getStatus().trim().equalsIgnoreCase(""))
  	 fichero.append(linea);
  	 ficheroTemp.append(cambiaLinea(linea));
  	
  	 
   }
   String valorSalida = env.getProperty(PROP_PATH_PREFIX + "out")+"/";
   
   String nombreFichero="CONCOMSEG_REPORT_DOC";
   String nombreFicheroTemp="TEMP_CONCOMSEG_REPORT_DOC";
		Date objDate = new Date(); // Sistema actual La fecha y la hora se asignan a objDate 
		 

   String strDateFormat = "yyyyMMdd"; // El formato de fecha está especificado  
   SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); // La cadena de formato de fecha se pasa como un argumento al objeto 
   nombreFichero=nombreFichero+"_"+objSDF.format(objDate)+".csv";
   nombreFicheroTemp=nombreFicheroTemp+"_"+objSDF.format(objDate)+".csv";
	/*		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		    ObjectOutputStream oos;
			try {
				oos = new ObjectOutputStream(baos);
				oos.write(fichero.toString().getBytes());
			    oos.flush();
			
			    oos.close();*/
			    InputStream is = new ByteArrayInputStream( fichero.toString().getBytes());
			   InputStream isTemp = new ByteArrayInputStream( ficheroTemp.toString().getBytes());
			
			try {
				service.uploadBinaryFiles(is, valorSalida,nombreFichero);
				service.uploadBinaryFiles(isTemp, valorSalida,nombreFicheroTemp);
			} catch (SFTPException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			

		  //  ordenarLista();		
}

public void generaFicheros() {
	
	
	try {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    ObjectOutputStream oos = new ObjectOutputStream(baos);
	  //  ordenarLista();
		for(int i=0;i<ficherosDia.size();i++) {				
		    oos.writeObject(ficherosDia.get(i));
		    oos.flush();
	}
		
		LOGGER.debug("JMLODEBUG SUBIDA FICHERO");
		
		LOGGER.info("JMLODEBUG SUBIDA FICHERO");
		
        oos.close();
        InputStream is = new ByteArrayInputStream(baos.toByteArray());
    	String valorSalida = env.getProperty(PROP_PATH_PREFIX + "out")+"/";
		service.uploadBinaryFiles(is, valorSalida,ficherosDiarios);
		
	
		
		LOGGER.debug("JMLODEBUG SUBIDA FICHERO2");
		
		LOGGER.info("JMLODEBUG SUBIDA FICHERO2");
	} catch (IOException | SFTPException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
}
public DatosPersonaJuridico actualizaDatoPersonaJuridicoPoliza(DatosPersonaJuridico datosPersonaJuridico,Poliza poliza) {
	
	
	try {
	
	datosPersonaJuridico.setnumPoliza(poliza.getDatosPoliza().getIdPoliza());
	datosPersonaJuridico.setNumeroSuplemento(poliza.getDatosPoliza().getNumeroSuplemento());
	datosPersonaJuridico.setMediador(poliza.getDatosPoliza().getDatosMediador().getIdMediador().getCodigoInterno());
	datosPersonaJuridico.setProducto(poliza.getDatosPoliza().getRamo().getModalidadRamo());
	

	if(poliza.getTomador()!=null && poliza.getTomador().getPersonaFisica()!=null) {
	datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaFisica().getTipoIdentificacion());
	datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaFisica().getIdPersona());
	}
	else 	if(poliza.getTitular()!=null) {
		datosPersonaJuridico.setTipoDoc(poliza.getTitular().getPersonaFisica().getTipoIdentificacion());
		datosPersonaJuridico.setCodDoc(poliza.getTitular().getPersonaFisica().getIdPersona());
	}
	else if(poliza.getTomador()!=null && poliza.getTomador().getPersonaJuridica()!=null){
		datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaJuridica().getTipoIdentificacion());
		datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaJuridica().getIdPersona());
	}
	else
	{
		datosPersonaJuridico.setTipoDoc("");
		datosPersonaJuridico.setCodDoc("");
	}
	
	datosPersonaJuridico.setPeridoPago(poliza.getFraccionPago());

	}catch(Exception e){
		LOGGER.error(e.toString());
	}
	return datosPersonaJuridico;
}



public DatosPersonaJuridico generaDatoPersonaJuridico(Poliza poliza) {
	
	DatosPersonaJuridico datosPersonaJuridico= new DatosPersonaJuridico();
	try {
	
	datosPersonaJuridico.setnumPoliza(poliza.getDatosPoliza().getIdPoliza());
	datosPersonaJuridico.setMediador(poliza.getDatosPoliza().getDatosMediador().getIdMediador().getCodigoInterno());
	datosPersonaJuridico.setProducto(poliza.getDatosPoliza().getRamo().getModalidadRamo());
	datosPersonaJuridico.setRecibo("");
	
	if(poliza.getTomador()!=null && poliza.getTomador().getPersonaFisica()!=null) {
	datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaFisica().getTipoIdentificacion());
	datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaFisica().getIdPersona());
	}
	else 	if(poliza.getTitular()!=null) {
		datosPersonaJuridico.setTipoDoc(poliza.getTitular().getPersonaFisica().getTipoIdentificacion());
		datosPersonaJuridico.setCodDoc(poliza.getTitular().getPersonaFisica().getIdPersona());
	}
	else if(poliza.getTomador()!=null && poliza.getTomador().getPersonaJuridica()!=null){
		datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaJuridica().getTipoIdentificacion());
		datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaJuridica().getIdPersona());
	}
	else
	{
		datosPersonaJuridico.setTipoDoc("");
		datosPersonaJuridico.setCodDoc("");
	}
	datosPersonaJuridico.setSitRecibo("");
	datosPersonaJuridico.setTipoRecibo("");
	datosPersonaJuridico.setPeridoPago(poliza.getFraccionPago());
	datosPersonaJuridico.setSitPoliza(poliza.getSituacionPoliza());

	}catch(Exception e){
		LOGGER.error(e.toString());
	}
	return datosPersonaJuridico;
}


public List<DatosPersonaJuridico> juntarListas(List<ProcesosEIACPoliza> listaPolizas,List<ProcesosEIAC> listaRecibos){
	
	 List<DatosPersonaJuridico> listaJunta=new ArrayList<DatosPersonaJuridico>();
	 boolean insertado=false;
	 for(int i=0; i<listaRecibos.size();i++) {
		 
		 List<Recibo> listaSubrecibo=listaRecibos.get(i).getObjetos().getRecibo();
		 
		 for(int j=0; j<listaSubrecibo.size();j++) {
			 insertado=false;
			 String idPoliza=listaSubrecibo.get(j).getDatosPoliza().getIdPoliza().trim();
			 for(int k=0;k<listaPolizas.size();k++) {
				 
				 List<Poliza> listaSubPolizas=listaPolizas.get(k).getObjetos().getPoliza();
				 
				 for(int l=0; l<listaSubPolizas.size();l++) {
					 
					 if(idPoliza.equals(listaSubPolizas.get(l).getDatosPoliza().getIdPoliza().trim())) {
						 DatosPersonaJuridico datoPersonaJuridico= generaDatoPersonaJuridico(listaSubPolizas.get(l),listaSubrecibo.get(j));
						
						 listaJunta.add(datoPersonaJuridico);
						 insertado=true;
					 }
				 }
				 
			 }
			 if(insertado==false) {
					
				 DatosPersonaJuridico datoPersonaJuridico= obtenPoliza(listaSubrecibo.get(j));
				 if(datoPersonaJuridico!=null)
					 listaJunta.add(datoPersonaJuridico);

			 }
		 }
		 
		 
	 }
	 boolean esta=false;
	 
	 for(int k=0;k<listaPolizas.size();k++) {
		 
		 List<Poliza> listaSubPolizas=listaPolizas.get(k).getObjetos().getPoliza();
		 
		 for(int l=0; l<listaSubPolizas.size();l++) {
			 esta=false;
			 
			 	for(int m=0;m<listaJunta.size();m++) {
			 		
			 	if(listaJunta.get(m).getNumPoliza().equals(listaSubPolizas.get(l).getDatosPoliza().getIdPoliza())) {
			 		esta=true;
			 		break;
				
			 	}
			 }
			 	if(esta==false) {
			 		
			DatosPersonaJuridico datoPoliza=generaDatoPersonaJuridico(listaSubPolizas.get(l));
			listaDatosPoliza.add(datoPoliza);
			 }
    	}
		 
	 }
 
	 return listaJunta;
	
}

public DatosPersonaJuridico obtenPoliza(Recibo recibo) {
	
	
	for (int i=0;i<listaDatosPoliza.size();i++) {
		if(listaDatosPoliza.get(i).getRecibo().equals(recibo.getDatosRecibo().getIdRecibo())){
			
			DatosPersonaJuridico datos= new DatosPersonaJuridico();
			datos=listaDatosPoliza.get(i);
			datos.setSitRecibo(recibo.getDatosRecibo().getSituacionRecibo());
			datos.setNumeroSuplemento(recibo.getDatosPoliza().getNumeroSuplemento());
			datos.setTipoRecibo(recibo.getDatosRecibo().getClaseRecibo());
			datos.setFechaEfectoActual(recibo.getDatosRecibo().getFechas().getFechaEfectoActual().toString());
			BigDecimal primaNeta=recibo.getDatosRecibo().getDatosImportes().getImportes().getPrimaNeta();
			String strPrimaNeta=String.valueOf(primaNeta);
			datos.setPrimaNeta(strPrimaNeta);
			
			return datos;
		}
	}
	return null;
}

public int estaPolizaLista(String idPolizaNuevo,int numSuplementoNuevo) {
	
	int retorno=-1;
	try {
	
	for (int i=0;i<listaDatosPoliza.size();i++) {
			if(listaDatosPoliza.get(i).getNumPoliza().equals(idPolizaNuevo)) {
				if(listaDatosPoliza.get(i).getNumeroSuplemento()==numSuplementoNuevo) 
				return i;		
			}
		}
	}catch(Exception e) {
		LOGGER.error(e.toString());
	}
	
	return retorno;
}

public DatosPersonaJuridico generaDatoPersonaJuridicoPoliza(Poliza poliza) {
	
	DatosPersonaJuridico datosPersonaJuridico= new DatosPersonaJuridico();
	try {
	
	datosPersonaJuridico.setnumPoliza(poliza.getDatosPoliza().getIdPoliza());
	if(poliza.getDatosAnulacion()!=null)
		datosPersonaJuridico.setFechaAnulacion(poliza.getDatosAnulacion().getFechaAnulacion());
	datosPersonaJuridico.setNumeroSuplemento(poliza.getDatosPoliza().getNumeroSuplemento());
	datosPersonaJuridico.setMediador(poliza.getDatosPoliza().getDatosMediador().getIdMediador().getCodigoInterno());
	datosPersonaJuridico.setProducto(poliza.getDatosPoliza().getRamo().getModalidadRamo());
	
	datosPersonaJuridico.setDescripcionRamo(poliza.getDatosPoliza().getRamo().getDescripcionRamo());
	datosPersonaJuridico.setModalidadRamo(poliza.getDatosPoliza().getRamo().getModalidadRamo());
	datosPersonaJuridico.setRamoEntidad(poliza.getDatosPoliza().getRamo().getRamoEntidad());
	datosPersonaJuridico.setClasePoliza(poliza.getClasePoliza());
	datosPersonaJuridico.setFechaSituacion(poliza.getFechas().getFechaSituacion());
	datosPersonaJuridico.setDuracionPoliza(poliza.getDuracionPoliza());
	
	if(poliza.getTomador()!=null && poliza.getTomador().getPersonaFisica()!=null) {
		datosPersonaJuridico.setTipoTomador(poliza.getTomador().getPersonaFisica().getTipoIdentificacion());
		datosPersonaJuridico.setDatoTomador(poliza.getTomador().getPersonaFisica().getIdPersona());
	}else if(poliza.getTomador()!=null && poliza.getTomador().getPersonaJuridica()!=null){
		datosPersonaJuridico.setTipoTomador(poliza.getTomador().getPersonaJuridica().getTipoIdentificacion());
		datosPersonaJuridico.setDatoTomador(poliza.getTomador().getPersonaJuridica().getIdPersona());
	}
	
	if(poliza.getAsegurado()!=null &&poliza.getAsegurado().getPersonaFisica()!=null) {
		datosPersonaJuridico.setTipoAsegurado(poliza.getAsegurado().getPersonaFisica().getTipoIdentificacion());
		datosPersonaJuridico.setDatoAsegurado(poliza.getAsegurado().getPersonaFisica().getIdPersona());
	}else if(poliza.getAsegurado()!= null && poliza.getAsegurado().getPersonaJuridica()!=null){
		datosPersonaJuridico.setTipoAsegurado(poliza.getAsegurado().getPersonaJuridica().getTipoIdentificacion());
		datosPersonaJuridico.setDatoAsegurado(poliza.getAsegurado().getPersonaJuridica().getIdPersona());
	}
	
	datosPersonaJuridico.setRamoDGS(poliza.getDatosPoliza().getRamo().getRamoDGS());
	datosPersonaJuridico.setRecibo("");

	if(poliza.getTomador()!=null && poliza.getTomador().getPersonaFisica()!=null) {
	datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaFisica().getTipoIdentificacion());
	datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaFisica().getIdPersona());
	}
	else 	if(poliza.getTitular()!=null) {
		datosPersonaJuridico.setTipoDoc(poliza.getTitular().getPersonaFisica().getTipoIdentificacion());
		datosPersonaJuridico.setCodDoc(poliza.getTitular().getPersonaFisica().getIdPersona());
	}
	else if(poliza.getTomador()!=null && poliza.getTomador().getPersonaJuridica()!=null){
		datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaJuridica().getTipoIdentificacion());
		datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaJuridica().getIdPersona());
	}
	else
	{
		datosPersonaJuridico.setTipoDoc("");
		datosPersonaJuridico.setCodDoc("");
	} 
	
	datosPersonaJuridico.setPeridoPago(poliza.getFraccionPago());
	datosPersonaJuridico.setSitPoliza(poliza.getSituacionPoliza());
	datosPersonaJuridico.setSituacionPoliza(poliza.getSituacionPoliza());
	
	if(poliza.getFechas()!=null) {
		
		datosPersonaJuridico.setPolizaFechaEfectoActual(poliza.getFechas().getFechaEfectoActual());
		datosPersonaJuridico.setPolizaFechaEmision(poliza.getFechas().getFechaEmision());
		datosPersonaJuridico.setPolizaFechaSituacion(poliza.getFechas().getFechaSituacion());
		datosPersonaJuridico.setPolizaFechaVencimiento(poliza.getFechas().getFechaVencimiento());
	}
	}catch(Exception e){
		LOGGER.error(e.toString());
	}
	return datosPersonaJuridico;
}

public String removerCeros(String cadena) {
    
	cadena = cadena.replaceAll("^0+", "");
    return cadena;
}

public int estaLista(String idReciboNuevo,String idPolizaNuevo,int numSupNuevo) {
	
	int retorno=-1;
	try {
	
	for (int i=0;i<listaDatosPoliza.size();i++) {
	
		
		if(listaDatosPoliza.get(i).getStatus()!=null && !listaDatosPoliza.get(i).getStatus().trim().equals(""))
			continue;
//		Objects.equal(listaDatosPoliza.get(i).getNumPoliza(), idPolizaNuevo)
//		listaDatosPoliza.get(i).getNumPoliza().compareTo(idPolizaNuevo)
	if(listaDatosPoliza.get(i).getNumPoliza()!=null && removerCeros(listaDatosPoliza.get(i).getNumPoliza()).equals(removerCeros(idPolizaNuevo))) {
		

				if(listaDatosPoliza.get(i).getRecibo()!=null && listaDatosPoliza.get(i).getRecibo().trim().contentEquals("")|| listaDatosPoliza.get(i).getNumeroSuplemento()==numSupNuevo) {
					
					return i;
			}
			
		}

	}
	}catch(Exception e) {
		LOGGER.error(e.toString());
	}
	
	return retorno;
}

public DatosPersonaJuridico actualizaDatoPersonaRecibo(DatosPersonaJuridico datosPersonaJuridico,Recibo recibo) {
	try {	
	datosPersonaJuridico.setNumeroSuplemento(recibo.getDatosPoliza().getNumeroSuplemento());
	datosPersonaJuridico.setSitRecibo(recibo.getDatosRecibo().getSituacionRecibo());
	datosPersonaJuridico.setTipoRecibo(recibo.getDatosRecibo().getClaseRecibo());
	datosPersonaJuridico.setRecibo(recibo.getDatosRecibo().getIdRecibo());
	if(recibo.getDatosRecibo()!=null && recibo.getDatosRecibo().getGestionCobro()!=null && recibo.getDatosRecibo().getGestionCobro().getDatosFormaPago()!=null && recibo.getDatosRecibo().getGestionCobro().getDatosFormaPago().getDatosCuentaCorriente()!=null)
		datosPersonaJuridico.setIban(recibo.getDatosRecibo().getGestionCobro().getDatosFormaPago().getDatosCuentaCorriente().getIban());
	
	BigDecimal primaNeta=recibo.getDatosRecibo().getDatosImportes().getImportes().getPrimaNeta();
	datosPersonaJuridico.setClaseRecibo(recibo.getDatosRecibo().getClaseRecibo());
	String strPrimaNeta=String.valueOf(primaNeta);
	datosPersonaJuridico.setPrimaNeta(strPrimaNeta);
	datosPersonaJuridico.setFechaEfectoActual(recibo.getDatosRecibo().getFechas().getFechaEfectoActual().toString());
	datosPersonaJuridico.setFecFinSeg(recibo.getDatosRecibo().getFechas().getFechaVencimiento().toString());
	datosPersonaJuridico.setFecInicioPoliza(recibo.getDatosRecibo().getFechas().getFechaEfectoInicial().toString());
	
	datosPersonaJuridico.setFechaEmision(recibo.getDatosRecibo().getFechas().getFechaEmision().toString());
	BigDecimal primaTotal=recibo.getDatosRecibo().getDatosImportes().getImportes().getPrimaTotal();
	String strPrimaTotal=String.valueOf(primaTotal);
	datosPersonaJuridico.setImporteRecibo(strPrimaTotal);
	}catch(Exception e){
		LOGGER.error(e.toString());
	}
	return datosPersonaJuridico;
}

public DatosPersonaJuridico generaDatoPersonaJuridicoRecibo(Recibo recibo) {
	
	DatosPersonaJuridico datosPersonaJuridico= new DatosPersonaJuridico();
	try {
	
	datosPersonaJuridico.setnumPoliza(recibo.getDatosPoliza().getIdPoliza());
	if(recibo.getDatosRecibo().getGestionCobro().getDatosFormaPago()!=null)
	datosPersonaJuridico.setIban(recibo.getDatosRecibo().getGestionCobro().getDatosFormaPago().getDatosCuentaCorriente().getIban());
	if(recibo.getDatosPoliza().getNumeroSuplemento()!=null)
	datosPersonaJuridico.setNumeroSuplemento(recibo.getDatosPoliza().getNumeroSuplemento());
	if(recibo.getDatosPoliza().getIdMediador()!=null)
	datosPersonaJuridico.setMediador(recibo.getDatosPoliza().getIdMediador());
	if(recibo.getDatosPoliza().getProductoDGS()!=null)
	datosPersonaJuridico.setProducto(recibo.getDatosPoliza().getProductoDGS());
	if(recibo.getDatosRecibo().getIdRecibo()!=null)
	datosPersonaJuridico.setRecibo(recibo.getDatosRecibo().getIdRecibo());

	datosPersonaJuridico.setTipoDoc("");
	datosPersonaJuridico.setCodDoc("");

	datosPersonaJuridico.setSitRecibo(recibo.getDatosRecibo().getSituacionRecibo());
	datosPersonaJuridico.setTipoRecibo(recibo.getDatosRecibo().getClaseRecibo());
	datosPersonaJuridico.setPeridoPago(recibo.getDatosRecibo().getFraccionPago());
	BigDecimal datoImporte=recibo.getDatosRecibo().getDatosImportes().getImportes().getPrimaNeta();
	String strImporte=String.valueOf(datoImporte);
	datosPersonaJuridico.setPrimaNeta(strImporte);
	
	datosPersonaJuridico.setFecFinSeg(recibo.getDatosRecibo().getFechas().getFechaVencimiento().toString());
	datosPersonaJuridico.setFecInicioPoliza(recibo.getDatosRecibo().getFechas().getFechaEfectoInicial().toString());
	datosPersonaJuridico.setFechaEmision(recibo.getDatosRecibo().getFechas().getFechaEmision().toString());
	BigDecimal primaTotal=recibo.getDatosRecibo().getDatosImportes().getImportes().getPrimaTotal();
	String strPrimaTotal=String.valueOf(primaTotal);
	datosPersonaJuridico.setImporteRecibo(strPrimaTotal);
	
	datosPersonaJuridico.setFechaEfectoActual(recibo.getDatosRecibo().getFechas().getFechaEfectoActual().toString());
	
	DatosPersonaJuridico datosPersonaPoliza= obtenerDatosPoliza(recibo.getDatosPoliza().getIdPoliza());
	
	if(datosPersonaPoliza!=null) {
		
	
				datosPersonaJuridico.setTipoDoc( datosPersonaPoliza.getTipoDoc());
				datosPersonaJuridico.setCodDoc(datosPersonaPoliza.getCodDoc());
			
		
	}

	}catch(Exception e){
		LOGGER.error(e.toString());
	}
	return datosPersonaJuridico;
}
public String cambiaLinea(String linea) {
	
	int totalSeparador=0;
	String cambiado="";
	String resultado="";
	for(int i=0;i<linea.length()-1;i++) {
		if(linea.substring(i, i+1).equalsIgnoreCase("|")) {
			totalSeparador++;
			if(totalSeparador==6) {
				String sublinea=linea.substring(i+1,linea.length());
				boolean finCambio=false;
				for(int j=0;j<sublinea.length();j++) {
					if(sublinea.substring(j,j+1).equalsIgnoreCase("|"))
						finCambio=true;
						if(!finCambio)
					cambiado+="@"+sublinea.substring(j,j+1);
						else
							cambiado+=sublinea.substring(j,j+1);
				}
				
				resultado=linea.substring(0,i+1)+cambiado;
				return resultado;
			}
		}
		
	}
	return "";
}

public DatosPersonaJuridico generaDatoPersonaJuridico(Poliza poliza,Recibo recibo) {
	
	DatosPersonaJuridico datosPersonaJuridico= new DatosPersonaJuridico();
	try {
	
	datosPersonaJuridico.setnumPoliza(poliza.getDatosPoliza().getIdPoliza());
	datosPersonaJuridico.setNumeroSuplemento(recibo.getDatosPoliza().getNumeroSuplemento());
	datosPersonaJuridico.setMediador(poliza.getDatosPoliza().getDatosMediador().getIdMediador().getCodigoInterno());
	datosPersonaJuridico.setProducto(poliza.getDatosPoliza().getRamo().getModalidadRamo());
	datosPersonaJuridico.setRecibo(recibo.getDatosRecibo().getIdRecibo());
	datosPersonaJuridico.setClaseRecibo(recibo.getDatosRecibo().getClaseRecibo());
	datosPersonaJuridico.setIban(recibo.getDatosRecibo().getGestionCobro().getDatosFormaPago().getDatosCuentaCorriente().getIban());
	if(poliza.getTomador()!=null && poliza.getTomador().getPersonaFisica()!=null) {
	datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaFisica().getTipoIdentificacion());
	datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaFisica().getIdPersona());
	}
	else 	if(poliza.getTitular()!=null) {
		datosPersonaJuridico.setTipoDoc(poliza.getTitular().getPersonaFisica().getTipoIdentificacion());
		datosPersonaJuridico.setCodDoc(poliza.getTitular().getPersonaFisica().getIdPersona());
	}
	else if(poliza.getTomador()!=null && poliza.getTomador().getPersonaJuridica()!=null){
		datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaJuridica().getTipoIdentificacion());
		datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaJuridica().getIdPersona());
	}
	else
	{
		datosPersonaJuridico.setTipoDoc("");
		datosPersonaJuridico.setCodDoc("");
	}
	datosPersonaJuridico.setSitRecibo(recibo.getDatosRecibo().getSituacionRecibo());
	datosPersonaJuridico.setTipoRecibo(recibo.getDatosRecibo().getClaseRecibo());
	datosPersonaJuridico.setFechaEfectoActual(recibo.getDatosRecibo().getFechas().getFechaEfectoActual().toString());
	BigDecimal primaNeta= recibo.getDatosRecibo().getDatosImportes().getImportes().getPrimaNeta();
	String strPrimaNeta=String.valueOf(primaNeta);
	datosPersonaJuridico.setPrimaNeta(strPrimaNeta);
	datosPersonaJuridico.setPeridoPago(poliza.getFraccionPago());
	datosPersonaJuridico.setSituacionPoliza(poliza.getSituacionPoliza());
	}catch(Exception e){
		LOGGER.error(e.toString());
	}
	return datosPersonaJuridico;
}

public DatosPersonaJuridico obtenerDatosPoliza(String poliza) {
	
	try {
	
	for (int i=0;i<listaDatosPoliza.size();i++) {
			if(listaDatosPoliza.get(i).getNumPoliza()!=null && listaDatosPoliza.get(i).getNumPoliza().equals(poliza)) {
			//	if(listaDatosPoliza.get(i).getNumeroSuplemento()==numSuplementoNuevo)
				return listaDatosPoliza.get(i);	
			}
		}
	}catch(Exception e) {
		LOGGER.error(e.toString());
	}
	
	return null;
	
}
//SE añaden clases de test
public class DatosPersonaJuridicoTest {

    @Test
    public void testGeneraDatoPersonaJuridicoPoliza() {
        // Create a sample Poliza object
        Poliza poliza = new Poliza();
        // Set the necessary properties of the Poliza object

        // Call the method under test
        DatosPersonaJuridico result = generaDatoPersonaJuridicoPoliza(poliza);

        // Assert the expected values of the DatosPersonaJuridico object
       assertNotNull(result);
      
        // Assert the remaining properties of the DatosPersonaJuridico object
    }
}

public class testGenerarFicheroDiarioCompleto {

    private testGenerarFicheroDiarioCompleto testGenerarFicheroDiarioCompleto;

   

    @Test
    public void testGenerarFicheroDiarioCompleto() {
        // Create a sample list of data
       
        // Add some data to the list

        // Call the method to generate the file
       testGenerarFicheroDiarioCompleto();

        // TODO: Add assertions to verify the generated file
        // For example, you can check if the file exists, has the correct content, etc.
    }
}

public class TestGenerarFicheroDiario {

    @Test
    public void testGenerarFicheroDiario() {
        // Create an instance of your class
    	TestGenerarFicheroDiario testGenerarFicheroDiario = new TestGenerarFicheroDiario();

        // Call the method you want to test
    boolean resultado=generarFicheroDiario();
    	assertEquals(true, resultado);
        // Add assertions to verify the expected behavior
        // For example, you can check if the generated files exist
        // and if they have the expected content
        // You can use file assertions libraries like AssertJ or JUnit's built-in assertions

        // Example using AssertJ:
    
    }
}


}
