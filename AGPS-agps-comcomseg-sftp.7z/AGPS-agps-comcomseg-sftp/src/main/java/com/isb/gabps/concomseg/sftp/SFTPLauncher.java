package com.isb.gabps.concomseg.sftp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.isb.config.ParamStoreConfiguration;


//squid:S1118: Add a private constructor to hide the implicit public one.
//- A partir de enero 2019 comenzó a considerar esta clase como utilitaria
//- Pide modificar el constructor a privado, y el spring boot necesita que sea pública

/**
 * Lanzador.
 * 
 * @author x310169
 */
@SuppressWarnings("squid:S1118")
@SpringBootApplication
public class SFTPLauncher {
	
	private static final Logger log = LoggerFactory.getLogger(SFTPLauncher.class);

	// squid:S2095: Close this "ConfigurableApplicationContext".
	// - No se puede cerrar el contexto de spring boot, se cierra la app si se hace.
	@SuppressWarnings("squid:S2095")
	/**
	 * Step para subir el fichero contable al servidor sftp.
	 * This is a Javadoc comment comentado por jmlo
	 * @param String[]
	 */
	public static void main(String[] args) {
		 final String PROJECT_KEY = "agps";
		 ParamStoreConfiguration.loadParamStoreConfiguration(PROJECT_KEY);
		 log.warn("DENTRO DEL NUEVO EJECUTABLE");
		
		 
	/*	
		 Transformer xsltTransformer;
	//	 Resource xsltRes = new ClassPathResource("d:\\contabilidad-zurich.xslt");
			StreamSource xsltSS;
			try {
				xsltSS = new StreamSource(new File("d:\\contabilidad-zurich.xslt"));
				xsltTransformer = TransformerFactory.newInstance().newTransformer(xsltSS);
				xsltTransformer.setOutputProperty(OutputKeys.INDENT, "yes");
				File fichero=new File("d:\\contabilidad-zurich-polizas.xml");
					
				xsltTransformer.setParameter("policy-file",fichero.toPath().toUri());
			//	InputStream input=new FileInputStream(new File("d:\\concomseg\\bucket\\pull-job-20200115-1_contabilidad-zurich-recibos.xml"));
	
				InputStream input=new FileInputStream(new File("d:\\contabilidad-zurich-recibos.xml"));
				OutputStream out = new ByteArrayOutputStream();
			    StreamResult result = new StreamResult(out);
			    StreamSource xml = new StreamSource(input);
		    	xsltTransformer.transform(xml, result);
		    String a=	new String (((ByteArrayOutputStream) out).toByteArray() );
		
			
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (TransformerConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (TransformerFactoryConfigurationError e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (TransformerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		

		 
		 
		 
		 
		 
		 
		 
		 
		 
		 TransformerFactory tf = TransformerFactory.newInstance();
		tf.setAttribute("indent-number", 2);
		 Transformer domTransformer;
		 try {
			domTransformer = tf.newTransformer();
		
		 
		 DocumentBuilderFactory factory =
			        DocumentBuilderFactory.newInstance();
		 
	 File f = new File("d:\\concomseg\\bucket\\pull-job-20200117-1_contabilidad-zurich-recibos.xml");
	 
	 String         line = null;
	    StringBuilder  stringBuilder = new StringBuilder();
   String         ls = System.getProperty("line.separator");

   Reader lector = new InputStreamReader(new FileInputStream(f));
   BufferedReader  reader = new BufferedReader(lector);
	       while((line = reader.readLine()) != null) {
	            stringBuilder.append(line);
	           // stringBuilder.append(ls);
	        }
	 
	 
		    DocumentBuilder builder = factory.newDocumentBuilder();
		    Document document = builder.parse(new InputSource(new StringReader(stringBuilder.toString())));
		 
			domTransformer.setOutputProperty(OutputKeys.INDENT, "yes");
			DOMSource ds = new DOMSource(document);
			//	 StringWriter sw = new StringWriter();
		//if(false)
			OutputStream out = new ByteArrayOutputStream();
			//domTransformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
			 domTransformer.setOutputProperty(OutputKeys.INDENT, "yes");
			// domTransformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			// domTransformer.setOutputProperty(OutputKeys.METHOD, "xml");
			
    		StreamResult sr = new StreamResult(out);
    		
    		domTransformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

    		 FileWriter writer = new FileWriter(new File("d:\\output.xml"));
 		    StreamResult result = new StreamResult(writer);
 		  
			domTransformer.transform(ds, result);		
		 } catch (TransformerConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 */
		 
		SpringApplication.run(SFTPLauncher.class, args);
	}
}
