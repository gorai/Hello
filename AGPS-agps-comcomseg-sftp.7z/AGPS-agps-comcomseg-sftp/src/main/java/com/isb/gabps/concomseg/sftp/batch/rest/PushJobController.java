package com.isb.gabps.concomseg.sftp.batch.rest;

import org.springframework.batch.core.Job;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isb.gabps.concomseg.sftp.batch.BatchGlobals;

/**
 * Controlador de servicios REST para gestionar el push-files job, que se encarga
 * de enviar los ficheros al servidor sftp.
 * 
 * <p>
 * Más detalles del funcionamiento en {@link AbstractJobController}
 * 
 * @author xIS08485
 */
@RestController
@RequestMapping(ControllerGlobals.URL_PUSH_JOB)
public class PushJobController extends AbstractJobController {
	/**
	 * Constructor
	 */
	public PushJobController() {
		this.jobPath = ControllerGlobals.URL_PUSH_JOB;
	}
	
	/**
	 * Define el job asociado al controller.
	 * 
	 * @param job Job
	 */
	@Autowired
	@Qualifier(BatchGlobals.JOB_PUSH_NAME)
	public void setJob(Job job) {
		this.job = job;
	}
}
