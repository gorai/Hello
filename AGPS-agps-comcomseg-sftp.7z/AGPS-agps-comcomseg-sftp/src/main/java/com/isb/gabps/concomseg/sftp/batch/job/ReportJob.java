package com.isb.gabps.concomseg.sftp.batch.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersValidator;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.isb.gabps.concomseg.sftp.batch.BatchGlobals;

/**
 * Configuración del job que sube al servidor sftp el archivo de contabilidad generado.
 * 
 * @author xIS08485
 */
@Configuration
public class ReportJob {
	// Para crear los jobs de esta configuración
	@Autowired
	private JobBuilderFactory jobs;
	
	// Para crear los steps de esta configuración
	@Autowired
    private StepBuilderFactory steps;
	
	
	
	/**
	 * Configura, crea y devuelve el job que se encarga de subir el fichero contable
	 * al servidor sftp.
	 * 
	 * @return La configuración del job
	 */
	@Bean(BatchGlobals.JOB_REPORT_NAME)
	public Job pullFilesJob(@Qualifier(BatchGlobals.VALIDATOR_DATE)JobParametersValidator dateValidator
			, @Qualifier(BatchGlobals.STEP_REPORT) Step uploadStep) {
		return jobs
				.get(BatchGlobals.JOB_REPORT_NAME)
				.validator(dateValidator)
				.start(uploadStep)
				.build();
	}
	
	/**
	 * Crea el step del job que se encarga de subir el fichero contable al servidor sftp.
	 * 
	 * @return La configuración del step
	 */
	@Bean(BatchGlobals.STEP_REPORT)
    protected Step downloadFilesStep(@Qualifier(BatchGlobals.TASKLET_REPORT) Tasklet tasklet) {
        return steps
        		.get(BatchGlobals.STEP_REPORT)
        		.tasklet(tasklet)
        		.build();
    }
}
