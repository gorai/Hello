package com.isb.gabps.concomseg.sftp.exception;

import java.io.Serializable;

/**
 * Clase para controlar las excepciones de estas piezas.
 *
 * @author Viewnext
 */
public class ComiSegException extends Exception implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /**
     * Constructor de la clase.
     */
    public ComiSegException() {
        super();
    }

    /**
     * Constructor parametrizado.
     *
     * @param message
     *            Mensaje de la excepcion a capturar
     */
    public ComiSegException(String message) {
        super(message);
    }

    /**
     * Constructor parametrizado.
     *
     * @param throwable
     *            Traza de la excepcion a capturar
     * @param message
     *            Mensaje de la excepcion a capturar
     */
    public ComiSegException(Throwable throwable, String message) {
        super(message, throwable);
    }

    /**
     * Instantiates a new gestor consentimientos exception.
     *
     * @param e
     *            the e
     */
    public ComiSegException(Exception e) {
        super(e.getMessage(), e.getCause());
    }

}
