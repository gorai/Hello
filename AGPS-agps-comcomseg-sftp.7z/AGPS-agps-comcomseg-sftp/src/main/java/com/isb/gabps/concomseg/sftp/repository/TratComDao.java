package com.isb.gabps.concomseg.sftp.repository;

import java.util.List;

import com.isb.gabps.concomseg.sftp.exception.ComiSegException;
import com.isb.gabps.concomseg.sftp.model.TablaConvProducto;
import com.isb.gabps.concomseg.sftp.model.TablaSeleccionRecibo;

/**
 * The Interface TratComDao.
 */
public interface TratComDao {

    /**
     * Elemento encontrado.
     *
     * @param idPoliza
     *            the id poliza
     * @param numeroSuplemento
     *            the numero suplemento
     * @param idRecibo
     *            the id recibo
     * @return true, if successful
     */
    List<TablaSeleccionRecibo> existePoliza(String idPoliza, Integer numeroSuplemento, String idRecibo);
    
    /**
     * Elemento encontrado.
     *
     * @param date
     *            date
     * @return  List<TablaSeleccionRecibo>
     */
    List<TablaSeleccionRecibo> reportExport(String date);

    List<TablaSeleccionRecibo> reportExport();

	List<String> listaProductos();

}
