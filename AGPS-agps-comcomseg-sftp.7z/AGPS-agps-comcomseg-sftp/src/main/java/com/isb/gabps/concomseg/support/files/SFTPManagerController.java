package com.isb.gabps.concomseg.support.files;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Security;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.ws.Response;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.google.common.base.Objects;
import com.isb.conector.S3Repository;
import com.isb.gabps.concomseg.sftp.SFTPConfig;
import com.isb.gabps.concomseg.sftp.SFTPException;
import com.isb.gabps.concomseg.sftp.batch.step.DownloadTasklet;
import com.isb.gabps.concomseg.sftp.model.TablaSeleccionRecibo;
import com.isb.gabps.concomseg.sftp.pojo.ProcesosEIAC;
import com.isb.gabps.concomseg.sftp.pojo.ProcesosEIAC.Objetos.Recibo;

import com.isb.gabps.concomseg.sftp.pojo.ProcesosEIACPoliza;
import com.isb.gabps.concomseg.sftp.pojo.ProcesosEIACPoliza.Objetos.Poliza;
import com.isb.gabps.concomseg.sftp.pojo.ProcesosEIACPoliza.Objetos.Poliza.Dato;

import com.isb.gabps.concomseg.sftp.repository.TratComDao;
import com.isb.gabps.concomseg.sftp.service.SFTPService;
import com.jcraft.jsch.SftpException;


/**
 * Herramienta de desarrollo para la subida/baja de ficheros que se encuentran dentro del PaaS.
 * Para usarse requiere activar el perfil spring: dev-tools.
 * 
 * @author xIS08485
 *
 */
//@Profile("feat-files")
@RestController
@RequestMapping("/sftp")
public class SFTPManagerController {
	// Logger
	private static final Logger LOGGER = LoggerFactory.getLogger(SFTPManagerController.class);
	
	// Constantes
	private static final String PROP_PATH_PREFIX = "app.sftp.path-";
	
	// Servicio para descargar los ficheros del servidor sftp
	@Autowired
	private SFTPService service;
	
	// Configuración (del properties)
	@Autowired
	private SFTPConfig config;
		
	// Usamos environment en lugar de la propiedad final, porque la vamos a buscar dinámicamente:
	// app.filesystem.(dato de entrada)
	@Autowired
	private Environment env;
	
	@Autowired
	private TratComDao repository;
	
	public S3Repository repositoryS3;
	private String ficheroSalidaPlano="DatosPolizaPlano.txt";
	private String ficheroDaily="DatosDaily.txt";
	private String ficherosDiarios="FicherosDaily.txt";
	List<DatosPersonaJuridico> listaDatosPoliza =new ArrayList<>();
	List<String> ficherosDia =new ArrayList<>();

	/**
	 * Devuelve una lista de los ficheros en una carpeta determinada.
	 * 
	 * <p>
	 * A través del ID de entrada, buscamos la ruta a la carpeta definida en el properties.
	 * La ruta buscada será: app.filesystem.path-(identificador de entrada).
	 * Por ejemplo: {@code app.filesystem.path-in} o {@code app.filesystem.path-out}
	 * 
	 * <p>
	 * URL acceso: GET .../sftp/{pathId}
	 * 
	 * @param pathId Identificador de la carpeta
	 * @return Una lista con los nombres de ficheros encontrados
	 */
	@GetMapping("lista/{pathId}")
	public ListFilesResponse listFiles(@PathVariable String pathId) {
	
		ListFilesResponse response = new ListFilesResponse();
				try {
					service.connect(config.getSFTPServer(), config.getSFTPPort(),
							config.getSFTPLogin(), config.getSFTPSecret());
				} catch (SFTPException e) {
					// TODO Auto-generated catch block
					response.setResult("Error al conectar a la base de datos");
					return response;			
				}
		LOGGER.debug("JMLO DB File");
	
		String valor = env.getProperty(PROP_PATH_PREFIX + pathId);
		if ((valor == null) || (valor.isEmpty())) {
			valor=pathId;	
		}
		Path ruta =Paths.get(valor);
		
		List<String>listaRutas =null;
		try {
			listaRutas = service.sftpListFiles(valor+"/*");
		} catch (SftpException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
		}
		
		response.setFilesList(listaRutas);
	    return response;
	
	}
	
	public int listaRecibosEstaLista(ProcesosEIAC eiac) {
		
		int retorno=-1;
		
		for(int i=0;i<listaDatosPoliza.size();i++) {
			String numRecibo=listaDatosPoliza.get(i).getRecibo();
		for(int j=0;j<eiac.getObjetos().getRecibo().size();i++) {
			if(eiac.getObjetos().getRecibo().get(j).getDatosRecibo().getIdRecibo().equals(numRecibo)) {
				int suplemento=listaDatosPoliza.get(i).getNumeroSuplemento();
				if(eiac.getObjetos().getRecibo().get(j).getDatosPoliza().getNumeroSuplemento()==suplemento)
					return i;
			}
		}
			
		}
		return retorno;
	}
	
	public DatosPersonaJuridico generaDatoPersonaJuridico(Poliza poliza,Recibo recibo) {
	
		DatosPersonaJuridico datosPersonaJuridico= new DatosPersonaJuridico();
		try {
		
		datosPersonaJuridico.setnumPoliza(poliza.getDatosPoliza().getIdPoliza());
		datosPersonaJuridico.setNumeroSuplemento(recibo.getDatosPoliza().getNumeroSuplemento());
		datosPersonaJuridico.setMediador(poliza.getDatosPoliza().getDatosMediador().getIdMediador().getCodigoInterno());
		datosPersonaJuridico.setProducto(poliza.getDatosPoliza().getRamo().getModalidadRamo());
		datosPersonaJuridico.setRecibo(recibo.getDatosRecibo().getIdRecibo());
	
		if(poliza.getTomador()!=null && poliza.getTomador().getPersonaFisica()!=null) {
		datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaFisica().getTipoIdentificacion());
		datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaFisica().getIdPersona());
		}
		else 	if(poliza.getTitular()!=null) {
			datosPersonaJuridico.setTipoDoc(poliza.getTitular().getPersonaFisica().getTipoIdentificacion());
			datosPersonaJuridico.setCodDoc(poliza.getTitular().getPersonaFisica().getIdPersona());
		}
		else if(poliza.getTomador()!=null && poliza.getTomador().getPersonaJuridica()!=null){
			datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaJuridica().getTipoIdentificacion());
			datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaJuridica().getIdPersona());
		}
		else
		{
			datosPersonaJuridico.setTipoDoc("");
			datosPersonaJuridico.setCodDoc("");
		}
		datosPersonaJuridico.setSitRecibo(recibo.getDatosRecibo().getSituacionRecibo());
		datosPersonaJuridico.setTipoRecibo(recibo.getDatosRecibo().getClaseRecibo());
		datosPersonaJuridico.setPeridoPago(poliza.getFraccionPago());
	
		}catch(Exception e){
			LOGGER.error(e.getMessage());
		}
		return datosPersonaJuridico;
	}
	
	public DatosPersonaJuridico obtenerDatosPoliza(String poliza) {
		
		try {
		
		for (int i=0;i<listaDatosPoliza.size();i++) {
				if(listaDatosPoliza.get(i).getNumPoliza().equals(poliza)) {
				//	if(listaDatosPoliza.get(i).getNumeroSuplemento()==numSuplementoNuevo)
					return listaDatosPoliza.get(i);	
				}
			}
		}catch(Exception e) {
			LOGGER.error(e.getMessage());
		}
		
		return null;
		
	}
	
	public DatosPersonaJuridico generaDatoPersonaJuridicoRecibo(Recibo recibo) {
		
		DatosPersonaJuridico datosPersonaJuridico= new DatosPersonaJuridico();
		try {
		
		datosPersonaJuridico.setnumPoliza(recibo.getDatosPoliza().getIdPoliza());
		
		
		datosPersonaJuridico.setNumeroSuplemento(recibo.getDatosPoliza().getNumeroSuplemento());
		datosPersonaJuridico.setMediador(recibo.getDatosPoliza().getIdMediador());
		datosPersonaJuridico.setProducto(recibo.getDatosPoliza().getProductoDGS());
		datosPersonaJuridico.setRecibo(recibo.getDatosRecibo().getIdRecibo());
	
		datosPersonaJuridico.setTipoDoc("");
		datosPersonaJuridico.setCodDoc("");
	
		datosPersonaJuridico.setSitRecibo(recibo.getDatosRecibo().getSituacionRecibo());
		datosPersonaJuridico.setTipoRecibo(recibo.getDatosRecibo().getClaseRecibo());
		datosPersonaJuridico.setPeridoPago(recibo.getDatosRecibo().getFraccionPago());
		
		
		DatosPersonaJuridico datosPersonaPoliza= obtenerDatosPoliza(recibo.getDatosPoliza().getIdPoliza());
		
		if(datosPersonaPoliza!=null) {
			
		
					datosPersonaJuridico.setTipoDoc( datosPersonaPoliza.getTipoDoc());
					datosPersonaJuridico.setCodDoc(datosPersonaPoliza.getCodDoc());
				
			
		}
	
		}catch(Exception e){
			LOGGER.error(e.getMessage());
		}
		return datosPersonaJuridico;
	}
	
	
	public DatosPersonaJuridico actualizaDatoPersonaRecibo(DatosPersonaJuridico datosPersonaJuridico,Recibo recibo) {
		
		try {
		datosPersonaJuridico.setNumeroSuplemento(recibo.getDatosPoliza().getNumeroSuplemento());
		datosPersonaJuridico.setSitRecibo(recibo.getDatosRecibo().getSituacionRecibo());
		datosPersonaJuridico.setTipoRecibo(recibo.getDatosRecibo().getClaseRecibo());
		datosPersonaJuridico.setRecibo(recibo.getDatosRecibo().getIdRecibo());
		
		}catch(Exception e){
			LOGGER.error(e.getMessage());
		}
		return datosPersonaJuridico;
	}
	
	public DatosPersonaJuridico generaDatoPersonaJuridicoPoliza(Poliza poliza) {
		
		DatosPersonaJuridico datosPersonaJuridico= new DatosPersonaJuridico();
		try {
		
		datosPersonaJuridico.setnumPoliza(poliza.getDatosPoliza().getIdPoliza());
		datosPersonaJuridico.setNumeroSuplemento(poliza.getDatosPoliza().getNumeroSuplemento());
		datosPersonaJuridico.setMediador(poliza.getDatosPoliza().getDatosMediador().getIdMediador().getCodigoInterno());
		datosPersonaJuridico.setProducto(poliza.getDatosPoliza().getRamo().getModalidadRamo());
		datosPersonaJuridico.setRecibo("");
	
		if(poliza.getTomador()!=null && poliza.getTomador().getPersonaFisica()!=null) {
		datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaFisica().getTipoIdentificacion());
		datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaFisica().getIdPersona());
		}
		else 	if(poliza.getTitular()!=null) {
			datosPersonaJuridico.setTipoDoc(poliza.getTitular().getPersonaFisica().getTipoIdentificacion());
			datosPersonaJuridico.setCodDoc(poliza.getTitular().getPersonaFisica().getIdPersona());
		}
		else if(poliza.getTomador()!=null && poliza.getTomador().getPersonaJuridica()!=null){
			datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaJuridica().getTipoIdentificacion());
			datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaJuridica().getIdPersona());
		}
		else
		{
			datosPersonaJuridico.setTipoDoc("");
			datosPersonaJuridico.setCodDoc("");
		}
		
		datosPersonaJuridico.setPeridoPago(poliza.getFraccionPago());
	
		}catch(Exception e){
			LOGGER.error(e.getMessage());
		}
		return datosPersonaJuridico;
	}
	
	
public DatosPersonaJuridico actualizaDatoPersonaJuridicoPoliza(DatosPersonaJuridico datosPersonaJuridico,Poliza poliza) {
		
	
		try {
		
		datosPersonaJuridico.setnumPoliza(poliza.getDatosPoliza().getIdPoliza());
		datosPersonaJuridico.setNumeroSuplemento(poliza.getDatosPoliza().getNumeroSuplemento());
		datosPersonaJuridico.setMediador(poliza.getDatosPoliza().getDatosMediador().getIdMediador().getCodigoInterno());
		datosPersonaJuridico.setProducto(poliza.getDatosPoliza().getRamo().getModalidadRamo());
		
	
		if(poliza.getTomador()!=null && poliza.getTomador().getPersonaFisica()!=null) {
		datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaFisica().getTipoIdentificacion());
		datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaFisica().getIdPersona());
		}
		else 	if(poliza.getTitular()!=null) {
			datosPersonaJuridico.setTipoDoc(poliza.getTitular().getPersonaFisica().getTipoIdentificacion());
			datosPersonaJuridico.setCodDoc(poliza.getTitular().getPersonaFisica().getIdPersona());
		}
		else if(poliza.getTomador()!=null && poliza.getTomador().getPersonaJuridica()!=null){
			datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaJuridica().getTipoIdentificacion());
			datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaJuridica().getIdPersona());
		}
		else
		{
			datosPersonaJuridico.setTipoDoc("");
			datosPersonaJuridico.setCodDoc("");
		}
		
		datosPersonaJuridico.setPeridoPago(poliza.getFraccionPago());
	
		}catch(Exception e){
			LOGGER.error(e.getMessage());
		}
		return datosPersonaJuridico;
	}
	

	
	public DatosPersonaJuridico generaDatoPersonaJuridico(Poliza poliza) {
		
		DatosPersonaJuridico datosPersonaJuridico= new DatosPersonaJuridico();
		try {
		
		datosPersonaJuridico.setnumPoliza(poliza.getDatosPoliza().getIdPoliza());
		datosPersonaJuridico.setMediador(poliza.getDatosPoliza().getDatosMediador().getIdMediador().getCodigoInterno());
		datosPersonaJuridico.setProducto(poliza.getDatosPoliza().getRamo().getModalidadRamo());
		datosPersonaJuridico.setRecibo("");
	
		if(poliza.getTomador()!=null && poliza.getTomador().getPersonaFisica()!=null) {
		datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaFisica().getTipoIdentificacion());
		datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaFisica().getIdPersona());
		}
		else 	if(poliza.getTitular()!=null) {
			datosPersonaJuridico.setTipoDoc(poliza.getTitular().getPersonaFisica().getTipoIdentificacion());
			datosPersonaJuridico.setCodDoc(poliza.getTitular().getPersonaFisica().getIdPersona());
		}
		else if(poliza.getTomador()!=null && poliza.getTomador().getPersonaJuridica()!=null){
			datosPersonaJuridico.setTipoDoc(poliza.getTomador().getPersonaJuridica().getTipoIdentificacion());
			datosPersonaJuridico.setCodDoc(poliza.getTomador().getPersonaJuridica().getIdPersona());
		}
		else
		{
			datosPersonaJuridico.setTipoDoc("");
			datosPersonaJuridico.setCodDoc("");
		}
		datosPersonaJuridico.setSitRecibo("");
		datosPersonaJuridico.setTipoRecibo("");
		datosPersonaJuridico.setPeridoPago(poliza.getFraccionPago());
	
		}catch(Exception e){
			LOGGER.error(e.getMessage());
		}
		return datosPersonaJuridico;
	}
	
	
	public List<DatosPersonaJuridico> juntarListas(List<ProcesosEIACPoliza> listaPolizas,List<ProcesosEIAC> listaRecibos){
		
		 List<DatosPersonaJuridico> listaJunta=new ArrayList<DatosPersonaJuridico>();
		 boolean insertado=false;
		 for(int i=0; i<listaRecibos.size();i++) {
			 
			 List<Recibo> listaSubrecibo=listaRecibos.get(i).getObjetos().getRecibo();
			 
			 for(int j=0; j<listaSubrecibo.size();j++) {
				 insertado=false;
				 String idPoliza=listaSubrecibo.get(j).getDatosPoliza().getIdPoliza().trim();
				
				 for(int k=0;k<listaPolizas.size();k++) {
					 
					 List<Poliza> listaSubPolizas=listaPolizas.get(k).getObjetos().getPoliza();
					 
					 for(int l=0; l<listaSubPolizas.size();l++) {
						 
						 if(idPoliza.equals(listaSubPolizas.get(l).getDatosPoliza().getIdPoliza().trim())) {
							 DatosPersonaJuridico datoPersonaJuridico= generaDatoPersonaJuridico(listaSubPolizas.get(l),listaSubrecibo.get(j));
							
							 listaJunta.add(datoPersonaJuridico);
							 insertado=true;
						 }
					 }
					 
				 }
				 if(insertado==false) {
						
					 DatosPersonaJuridico datoPersonaJuridico= obtenPoliza(listaSubrecibo.get(j));
					 if(datoPersonaJuridico!=null)
						 listaJunta.add(datoPersonaJuridico);
					
				 }
			 }
			 
			 
		 }
		 boolean esta=false;
		 
		 for(int k=0;k<listaPolizas.size();k++) {
			 
			 List<Poliza> listaSubPolizas=listaPolizas.get(k).getObjetos().getPoliza();
			 
			 for(int l=0; l<listaSubPolizas.size();l++) {
				 esta=false;
				 
				 	for(int m=0;m<listaJunta.size();m++) {
				 		
				 	if(listaJunta.get(m).getNumPoliza().equals(listaSubPolizas.get(l).getDatosPoliza().getIdPoliza())) {
				 		esta=true;
				 		break;
					
				 	}
				 }
				 	if(esta==false) {
				 		
				DatosPersonaJuridico datoPoliza=generaDatoPersonaJuridico(listaSubPolizas.get(l));
				listaDatosPoliza.add(datoPoliza);
				 }
	    	}
			 
		 }
	 
		 return listaJunta;
		
	}
	
	public DatosPersonaJuridico obtenPoliza(Recibo recibo) {
		
		
		for (int i=0;i<listaDatosPoliza.size();i++) {
			if(listaDatosPoliza.get(i).getRecibo().equals(recibo.getDatosRecibo().getIdRecibo())){
				
				DatosPersonaJuridico datos= new DatosPersonaJuridico();
				datos=listaDatosPoliza.get(i);
				datos.setSitRecibo(recibo.getDatosRecibo().getSituacionRecibo());
				datos.setNumeroSuplemento(recibo.getDatosPoliza().getNumeroSuplemento());
				datos.setTipoRecibo(recibo.getDatosRecibo().getClaseRecibo());
				return datos;
			}
		}
		return null;
	}
	
	public int estaLista(String idReciboNuevo,String idPolizaNuevo,int numSupNuevo) {
		
		int retorno=-1;
		try {
		
		for (int i=0;i<listaDatosPoliza.size();i++) {
		
			
			if(listaDatosPoliza.get(i).getStatus()!=null && !listaDatosPoliza.get(i).getStatus().trim().equals(""))
				continue;
	//		Objects.equal(listaDatosPoliza.get(i).getNumPoliza(), idPolizaNuevo)
	//		listaDatosPoliza.get(i).getNumPoliza().compareTo(idPolizaNuevo)
			if(listaDatosPoliza.get(i).getNumPoliza().equals(idPolizaNuevo)) {
			
	
					if(listaDatosPoliza.get(i).getRecibo().trim().contentEquals("")|| listaDatosPoliza.get(i).getNumeroSuplemento()==numSupNuevo) {
						
						return i;
					
				}
				
			}
	
		}
		}catch(Exception e) {
			LOGGER.error(e.getMessage());
		}
		
		return retorno;
	}
	
	public int estaPolizaLista(String idPolizaNuevo,int numSuplementoNuevo) {
		
		int retorno=-1;
		try {
		
		for (int i=0;i<listaDatosPoliza.size();i++) {
				if(listaDatosPoliza.get(i).getNumPoliza().equals(idPolizaNuevo)) {
					if(listaDatosPoliza.get(i).getNumeroSuplemento()==numSuplementoNuevo) 
					return i;		
				}
			}
		}catch(Exception e) {
			LOGGER.error(e.getMessage());
		}
		
		return retorno;
	}
	
	public void insertarPoliza(List<Poliza> listaPolizas) {
		try {
		for(int i=0;i<listaPolizas.size();i++) {
			
		
		String idPolizaNuevo=listaPolizas.get(i).getDatosPoliza().getIdPoliza();
		int numSuplementoNuevo=listaPolizas.get(i).getDatosPoliza().getNumeroSuplemento();
		int num=-1;
		
		if((num=estaPolizaLista(idPolizaNuevo,numSuplementoNuevo))>=0){
			
			
			DatosPersonaJuridico datoPersonaJuridico=actualizaDatoPersonaJuridicoPoliza(listaDatosPoliza.get(num), listaPolizas.get(i));
			listaDatosPoliza.set(num,  datoPersonaJuridico); 
		//	listaDatosPoliza.add(datoPersonaJuridico);
						
		}else {
			
			DatosPersonaJuridico datoPersonaJuridico=generaDatoPersonaJuridicoPoliza(listaPolizas.get(i));
			listaDatosPoliza.add(datoPersonaJuridico);
			
		}
		}
		}catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	
	}
	
	
	public void insertarRecibo(List<Recibo> listaRecibos) {
		try {
		for(int i=0;i<listaRecibos.size();i++) {
			
		String idReciboNuevo=listaRecibos.get(i).getDatosRecibo().getIdRecibo();
		
		
		
		String idPolizaNuevo=listaRecibos.get(i).getDatosPoliza().getIdPoliza();	
		

		int numSuplementoNuevo=listaRecibos.get(i).getDatosPoliza().getNumeroSuplemento();
		int num=-1;
	
		if((num=estaLista(idReciboNuevo,idPolizaNuevo,numSuplementoNuevo))>=0){
						
			DatosPersonaJuridico datoPersonaJuridico=actualizaDatoPersonaRecibo(listaDatosPoliza.get(num), listaRecibos.get(i));
			listaDatosPoliza.set(num, datoPersonaJuridico);
		//	listaDatosPoliza.add(datoPersonaJuridico);
						
		}else {
			
			DatosPersonaJuridico datoPersonaJuridico=generaDatoPersonaJuridicoRecibo(listaRecibos.get(i));
			listaDatosPoliza.add(datoPersonaJuridico);
			
		}
		}
		}catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	
	}
	
	public String cambiaLinea(String linea) {
		
		int totalSeparador=0;
		String cambiado="";
		String resultado="";
		for(int i=0;i<linea.length()-1;i++) {
			if(linea.substring(i, i+1).equalsIgnoreCase("|")) {
				totalSeparador++;
				if(totalSeparador==6) {
					String sublinea=linea.substring(i+1,linea.length());
					boolean finCambio=false;
					for(int j=0;j<sublinea.length();j++) {
						if(sublinea.substring(j,j+1).equalsIgnoreCase("|"))
							finCambio=true;
							if(!finCambio)
						cambiado+="@"+sublinea.substring(j,j+1);
							else
								cambiado+=sublinea.substring(j,j+1);
					}
					
					resultado=linea.substring(0,i+1)+cambiado;
					return resultado;
				}
			}
			
		}
		return "";
	}
	
	public void generarFicheroDiario() {
		
		   StringBuffer fichero= new StringBuffer();
		   StringBuffer ficheroTemp= new StringBuffer();
	    	 String cabecera="co_poliza|num_suplemento|co_mediador|co_producto|co_recibo|tip_documento|cod_documento|co_sit_recibo|co_tipo_recibo|co_period_pago"+"\n";
	    	 fichero.append(cabecera);
	    	 ficheroTemp.append(cabecera);
	    	 NumberFormat formatter = new DecimalFormat("+#000000000000000.00;-#000000000000000.00");     
	
	         for (int i = 0; i <listaDatosPoliza.size(); i++) {
	        	 String linea="";
	    
	        	 linea+=listaDatosPoliza.get(i).getNumPoliza()+"|";
	        	 linea+=listaDatosPoliza.get(i).getNumeroSuplemento()+"|";
	        	 if(listaDatosPoliza.get(i).getMediador()!=null)
	        	 linea+=listaDatosPoliza.get(i).getMediador()+"|";
	        	 else
	        		 linea+=""+"|";
	        	 String prod=listaDatosPoliza.get(i).getProducto();
	        	 if(prod!=null && prod.contains(" "))
	        		 prod=prod.substring(0,prod.indexOf(" "));
	        	 if (prod==null)
	        		 prod="";
	        	 linea+=prod+"|";
	        	 linea+=listaDatosPoliza.get(i).getRecibo()+"|";
	        	 linea+=listaDatosPoliza.get(i).getTipoDoc()+"|";
	        	 linea+=listaDatosPoliza.get(i).getCodDoc()+"|";
	        	 if(listaDatosPoliza.get(i).getSitRecibo()!=null)
	        		 linea+=listaDatosPoliza.get(i).getSitRecibo()+"|";
	        	 else
	        		 linea+=""+"|";
	        	 if(listaDatosPoliza.get(i).getTipoRecibo()!=null)
	        		 linea+=listaDatosPoliza.get(i).getTipoRecibo()+"|";
	        	 else
	        		 linea+=""+"|";
	        	 if(listaDatosPoliza.get(i).getPeridoPago()!=null)
	        	 linea+=listaDatosPoliza.get(i).getPeridoPago()+"\n";
	        	 else
	        		 linea+=""+"\n";
	        	// linea+=listaDatosPoliza.get(i).getStatus()+"\n";
	        	 
	        	// if(listaDatosPoliza.get(i).getStatus().trim().equalsIgnoreCase(""))
	        	 fichero.append(linea);
	        	 ficheroTemp.append(cambiaLinea(linea));
	        	
	        	 
	         }
	         String valorSalida = env.getProperty(PROP_PATH_PREFIX + "out")+"/";
	         
	         String nombreFichero="CONCOMSEG_REPORT_DOC";
	         String nombreFicheroTemp="TEMP_CONCOMSEG_REPORT_DOC";
	 		Date objDate = new Date(); // Sistema actual La fecha y la hora se asignan a objDate 
	 		 
	   
	         String strDateFormat = "yyyyMMdd"; // El formato de fecha está especificado  
	         SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); // La cadena de formato de fecha se pasa como un argumento al objeto 
	         nombreFichero=nombreFichero+"_"+objSDF.format(objDate)+".csv";
	         nombreFicheroTemp=nombreFicheroTemp+"_"+objSDF.format(objDate)+".csv";
	 	/*		ByteArrayOutputStream baos = new ByteArrayOutputStream();
	 		    ObjectOutputStream oos;
				try {
					oos = new ObjectOutputStream(baos);
					oos.write(fichero.toString().getBytes());
	 			    oos.flush();
	 			
	 			    oos.close();*/
	 			    InputStream is = new ByteArrayInputStream( fichero.toString().getBytes());
	 			   InputStream isTemp = new ByteArrayInputStream( ficheroTemp.toString().getBytes());
	 			
	 			try {
					service.uploadBinaryFiles(is, valorSalida,nombreFichero);
					service.uploadBinaryFiles(isTemp, valorSalida,nombreFicheroTemp);
				} catch (SFTPException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
	    
	 		  //  ordenarLista();		
	}
	
	public boolean compruebaFormato(String nombre) {
		
		if(nombre.startsWith("EIAC-ENV-E0189")) 
			return true;
		else return false;
	}
	
	
	@GetMapping("diario/{fecha}")
	public String exportDaily(@PathVariable String fecha) {
	
		ListFilesResponse response = new ListFilesResponse();
		listaDatosPoliza =new ArrayList<>();
		ficherosDia =new ArrayList<>();
	
				try {
					service.connect(config.getSFTPServer(), config.getSFTPPort(),
							config.getSFTPLogin(), config.getSFTPSecret());
					
				} catch (SFTPException e) {
					// TODO Auto-generated catch block
					response.setResult("Error al conectar a la base de datos");
					return "KO";			
			}
		obtenerFicherosDiarios(ficherosDiarios);	
		obtenerPlanos(ficheroDaily);		
		LOGGER.debug("JMLO DB File");
	
		String valor = env.getProperty(PROP_PATH_PREFIX + "in");
		if ((valor == null) || (valor.isEmpty())) {
			valor="in";	
		}
		Path ruta =Paths.get(valor);
		
		List<String>listaRutas =null;
		try {
			listaRutas = service.sftpListFiles(valor+"/*");
		} catch (SftpException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
		}
		
		Collections.sort(listaRutas, new Comparator<String>() {
		    @Override
		    public int compare(String o1, String o2) {
		        return o1.compareTo(o1);
		    }
		});
		
	
		
		List<ProcesosEIAC> listaRecibos= new ArrayList<ProcesosEIAC>();
		List<ProcesosEIACPoliza> listaPolizas= new ArrayList<ProcesosEIACPoliza>();
		for(int i=0;i<listaRutas.size();i++) {
			if(existeDiario(listaRutas.get(i))|| !compruebaFormato(listaRutas.get(i))) {	
				continue;
				
			}else {
				
			String fichero=obtenerFicheroLocal(valor+"/"+listaRutas.get(i));
			if(fichero.contains("<Recibo>")) {
				JAXBContext jaxbContext;
				
				
				LOGGER.debug("FicheroEIACRECIBO  "+i+" "+listaRutas.size()+" "+listaRutas.get(i));
				LOGGER.info("FicheroEIACRECIBO  "+i+" "+listaRutas.size()+" "+listaRutas.get(i));
				
				try
				{
				    jaxbContext = JAXBContext.newInstance(ProcesosEIAC.class);              
				 
				    Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
				 
				    ProcesosEIAC eiac = (ProcesosEIAC) jaxbUnmarshaller.unmarshal(new StringReader(fichero)); 			  
				    ficherosDia.add(listaRutas.get(i));
				    listaRecibos.add(eiac);
				//    int retorno=-1;
				//    if((retorno=listaRecibosEstaLista(eiac))>=0) {
				//    listaDatosPoliza.remove(retorno);
				   // obtenerDatosPersonaJuridicoDummie(eiac,listaRutas.get(i));
				  
				}
				catch (JAXBException e) 
				{
					
					LOGGER.debug("Fichero con error "+listaRutas.get(i));
					LOGGER.error("Fichero con error "+listaRutas.get(i));
					LOGGER.info("Fichero con error "+listaRutas.get(i));
				    e.printStackTrace();
				}	
				
			
				continue;
			}
			else
			if(fichero.contains("<Poliza>")){
		//	fichero=fichero.substring(fichero.indexOf("\">")+3,fichero.length());
			JAXBContext jaxbContext;
			
			
			LOGGER.debug("FicheroEIAC "+i+" "+listaRutas.size()+" "+listaRutas.get(i));
			LOGGER.info("FicheroEIAC "+i+" "+listaRutas.size()+" "+listaRutas.get(i));
			
			try
			{
			    jaxbContext = JAXBContext.newInstance(ProcesosEIACPoliza.class);              
			 
			    Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			 
			    ProcesosEIACPoliza eiac = (ProcesosEIACPoliza) jaxbUnmarshaller.unmarshal(new StringReader(fichero));
		 
			    ficherosDia.add(listaRutas.get(i));
			    listaPolizas.add(eiac);
			//    obtenerDatosPersonaJuridico(eiac,listaRutas.get(i));
			    int posicion=-1;
			  
			}
			catch (JAXBException e) 
			{
			
				LOGGER.debug("Fichero con error "+listaRutas.get(i));
				LOGGER.error("Fichero con error "+listaRutas.get(i));
				LOGGER.info("Fichero con error "+listaRutas.get(i));
			    e.printStackTrace();
			}
			}
			}
		}
				
	//	List<DatosPersonaJuridico> listaJunta=juntarListas(listaPolizas,listaRecibos);
		for(int i=0; i<listaPolizas.size();i++) {
			List<Poliza> nuevaListaPoliza=listaPolizas.get(i).getObjetos().getPoliza();
			insertarPoliza(nuevaListaPoliza);
		}
		
		for(int i=0;i<listaRecibos.size();i++) {
			List<Recibo> nuevaListaRecibo= listaRecibos.get(i).getObjetos().getRecibo();
			insertarRecibo(nuevaListaRecibo);
		}
		String valorSalida = env.getProperty(PROP_PATH_PREFIX + "out")+"/";
		LOGGER.debug("Obtenemos los datos de base de datos");
		
		LOGGER.info("Obtenemos los datos de base de datos");	
	//	ByteArrayInputStream ficheroSalida=obtenerDatosBD();
		
		LOGGER.debug("JMLOBD Datos ya obtenidos");
		LOGGER.debug("JMLOBD Datos ya obtenidos");
		LOGGER.debug("JMLOBD Datos ya obtenidos");
		
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
		    ObjectOutputStream oos = new ObjectOutputStream(baos);
		  //  ordenarLista();
			for(int i=0;i<listaDatosPoliza.size();i++) {				
			    oos.writeObject(listaDatosPoliza.get(i));
			    oos.flush();
		}
			
			LOGGER.debug("JMLODEBUG SUBIDA FICHERO");
			
			LOGGER.info("JMLODEBUG SUBIDA FICHERO");
			
            oos.close();
            InputStream is = new ByteArrayInputStream(baos.toByteArray());
			service.uploadBinaryFiles(is, valorSalida,ficheroDaily);
			
			generarFicheroDiario();
			generaFicheros();
			
			LOGGER.debug("JMLODEBUG SUBIDA FICHERO2");
			
			LOGGER.info("JMLODEBUG SUBIDA FICHERO2");
		} catch (IOException | SFTPException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
		LOGGER.debug("Datos ya obtenidos, enviamso");
		
		LOGGER.info("Datos ya obtenidos, enviamso");
		
		
		String nombreFichero="CONCOMSEG_REPORT";
		Date objDate = new Date(); // Sistema actual La fecha y la hora se asignan a objDate 
		 
  
        String strDateFormat = "yyyyMMdd"; // El formato de fecha está especificado  
        SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); // La cadena de formato de fecha se pasa como un argumento al objeto 
        nombreFichero=nombreFichero+"_"+objSDF.format(objDate)+".csv";
    	LOGGER.debug("Datos ya obtenidos, enviamso2");
		
		LOGGER.info("Datos ya obtenidos, enviamso2");
     
		
	//	response.setFilesList(listaRutas);
        LOGGER.debug("salimosJMLO");
		
		LOGGER.info("salimosJMLO");
	    return "OK";

	
	}	
	
	public void generaFicheros() {
		
		
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
		    ObjectOutputStream oos = new ObjectOutputStream(baos);
		  //  ordenarLista();
			for(int i=0;i<ficherosDia.size();i++) {				
			    oos.writeObject(ficherosDia.get(i));
			    oos.flush();
		}
			
			LOGGER.debug("JMLODEBUG SUBIDA FICHERO");
			
			LOGGER.info("JMLODEBUG SUBIDA FICHERO");
			
            oos.close();
            InputStream is = new ByteArrayInputStream(baos.toByteArray());
        	String valorSalida = env.getProperty(PROP_PATH_PREFIX + "out")+"/";
			service.uploadBinaryFiles(is, valorSalida,ficherosDiarios);
			
		
			
			LOGGER.debug("JMLODEBUG SUBIDA FICHERO2");
			
			LOGGER.info("JMLODEBUG SUBIDA FICHERO2");
		} catch (IOException | SFTPException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
	
	public DatosPersonaJuridico obtenerDatosPersona(String coPoliza) {
		String datos="";
		DatosPersonaJuridico temp=new DatosPersonaJuridico();
		temp.setFecFinSeg("0001-01-01");
		temp.setFecInicioPoliza("0001-01-01");
		
		for(int i=0;i<listaDatosPoliza.size();i++) {
			if(listaDatosPoliza.get(i).getNumPoliza().equals(coPoliza)) {
				temp=listaDatosPoliza.get(i);
			if(!listaDatosPoliza.get(i).getTipSeguro().trim().equals(""))
			return  temp;
			}
		}
		
		return temp;
	}
	
	public boolean productoExiste(List<String> listaProductos,String producto) {
		
		for(int i=0;i<listaProductos.size();i++) {
			String productoActual=listaProductos.get(i);
			if(productoActual.equalsIgnoreCase(producto))
				return true;
		}
		return false;
	}

	private ByteArrayInputStream escribirReport(List<TablaSeleccionRecibo> listaReport,String nombreFichero) {
	    StringBuffer fichero= new StringBuffer();
	    
    	 String cabecera="co_poliza|num_suplemento|co_mediador|co_producto|co_recibo|tip_documento|cod_documento|co_sit_recibo|co_tipo_recibo|co_period_pago|fh_sit_rec|fh_efe_act_rec|fh_vto_rec|fh_emis_rec|im_prim_tot_pol|im_prim_net_pol|im_cargo|com_bruta|com_liquida|ci_est_interno|ci_retr_contab|fh_alta_com|fh_retr_com|fh_ult_period|im_ult_period|im_tot_period|ImpPendiente|co_usuario|fh_modif|FecInicioPoliza|FecFinPoliza|SitPoliza|TipSeguro|"+"\n";
    	 fichero.append(cabecera);
    	 NumberFormat formatter = new DecimalFormat("+#000000000000000.00;-#000000000000000.00");     
         List listaProductos= repository.listaProductos();
         for (int i = 0; i <listaReport.size(); i++) {
        	 
        	
        	 
        	 if(!productoExiste(listaProductos,listaReport.get(i).getCoProducto()))
        		 continue;
        	 String linea="";
        	 
        	 linea+=listaReport.get(i).getCoPoliza()+"|";
        	 linea+=listaReport.get(i).getNumSuplemento()+"|";
        	 if(listaReport.get(i).getCoMediador()!=null)
        	 linea+=listaReport.get(i).getCoMediador()+"|";
        	 else
        		 linea+=""+"|";
        	 linea+=listaReport.get(i).getCoProducto()+"|";      
        	 linea+=listaReport.get(i).getCoRecibo()+"|";
        	  
        	 DatosPersonaJuridico persona=obtenerDatosPersona(listaReport.get(i).getCoPoliza());
        	 
        	 if(persona!=null) {
        		 linea+=persona.getTipoDoc()+"|";
        		 linea+=persona.getCodDoc()+"|";
        	 }else {
        		 linea+="||";
        	 }
        	 
        	 if(listaReport.get(i).getCoSitRecibo()!=null)
        		 linea+=listaReport.get(i).getCoSitRecibo()+"|";
        	 else
        		 linea+=""+"|";
        	 if(listaReport.get(i).getCoTipoRecibo()!=null)
        		 linea+=listaReport.get(i).getCoTipoRecibo()+"|";
        	 else
        		 linea+=""+"|";
        	 if(listaReport.get(i).getCoPeriodPago()!=null)
        	 linea+=listaReport.get(i).getCoPeriodPago()+"|";
        	 else
        		 linea+=""+"|";
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhSitRec().getTime())+"|";
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhEfeActRec().getTime())+"|";
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhVtoRec().getTime())+"|";	        	 
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhEmisRec().getTime())+"|";
        	
        	 linea+=formatter.format(listaReport.get(i).getImPrimTotPol()*-1).replace(",",".")+"|";
        	 linea+=formatter.format(listaReport.get(i).getImPrimNetPol()).replace(",",".")+"|";
        	 linea+=formatter.format(listaReport.get(i).getComBruta()).replace(",",".")+"|";
        	 linea+=formatter.format(listaReport.get(i).getComLiquida()).replace(",",".")+"|";
        	 linea+=listaReport.get(i).getCiEstInterno()+"|";
        	 linea+=listaReport.get(i).getCiRetrContab()+"|";
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhRetrCom().getTime())+"|";
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhAltaCom().getTime())+"|"; 
        	
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhUltPeriod().getTime())+"|";
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhUltPeriod().getTime())+"|";
        	 linea+=formatter.format(listaReport.get(i).getImUltPeriod()).replace(",",".")+"|";

        	 linea+=formatter.format(listaReport.get(i).getImTotPeriod()).replace(",",".")+"|";
        	 //
        	 Double total= new Double(listaReport.get(i).getComLiquida());
        	 Double periodificado= new Double(listaReport.get(i).getImTotPeriod());
        	 Double pendiente= total-periodificado;
        	 
        	 linea+=formatter.format(pendiente).replace(",",".")+"|";
        	 
        	 
        	 linea+=listaReport.get(i).getCoUsuario()+"|";
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhModif().getTime())+"|";
        	 
        	 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        	 Date date=null;
        	 if(persona!=null) {
        		 	try {
        		 		date = sdf.parse(persona.getFecInicioPoliza());
        		 		} catch (ParseException e1) {
				// TODO Auto-generated catch block
        		 		e1.printStackTrace();
        		 		}
        		 	Calendar cal = Calendar.getInstance();
        		 	cal.setTime(date);
        	 
        		 	linea+=new SimpleDateFormat("dd/MM/yyyy").format(cal.getTime())+"|";
        	
        		 	try {
        		 		date = sdf.parse(persona.getFecFinSeg());
        		 	} catch (ParseException e) {
				// TODO Auto-generated catch block
        		 		
        		 		LOGGER.debug("JMLODEBUG excepcion"+e.getMessage());
        			
        				LOGGER.info("JMLODEBUG excepcion"+e.getMessage());
        		 		e.printStackTrace();
        		 	}
        		 	cal = Calendar.getInstance();
        		 	cal.setTime(date);
        	 	 
        		 	linea+=new SimpleDateFormat("dd/MM/yyyy").format(cal.getTime())+"|";
        		 	linea+=persona.getSitPoliza()+"|";
        		 	linea+=persona.getTipSeguro()+"\n";
        	 		}else
        	 				linea+="|||\n";
        	 		fichero.append(linea); 	 
         } 

	 		LOGGER.debug("JMLODEBUG retorno");
			
			LOGGER.info("JMLODEBUG retorno");
         return new ByteArrayInputStream(fichero.toString().getBytes());
        
 //       System.out.print(fichero);

	}
	
public ByteArrayInputStream obtenerDatosBD() {
		
		Date myDate = new Date();
		String fechaFormateada=new SimpleDateFormat("yyyyMMddHHmm").format(myDate);
		List<TablaSeleccionRecibo> listaResultado=repository.reportExport();
		listaResultado.sort(Comparator.comparing(TablaSeleccionRecibo::getCoPoliza));

		//Aquí obtienes el formato que deseas.
	
		String nombreFichero="CONCOMSEG_REPORT_"+fechaFormateada+".csv";
		String ruta=config.getFSOutPath()+nombreFichero;
		
	return	escribirReport(listaResultado,nombreFichero);
	}

public String obtenerCdNegoci(List<Dato> otrosDatos) {
	String negoci="";
	for(int i=0;i<otrosDatos.size();i++) {
		
		if(otrosDatos.get(i).getIdDato().equals("CDNEGOCI")) {
			negoci=otrosDatos.get(i).getValorSubdato().trim();
		return negoci;	
		}
	}
	return negoci;
}

	public void obtenerDatosPersonaJuridico( ProcesosEIACPoliza eiac,String nombreFichero) {
		
		for(int i=0;i<eiac.getObjetos().getPoliza().size();i++) {
			String fecInicio=eiac.getObjetos().getPoliza().get(i).getFechas().getFechaEfectoInicial();
			String situacionPol=eiac.getObjetos().getPoliza().get(i).getSituacionPoliza();
			String fechaFinSeg=eiac.getObjetos().getPoliza().get(i).getFechas().getFechaVencimiento();
			List<Dato> listaTipSeguro=eiac.getObjetos().getPoliza().get(i).getOtrosDatos().getDato();
			
			String tipSeguro=obtenerCdNegoci(listaTipSeguro);
			
			if(eiac.getObjetos().getPoliza().get(i).getTomador().getPersonaFisica()!=null) {
			String nombre=eiac.getObjetos().getPoliza().get(i).getTomador().getPersonaFisica().getNombre();
			String apellido1=eiac.getObjetos().getPoliza().get(i).getTomador().getPersonaFisica().getApellido1();
			String apellido2=eiac.getObjetos().getPoliza().get(i).getTomador().getPersonaFisica().getApellido2();
			String idCliente=eiac.getObjetos().getPoliza().get(i).getTomador().getPersonaFisica().getIdCliente();
			String idPersona=eiac.getObjetos().getPoliza().get(i).getTomador().getPersonaFisica().getIdPersona();
			String idPoliza=eiac.getObjetos().getPoliza().get(i).getDatosPoliza().getIdPoliza();
			String tipoDoc=eiac.getObjetos().getPoliza().get(i).getTomador().getPersonaFisica().getTipoIdentificacion();
			int idSuplemento=eiac.getObjetos().getPoliza().get(i).getDatosPoliza().getNumeroSuplemento();
				
		DatosPersonaJuridico dato= new DatosPersonaJuridico();
		dato.setFichero(nombreFichero);
		dato.setTipoPersona("F");
		dato.setNombre(nombre); 
		dato.setApellido1(apellido1);
		dato.setApellido2(apellido2);
		dato.setIdClienteZurich(idCliente);
		dato.setTipoDoc(tipoDoc);
		dato.setCodDoc(idPersona);
		dato.setNumeroSuplemento(idSuplemento);
		dato.setnumPoliza(idPoliza);
		dato.setFecInicioPoliza(fecInicio);
		dato.setFecFinSeg(fechaFinSeg);
		dato.setSitPoliza(situacionPol);
		dato.setTipSeguro(tipSeguro);
		
		listaDatosPoliza.add(dato);
			}
			else
				if(eiac.getObjetos().getPoliza().get(i).getTomador().getPersonaJuridica()!=null) {
					DatosPersonaJuridico dato= new DatosPersonaJuridico();	
					String idPoliza=eiac.getObjetos().getPoliza().get(i).getDatosPoliza().getIdPoliza();
					String tipoIdentificacion=eiac.getObjetos().getPoliza().get(i).getTomador().getPersonaJuridica().getTipoIdentificacion();
					String idPersona=eiac.getObjetos().getPoliza().get(i).getTomador().getPersonaJuridica().getIdPersona();
					String idCliente=eiac.getObjetos().getPoliza().get(i).getTomador().getPersonaJuridica().getIdCliente();
					int idSuplemento=eiac.getObjetos().getPoliza().get(i).getDatosPoliza().getNumeroSuplemento();
					dato.setFichero(nombreFichero);
					dato.setTipoDoc(tipoIdentificacion);
					dato.setnumPoliza(idPoliza);
					dato.setNumeroSuplemento(idSuplemento);
					dato.setCodDoc(idPersona);
					dato.setIdClienteZurich(idCliente);
					dato.setTipoPersona("J");
					dato.setFecInicioPoliza(fecInicio);
					dato.setFecFinSeg(fechaFinSeg);
					dato.setSitPoliza(situacionPol);
					dato.setTipSeguro(tipSeguro);
					listaDatosPoliza.add(dato);
			}
			
		}
	}
	
	
public void obtenerDatosPersonaJuridicoDummie( ProcesosEIACPoliza eiac,String nombreFichero) {
		
			
		DatosPersonaJuridico dato= new DatosPersonaJuridico();
		dato.setFichero(nombreFichero);
		dato.setTipoPersona("F");
		dato.setNombre(""); 
		dato.setApellido1("");
		dato.setApellido2("");
		dato.setIdClienteZurich("");
		dato.setTipoDoc("");
		dato.setCodDoc("");
		dato.setNumeroSuplemento(0);
		dato.setnumPoliza("");
		dato.setFecInicioPoliza("");
		dato.setFecFinSeg("");
		dato.setSitPoliza("");
		dato.setTipSeguro("");
		
		listaDatosPoliza.add(dato);
			
	}
	
	
	public boolean existePlano(String nombreFichero) {
		
		for(int i=0;i< listaDatosPoliza.size();i++) {
			if(nombreFichero.equals(listaDatosPoliza.get(i).getFichero()))
				return true;
		}
		return false;
	}
	
	public boolean existeDiario(String nombreFichero) {
		
		for(int i=0;i< ficherosDia.size();i++) {
			if(nombreFichero.equals(ficherosDia.get(i)))
				return true;
		}
		return false;
	}
	
	public void obtenerPlanos(String fichero){
		
		String rutaFichero = env.getProperty(PROP_PATH_PREFIX + "out")+"/"+fichero;
		try {
		ByteArrayOutputStream ficheroPlano=	service.sftpDownloadFile(rutaFichero);
		if(ficheroPlano!=null) {
			
			ByteArrayInputStream bis = new ByteArrayInputStream(ficheroPlano.toByteArray());
	         ObjectInputStream in = new ObjectInputStream(bis);
	         
	         while (in.available()>=0) {
	         
	        	 DatosPersonaJuridico dato = (DatosPersonaJuridico) in.readObject();
	           	 listaDatosPoliza.add(dato);
	        	 
	         }
			
		}
		} catch (SftpException | IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace();
		}
	}

	public void obtenerFicherosDiarios(String fichero){
		
		String rutaFichero = env.getProperty(PROP_PATH_PREFIX + "out")+"/"+fichero;
		try {
		ByteArrayOutputStream ficheroPlano=	service.sftpDownloadFile(rutaFichero);
		if(ficheroPlano!=null) {
			
			ByteArrayInputStream bis = new ByteArrayInputStream(ficheroPlano.toByteArray());
	         ObjectInputStream in = new ObjectInputStream(bis);
	         
	         while (in.available()>=0) {
	         
	        	 String dato = (String) in.readObject();
	        	 ficherosDia.add(dato);
	        	 
	         }
			
		}
		} catch (SftpException | IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace();
		}
	}	
	
	
	@GetMapping("export")
	public String exportar() {
	
		ListFilesResponse response = new ListFilesResponse();
		listaDatosPoliza =new ArrayList<>();
	
				try {
					service.connect(config.getSFTPServer(), config.getSFTPPort(),
							config.getSFTPLogin(), config.getSFTPSecret());
					
				} catch (SFTPException e) {
					// TODO Auto-generated catch block
					response.setResult("Error al conectar a la base de datos");
					return "KO";			
				}
					
		obtenerPlanos(ficheroSalidaPlano);		
	
		LOGGER.debug("JMLO DB File");
	
		String valor = env.getProperty(PROP_PATH_PREFIX + "in");
		if ((valor == null) || (valor.isEmpty())) {
			valor="in";	
		}
		Path ruta =Paths.get(valor);
		
		List<String>listaRutas =null;
		try {
			listaRutas = service.sftpListFiles(valor+"/*");
		} catch (SftpException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
		}
		
		
		for(int i=0;i<listaRutas.size();i++) {
			if(existePlano(listaRutas.get(i))) {
				
				LOGGER.debug("FicheroEIACEXISTE "+i+" "+listaRutas.size()+" "+listaRutas.get(i));
				LOGGER.info("FicheroEIACEXISTE "+i+" "+listaRutas.size()+" "+listaRutas.get(i));
				
				continue;
				
			}else {
				
			String fichero=obtenerFicheroLocal(valor+"/"+listaRutas.get(i));
			if(fichero.contains("<Recibo>")) {
				JAXBContext jaxbContext;
				
				
				LOGGER.debug("FicheroEIACRECIBO  "+i+" "+listaRutas.size()+" "+listaRutas.get(i));
				LOGGER.info("FicheroEIACRECIBO  "+i+" "+listaRutas.size()+" "+listaRutas.get(i));
				
				try
				{
				    jaxbContext = JAXBContext.newInstance(ProcesosEIACPoliza.class);              
				 
				    Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
				 
				    ProcesosEIACPoliza eiac = (ProcesosEIACPoliza) jaxbUnmarshaller.unmarshal(new StringReader(fichero));
				    
				    obtenerDatosPersonaJuridicoDummie(eiac,listaRutas.get(i));
				  
				}
				catch (JAXBException e) 
				{
					
					LOGGER.debug("Fichero con error "+listaRutas.get(i));
					LOGGER.error("Fichero con error "+listaRutas.get(i));
					LOGGER.info("Fichero con error "+listaRutas.get(i));
				    e.printStackTrace();
				}	
				
			
				continue;
			}
			else
			if(fichero.contains("<Poliza>")){
		//	fichero=fichero.substring(fichero.indexOf("\">")+3,fichero.length());
			JAXBContext jaxbContext;
			
			
			LOGGER.debug("FicheroEIAC "+i+" "+listaRutas.size()+" "+listaRutas.get(i));
			
			LOGGER.info("FicheroEIAC "+i+" "+listaRutas.size()+" "+listaRutas.get(i));
			
			try
			{
			    jaxbContext = JAXBContext.newInstance(ProcesosEIACPoliza.class);              
			 
			    Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			 
			    ProcesosEIACPoliza eiac = (ProcesosEIACPoliza) jaxbUnmarshaller.unmarshal(new StringReader(fichero));
			    
			    obtenerDatosPersonaJuridico(eiac,listaRutas.get(i));
			  
			}
			catch (JAXBException e) 
			{
				
				LOGGER.debug("Fichero con error "+listaRutas.get(i));
				LOGGER.error("Fichero con error "+listaRutas.get(i));
				LOGGER.info("Fichero con error "+listaRutas.get(i));
			    e.printStackTrace();
			}
			}
			}
		}
		
		String valorSalida = env.getProperty(PROP_PATH_PREFIX + "out")+"/";
		LOGGER.debug("Obtenemos los datos de base de datos");
		
		LOGGER.info("Obtenemos los datos de base de datos");
		ByteArrayInputStream ficheroSalida=obtenerDatosBD();
		
		LOGGER.debug("JMLOBD Datos ya obtenidos");
		LOGGER.debug("JMLOBD Datos ya obtenidos");
		LOGGER.debug("JMLOBD Datos ya obtenidos");
		
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
		    ObjectOutputStream oos = new ObjectOutputStream(baos);
		  //  ordenarLista();
			for(int i=0;i<listaDatosPoliza.size();i++) {				
			    oos.writeObject(listaDatosPoliza.get(i));
			    oos.flush();
		}
			
			LOGGER.debug("JMLODEBUG SUBIDA FICHERO");
			LOGGER.info("JMLODEBUG SUBIDA FICHERO");
			
oos.close();
InputStream is = new ByteArrayInputStream(baos.toByteArray());
			service.uploadBinaryFiles(is, valorSalida,ficheroSalidaPlano);
			
			
			LOGGER.debug("JMLODEBUG SUBIDA FICHERO2");
			LOGGER.info("JMLODEBUG SUBIDA FICHERO2");
		} catch (IOException | SFTPException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
		LOGGER.debug("Datos ya obtenidos, enviamso");
		LOGGER.info("Datos ya obtenidos, enviamso");
		
		
		String nombreFichero="CONCOMSEG_REPORT";
		Date objDate = new Date(); // Sistema actual La fecha y la hora se asignan a objDate 
		 
  
        String strDateFormat = "yyyyMMdd"; // El formato de fecha está especificado  
        SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); // La cadena de formato de fecha se pasa como un argumento al objeto 
        nombreFichero=nombreFichero+"_"+objSDF.format(objDate)+".csv";
    	LOGGER.debug("Datos ya obtenidos, enviamso2");
		
		LOGGER.info("Datos ya obtenidos, enviamso2");
        try {
			service.uploadBinaryFiles(ficheroSalida, valorSalida,nombreFichero);
			
			LOGGER.debug("Datos ya obtenidos, enviamso 3");
			
			LOGGER.info("Datos ya obtenidos, enviamso3");
		} catch (SFTPException e) {
			// TODO Auto-generated catch block
			
			LOGGER.debug("Datos ya obtenidos, enviamso 4"+e.getMessage());
			LOGGER.error("Datos ya obtenidos, enviamso4"+e.getMessage());
			LOGGER.info("Datos ya obtenidos, enviamso4"+e.getMessage());
			e.printStackTrace();
			return "KO";
		}
		
	//	response.setFilesList(listaRutas);
        LOGGER.debug("salimosJMLO");
		
		LOGGER.info("salimosJMLO");
	    return "OK";
	
	}
	
	
	public void ordenarLista() {
		listaDatosPoliza.sort(Comparator.comparing(DatosPersonaJuridico::getNumPoliza));
		//Expresión lambda java8
		/*Collections.sort(listaDatosPoliza, (o1, o2) -> o1.getNumPoliza().compareTo(o2.getNumPoliza()));

		//Clase anónima
		Collections.sort(listaDatosPoliza, new Comparator<DatosPersonaJuridico>() {
		    @Override
		    public int compare(DatosPersonaJuridico o1, DatosPersonaJuridico o2) {
		        return o1.getNumPoliza().compareTo(o1.getNumPoliza());
		    }
		});*/
	}
	
	
	public  String  obtenerFicheroLocal(String ruta) {
					try {
					service.connect(config.getSFTPServer(), config.getSFTPPort(),
							config.getSFTPLogin(), config.getSFTPSecret());
				} catch (SFTPException e) {
					// TODO Auto-generated catch block
			}
			try {
				ByteArrayOutputStream salida = service.sftpDownloadFile(ruta);
			
				
				return salida.toString();

			} catch (SftpException e) {
				String excep= e.getMessage();
				return excep;
				
			}
		
	
	}
	

	@GetMapping("fichero")
	public  String  obtenerFichero(
			@RequestParam(required = false) String ruta
			//@PathVariable String pathCompleto
			) {
	
					try {
					service.connect(config.getSFTPServer(), config.getSFTPPort(),
							config.getSFTPLogin(), config.getSFTPSecret());
				} catch (SFTPException e) {
					// TODO Auto-generated catch block
							
				}

			try {
				ByteArrayOutputStream salida = service.sftpDownloadFile(ruta);
			
				
				return salida.toString();

			} catch (SftpException e) {
				String excep= e.getMessage();
				return excep;
				
			}
		
	
	}
	
	
	public boolean subirExportacion(InputStream fichero) {
		
		String valor = env.getProperty(PROP_PATH_PREFIX + "out")+"/";
		String nombreFichero="CONCOMSEG_REPORT";
		Date objDate = new Date(); // Sistema actual La fecha y la hora se asignan a objDate 
		 
  
        String strDateFormat = "yyyyMMdd"; // El formato de fecha está especificado  
        SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); // La cadena de formato de fecha se pasa como un argumento al objeto 
        nombreFichero=nombreFichero+"_"+objSDF.format(objDate)+".csv";
		
		
		try { 
			service.connect(config.getSFTPServer(), config.getSFTPPort(),
					config.getSFTPLogin(), config.getSFTPSecret());
			
			service.uploadBinaryFiles(fichero, valor,nombreFichero);
		} catch (SFTPException e) {
			// TODO Auto-generated catch block
			LOGGER.error("Error al subir fichero");
			return false;
		}
		return true;
	}
	/**
	 * Sube un fichero a una carpeta determinada.
	 * 
	 * <p>
	 * A través del ID de entrada, buscamos la ruta a la carpeta definida en el properties.
	 * La ruta buscada será: app.filesystem.path-(identificador de entrada).
	 * Por ejemplo: {@code app.filesystem.path-in} o {@code app.filesystem.path-out}
	 * 
	 * <p>
	 * URL acceso: POST .../files/{pathId}
	 * 
	 * @param pathId Identificador de la carpeta
	 * @param file Fichero a subir (formato multipart de un form http)
	 * @param overwrite Si {@code true}, sobreescribe el fichero en caso de ya existir con el mismo nombre
	 * @return OK/KO
	 */
	
public InputStream obtenerFicheroCambio(InputStream ficheroEntrada) {
	StringBuffer ficheroNuevo= new StringBuffer();
	String newLine = System.getProperty("line.separator");
	 BufferedReader reader = new BufferedReader(
	         new InputStreamReader(ficheroEntrada));
	
	 try {
		for (String line; (line = reader.readLine()) != null; ) {
		     if (ficheroNuevo.length() > 0) {
		         ficheroNuevo.append("\n");
		     }
		     line=line.replaceAll("@","");
		     ficheroNuevo.append(line);
		 }
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 
	  InputStream is = new ByteArrayInputStream( ficheroNuevo.toString().getBytes());
	 return is;
	
}
	
@PostMapping("{pathId}")
	public String putFile(@PathVariable String pathId,
			@RequestParam("file") MultipartFile file,
			@RequestParam(value = "overwrite", required = false) Boolean overwrite) {
		// Validar parametro id
		LOGGER.debug("JMLO DB Path");
	
		String valor = env.getProperty(PROP_PATH_PREFIX + pathId)+"/";
			
		try {
			service.connect(config.getSFTPServer(), config.getSFTPPort(),
					config.getSFTPLogin(), config.getSFTPSecret());	
			if(file.getOriginalFilename().startsWith("TEMP_")){
				InputStream ficheroTemp=obtenerFicheroCambio(file.getInputStream());
				service.uploadBinaryFiles(ficheroTemp, valor,file.getOriginalFilename().replaceAll("TEMP_", ""));
			}else
			service.uploadBinaryFiles(file.getInputStream(), valor,file.getOriginalFilename());
		} catch (SFTPException | IOException e) {
			// TODO Auto-generated catch block
			LOGGER.error("JMLOSFTP Error al subir fichero"+e.getMessage());
			LOGGER.info("JMLOSFTP Error al subir fichero"+e.getMessage());
			LOGGER.debug("JMLOSFTP Error al subir fichero"+e.getMessage());
		}

		
		
		return "OK";
	}
	
	/**
	 * Devuelve un fichero de una carpeta determinada.
	 * 
	 * <p>
	 * A través del ID de entrada, buscamos la ruta a la carpeta definida en el properties.
	 * La ruta buscada será: app.filesystem.path-(identificador de entrada).
	 * Por ejemplo: {@code app.filesystem.path-in} o {@code app.filesystem.path-out}
	 * 
	 * <p>
	 * URL acceso: GET .../files/{pathId}/{fileId}
	 * 
	 * @param pathId Identificador de la carpeta
	 * @param fileId Nombre del fichero
	 * @return Fichero encontrado (o descripción del error)
	 */
	@GetMapping("{pathId}/{fileId}")
	public ResponseEntity<Resource> getFile(@PathVariable String pathId, @PathVariable String fileId) {
		LOGGER.debug("JMLO DB Path");
		// Validar que carpeta esté definida en el properties
		if ((pathId == null) || (pathId.isEmpty())) {
			Resource error = new ByteArrayResource(("ERROR: La URL del recurso es incompleta").getBytes());
			return ResponseEntity
					.status(HttpStatus.BAD_REQUEST)
					.contentType(MediaType.TEXT_PLAIN)
					.body(error);
		}
		String path = env.getProperty(PROP_PATH_PREFIX + pathId);
		if ((path == null) || (path.isEmpty())) {
			Resource error = new ByteArrayResource(("ERROR: No existe el recurso '" + pathId + "'").getBytes());
			return ResponseEntity
					.status(HttpStatus.NOT_FOUND)
					.contentType(MediaType.TEXT_PLAIN)
					.body(error);
		}
		
		// Validar que fichero exista en la carpeta
		if ((fileId == null) || (fileId.isEmpty())) {
			Resource error = new ByteArrayResource(("ERROR: La URL del recurso es incompleta").getBytes());
			return ResponseEntity
					.status(HttpStatus.BAD_REQUEST)
					.contentType(MediaType.TEXT_PLAIN)
					.body(error);
		}
		File fichero = new File(path, fileId);
		if (!fichero.exists()) {
			Resource error = new ByteArrayResource(("ERROR: No existe el recurso '" + fileId + "'").getBytes());
			return ResponseEntity
					.status(HttpStatus.NOT_FOUND)
					.contentType(MediaType.TEXT_PLAIN)
					.body(error);
		}
		
		// Fichero existe, devolverlo en la salida
		Resource contenido = new FileSystemResource(fichero);
		return ResponseEntity
				.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fichero.getName() + "\"")
				.contentType(MediaType.APPLICATION_OCTET_STREAM)
				.body(contenido);
	}
	
	/**
	 * Borra un fichero de una carpeta determinada.
	 * 
	 * <p>
	 * A través del ID de entrada, buscamos la ruta a la carpeta definida en el properties.
	 * La ruta buscada será: app.filesystem.path-(identificador de entrada).
	 * Por ejemplo: {@code app.filesystem.path-in} o {@code app.filesystem.path-out}
	 * 
	 * <p>
	 * URL acceso: GET .../files/{pathId}/{fileId}
	 * 
	 * @param pathId Identificador de la carpeta
	 * @param fileId Nombre del fichero
	 * @return OK/KO
	 */
	@DeleteMapping("{pathId}/{fileId}")
	public String deleteFile(@PathVariable String pathId, @PathVariable String fileId) {
		LOGGER.debug("JMLO DB CPath");
		// Validar que carpeta esté definida en el properties
		if ((pathId == null) || (pathId.isEmpty())) {
			return "ERROR: La URL del recurso es incompleta";
		}
		String path = env.getProperty(PROP_PATH_PREFIX + pathId);
		if ((path == null) || (path.isEmpty())) {
			return "ERROR: No existe el recurso '" + pathId + "'";
		}
		
		// Validar que fichero exista en la carpeta
		if ((fileId == null) || (fileId.isEmpty())) {
			return "ERROR: La URL del recurso es incompleta";
		}
		
		
		try {
			service.connect(config.getSFTPServer(), config.getSFTPPort(),
					config.getSFTPLogin(), config.getSFTPSecret());	
			
			service.deleteFile(fileId,path);
		} catch (SFTPException  e) {
			// TODO Auto-generated catch block
			LOGGER.error("JMLOSFTP Error al subir fichero"+e.getMessage());
			LOGGER.info("JMLOSFTP Error al subir fichero"+e.getMessage());
			LOGGER.debug("JMLOSFTP Error al subir fichero"+e.getMessage());
			return "KO";
		}
		return "Fichero borrado correctamente";
	
		
		/*
		File fichero = new File(path, fileId);
		if (!fichero.exists()) {
			return "ERROR: No existe el recurso '" + fileId + "'";
		}
		
		// Fichero existe, devolverlo en la salida
		if (fichero.delete()) {
			return "OK";
		} else {
			return "ERROR: Error técnico al borrar el fichero.";
		}*/
	}
	
	
	@PostMapping(path = "/abc")
	public String createAbc(HttpServletRequest request) throws IOException {
	    StringBuilder builder = new StringBuilder();
	    try (BufferedReader in = request.getReader()) {
	        char[] buf = new char[4096];
	        for (int len; (len = in.read(buf)) > 0; )
	            builder.append(buf, 0, len);
	    }
	    String requestBody = builder.toString();
	    
	    
	    
	    String urlString = "https://pilotowebseguros.grupocmc.es/datos-catastro/coodenadas";
	       URL url = new URL ("https://pilotowebseguros.grupocmc.es/datos-catastro/coodenadas");
	 
	       Security.addProvider (new com.sun.net.ssl.internal.ssl.Provider ());
	 
	       SSLSocketFactory factory = (SSLSocketFactory) SSLSocketFactory.getDefault ();
	       SSLSocket socket = (SSLSocket) factory.createSocket (url.getHost (), 443);
	 
	       PrintWriter out = new PrintWriter (new OutputStreamWriter (socket.getOutputStream ()));
	       out.println ("POST " + urlString + " HTTP/1.1");
	       out.println ();
	       out.flush ();
	 
	       BufferedReader in = new BufferedReader (new InputStreamReader (socket.getInputStream ()));
	 
	       String line;
	     
	       out.close ();
	       in.close ();
	    
	    
	  
	    URL obj= new URL("https://pilotowebseguros.grupocmc.es/datos-catastro/coodenadas");
	    HttpURLConnection postConnection= (HttpURLConnection)obj.openConnection();
	    postConnection.setRequestMethod("POST");
	    postConnection.setRequestProperty("Accept", "application/json, text/plain, */*");
	    postConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36");
	    postConnection.setRequestProperty("Content-Type", "application/json");
	    
	    postConnection.setDoOutput(true);
	    OutputStream os=postConnection.getOutputStream();
	    os.write(requestBody.getBytes());
	    os.flush();
	    os.close();
	    
	    int responseCode=postConnection.getResponseCode();
	    
	    if(responseCode==HttpURLConnection.HTTP_CREATED) {
	    	BufferedReader in2 =new BufferedReader(new InputStreamReader(
	    			postConnection.getInputStream()));
	    	String inputLine;
	    	StringBuffer response=new StringBuffer();
	    	
	    while ((inputLine= in2.readLine())!=null) {
	    	response.append(inputLine);
	    }in2.close();
	    return response.toString();
	    }
		return "";
	    
	   
	}
	

	
	
}
