//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantaci?n de la referencia de enlace (JAXB) XML v2.3.0 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perder?n si se vuelve a compilar el esquema de origen. 
// Generado el: 2019.06.25 a las 12:23:50 PM CEST 
//


package com.isb.gabps.concomseg.sftp.pojo;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Cabecera"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="FechaCreacion" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *                   &lt;element name="Emisor"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="CodigoInterno" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                             &lt;element name="CodigoDGS" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="Receptor"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="CodigoInterno" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/&gt;
 *                             &lt;element name="CodigoDGS" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="DatosProcesos"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="DetalleProcesos"&gt;
 *                               &lt;complexType&gt;
 *                                 &lt;complexContent&gt;
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                     &lt;sequence&gt;
 *                                       &lt;element name="DetalleProceso" maxOccurs="unbounded"&gt;
 *                                         &lt;complexType&gt;
 *                                           &lt;complexContent&gt;
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                               &lt;sequence&gt;
 *                                                 &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                                 &lt;element name="Transaccion" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                                 &lt;element name="Periodo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                                 &lt;element name="FechaDesde" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *                                                 &lt;element name="FechaHasta" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *                                               &lt;/sequence&gt;
 *                                             &lt;/restriction&gt;
 *                                           &lt;/complexContent&gt;
 *                                         &lt;/complexType&gt;
 *                                       &lt;/element&gt;
 *                                     &lt;/sequence&gt;
 *                                   &lt;/restriction&gt;
 *                                 &lt;/complexContent&gt;
 *                               &lt;/complexType&gt;
 *                             &lt;/element&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="DatosLote"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="IdLote" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
 *                             &lt;element name="NumeroFicheros" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
 *                             &lt;element name="SecuenciaFichero" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Objetos"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Recibo" maxOccurs="unbounded"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="DatosPoliza"&gt;
 *                               &lt;complexType&gt;
 *                                 &lt;complexContent&gt;
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                     &lt;sequence&gt;
 *                                       &lt;element name="IdPoliza" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
 *                                       &lt;element name="NumeroSuplemento" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
 *                                       &lt;element name="IdMediador" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/&gt;
 *                                       &lt;element name="ProductoDGS" type="{http://www.w3.org/2001/XMLSchema}unsignedShort"/&gt;
 *                                     &lt;/sequence&gt;
 *                                   &lt;/restriction&gt;
 *                                 &lt;/complexContent&gt;
 *                               &lt;/complexType&gt;
 *                             &lt;/element&gt;
 *                             &lt;element name="DatosRecibo"&gt;
 *                               &lt;complexType&gt;
 *                                 &lt;complexContent&gt;
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                     &lt;sequence&gt;
 *                                       &lt;element name="IdRecibo" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
 *                                       &lt;element name="SituacionRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                       &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                       &lt;element name="FraccionPago" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                       &lt;element name="Fechas"&gt;
 *                                         &lt;complexType&gt;
 *                                           &lt;complexContent&gt;
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                               &lt;sequence&gt;
 *                                                 &lt;element name="FechaSituacion" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *                                                 &lt;element name="FechaEfectoActual" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *                                                 &lt;element name="FechaVencimiento" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *                                                 &lt;element name="FechaEmision" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *                                               &lt;/sequence&gt;
 *                                             &lt;/restriction&gt;
 *                                           &lt;/complexContent&gt;
 *                                         &lt;/complexType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="DatosImportes"&gt;
 *                                         &lt;complexType&gt;
 *                                           &lt;complexContent&gt;
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                               &lt;sequence&gt;
 *                                                 &lt;element name="Importes"&gt;
 *                                                   &lt;complexType&gt;
 *                                                     &lt;complexContent&gt;
 *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                         &lt;sequence&gt;
 *                                                           &lt;element name="PrimaTotal" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *                                                           &lt;element name="PrimaNeta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *                                                           &lt;element name="DatosCargos"&gt;
 *                                                             &lt;complexType&gt;
 *                                                               &lt;complexContent&gt;
 *                                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                   &lt;sequence&gt;
 *                                                                     &lt;element name="Cargo"&gt;
 *                                                                       &lt;complexType&gt;
 *                                                                         &lt;complexContent&gt;
 *                                                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                             &lt;sequence&gt;
 *                                                                               &lt;element name="ClaseCargo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                                                               &lt;element name="Importe" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *                                                                             &lt;/sequence&gt;
 *                                                                           &lt;/restriction&gt;
 *                                                                         &lt;/complexContent&gt;
 *                                                                       &lt;/complexType&gt;
 *                                                                     &lt;/element&gt;
 *                                                                   &lt;/sequence&gt;
 *                                                                 &lt;/restriction&gt;
 *                                                               &lt;/complexContent&gt;
 *                                                             &lt;/complexType&gt;
 *                                                           &lt;/element&gt;
 *                                                         &lt;/sequence&gt;
 *                                                       &lt;/restriction&gt;
 *                                                     &lt;/complexContent&gt;
 *                                                   &lt;/complexType&gt;
 *                                                 &lt;/element&gt;
 *                                               &lt;/sequence&gt;
 *                                             &lt;/restriction&gt;
 *                                           &lt;/complexContent&gt;
 *                                         &lt;/complexType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="DatosComisiones"&gt;
 *                                         &lt;complexType&gt;
 *                                           &lt;complexContent&gt;
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                               &lt;sequence&gt;
 *                                                 &lt;element name="Comision"&gt;
 *                                                   &lt;complexType&gt;
 *                                                     &lt;complexContent&gt;
 *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                         &lt;sequence&gt;
 *                                                           &lt;element name="NumeroOrden" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
 *                                                           &lt;element name="ClaseComision" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                                                           &lt;element name="ComisionBruta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *                                                           &lt;element name="ComisionLiquida" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *                                                         &lt;/sequence&gt;
 *                                                       &lt;/restriction&gt;
 *                                                     &lt;/complexContent&gt;
 *                                                   &lt;/complexType&gt;
 *                                                 &lt;/element&gt;
 *                                               &lt;/sequence&gt;
 *                                             &lt;/restriction&gt;
 *                                           &lt;/complexContent&gt;
 *                                         &lt;/complexType&gt;
 *                                       &lt;/element&gt;
 *                                     &lt;/sequence&gt;
 *                                   &lt;/restriction&gt;
 *                                 &lt;/complexContent&gt;
 *                               &lt;/complexType&gt;
 *                             &lt;/element&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cabecera",
    "objetos"
})
@XmlRootElement(name = "ProcesosEIAC")
public class ProcesosEIACPoliza {
	
	@XmlElement(name = "Cabecera", required = true)
    protected ProcesosEIACPoliza.Cabecera cabecera;
    @XmlElement(name = "Objetos", required = true)
    protected ProcesosEIACPoliza.Objetos objetos;

    /**
     * Obtiene el valor de la propiedad cabecera.
     * 
     * @return
     *     possible object is
     *     {@link ProcesosEIAC.Cabecera }
     *     
     */
    public ProcesosEIACPoliza.Cabecera getCabecera() {
        return cabecera;
    }

    /**
     * Define el valor de la propiedad cabecera.
     * 
     * @param value
     *     allowed object is
     *     {@link ProcesosEIAC.Cabecera }
     *     
     */
    public void setCabecera(ProcesosEIACPoliza.Cabecera value) {
        this.cabecera = value;
    }

    /**
     * Obtiene el valor de la propiedad objetos.
     * 
     * @return
     *     possible object is
     *     {@link ProcesosEIAC.Objetos }
     *     
     */
    public ProcesosEIACPoliza.Objetos getObjetos() {
        return objetos;
    }

    /**
     * Define el valor de la propiedad objetos.
     * 
     * @param value
     *     allowed object is
     *     {@link ProcesosEIAC.Objetos }
     *     
     */
    public void setObjetos(ProcesosEIACPoliza.Objetos value) {
        this.objetos = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="FechaCreacion" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
     *         &lt;element name="Emisor"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="CodigoInterno" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                   &lt;element name="CodigoDGS" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="Receptor"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="CodigoInterno" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/&gt;
     *                   &lt;element name="CodigoDGS" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="DatosProcesos"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="DetalleProcesos"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="DetalleProceso" maxOccurs="unbounded"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                                       &lt;element name="Transaccion" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                                       &lt;element name="Periodo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                                       &lt;element name="FechaDesde" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
     *                                       &lt;element name="FechaHasta" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="DatosLote"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="IdLote" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
     *                   &lt;element name="NumeroFicheros" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
     *                   &lt;element name="SecuenciaFichero" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "fechaCreacion",
        "emisor",
        "receptor",
        "datosProcesos",
        "datosLote",
        "version"
    })
    @XmlRootElement
    public static class Cabecera {
    
        @XmlElement(name = "FechaCreacion", required = true)
        @XmlSchemaType(name = "date")
        protected XMLGregorianCalendar fechaCreacion;
        @XmlElement(name = "Emisor", required = true)
        protected ProcesosEIAC.Cabecera.Emisor emisor;
        @XmlElement(name = "Receptor", required = true)
        protected ProcesosEIAC.Cabecera.Receptor receptor;
        @XmlElement(name = "DatosProcesos", required = true)
        protected ProcesosEIAC.Cabecera.DatosProcesos datosProcesos;
        @XmlElement(name = "DatosLote", required = true)
        protected ProcesosEIAC.Cabecera.DatosLote datosLote;
        @XmlElement(name = "Version", required = true)
        protected BigDecimal version;

        /**
         * Obtiene el valor de la propiedad fechaCreacion.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getFechaCreacion() {
            return fechaCreacion;
        }

        /**
         * Define el valor de la propiedad fechaCreacion.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setFechaCreacion(XMLGregorianCalendar value) {
            this.fechaCreacion = value;
        }

        /**
         * Obtiene el valor de la propiedad emisor.
         * 
         * @return
         *     possible object is
         *     {@link ProcesosEIAC.Cabecera.Emisor }
         *     
         */
        public ProcesosEIAC.Cabecera.Emisor getEmisor() {
            return emisor;
        }

        /**
         * Define el valor de la propiedad emisor.
         * 
         * @param value
         *     allowed object is
         *     {@link ProcesosEIAC.Cabecera.Emisor }
         *     
         */
        public void setEmisor(ProcesosEIAC.Cabecera.Emisor value) {
            this.emisor = value;
        }

        /**
         * Obtiene el valor de la propiedad receptor.
         * 
         * @return
         *     possible object is
         *     {@link ProcesosEIAC.Cabecera.Receptor }
         *     
         */
        public ProcesosEIAC.Cabecera.Receptor getReceptor() {
            return receptor;
        }

        /**
         * Define el valor de la propiedad receptor.
         * 
         * @param value
         *     allowed object is
         *     {@link ProcesosEIAC.Cabecera.Receptor }
         *     
         */
        public void setReceptor(ProcesosEIAC.Cabecera.Receptor value) {
            this.receptor = value;
        }

        /**
         * Obtiene el valor de la propiedad datosProcesos.
         * 
         * @return
         *     possible object is
         *     {@link ProcesosEIAC.Cabecera.DatosProcesos }
         *     
         */
        public ProcesosEIAC.Cabecera.DatosProcesos getDatosProcesos() {
            return datosProcesos;
        }

        /**
         * Define el valor de la propiedad datosProcesos.
         * 
         * @param value
         *     allowed object is
         *     {@link ProcesosEIAC.Cabecera.DatosProcesos }
         *     
         */
        public void setDatosProcesos(ProcesosEIAC.Cabecera.DatosProcesos value) {
            this.datosProcesos = value;
        }

        /**
         * Obtiene el valor de la propiedad datosLote.
         * 
         * @return
         *     possible object is
         *     {@link ProcesosEIAC.Cabecera.DatosLote }
         *     
         */
        public ProcesosEIAC.Cabecera.DatosLote getDatosLote() {
            return datosLote;
        }

        /**
         * Define el valor de la propiedad datosLote.
         * 
         * @param value
         *     allowed object is
         *     {@link ProcesosEIAC.Cabecera.DatosLote }
         *     
         */
        public void setDatosLote(ProcesosEIAC.Cabecera.DatosLote value) {
            this.datosLote = value;
        }

        /**
         * Obtiene el valor de la propiedad version.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getVersion() {
            return version;
        }

        /**
         * Define el valor de la propiedad version.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setVersion(BigDecimal value) {
            this.version = value;
        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="IdLote" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
         *         &lt;element name="NumeroFicheros" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
         *         &lt;element name="SecuenciaFichero" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "idLote",
            "numeroFicheros",
            "secuenciaFichero"
        })
        public static class DatosLote {

            @XmlElement(name = "IdLote", required = true)
            @XmlSchemaType(name = "unsignedLong")
            protected BigInteger idLote;
            @XmlElement(name = "NumeroFicheros")
            @XmlSchemaType(name = "unsignedByte")
            protected short numeroFicheros;
            @XmlElement(name = "SecuenciaFichero")
            @XmlSchemaType(name = "unsignedByte")
            protected short secuenciaFichero;

            /**
             * Obtiene el valor de la propiedad idLote.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getIdLote() {
                return idLote;
            }

            /**
             * Define el valor de la propiedad idLote.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setIdLote(BigInteger value) {
                this.idLote = value;
            }

            /**
             * Obtiene el valor de la propiedad numeroFicheros.
             * 
             */
            public short getNumeroFicheros() {
                return numeroFicheros;
            }

            /**
             * Define el valor de la propiedad numeroFicheros.
             * 
             */
            public void setNumeroFicheros(short value) {
                this.numeroFicheros = value;
            }

            /**
             * Obtiene el valor de la propiedad secuenciaFichero.
             * 
             */
            public short getSecuenciaFichero() {
                return secuenciaFichero;
            }

            /**
             * Define el valor de la propiedad secuenciaFichero.
             * 
             */
            public void setSecuenciaFichero(short value) {
                this.secuenciaFichero = value;
            }

        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="DetalleProcesos"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="DetalleProceso" maxOccurs="unbounded"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                             &lt;element name="Transaccion" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                             &lt;element name="Periodo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                             &lt;element name="FechaDesde" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
         *                             &lt;element name="FechaHasta" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "detalleProcesos"
        })
        public static class DatosProcesos {

            @XmlElement(name = "DetalleProcesos", required = true)
            protected ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos detalleProcesos;

            /**
             * Obtiene el valor de la propiedad detalleProcesos.
             * 
             * @return
             *     possible object is
             *     {@link ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos }
             *     
             */
            public ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos getDetalleProcesos() {
                return detalleProcesos;
            }

            /**
             * Define el valor de la propiedad detalleProcesos.
             * 
             * @param value
             *     allowed object is
             *     {@link ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos }
             *     
             */
            public void setDetalleProcesos(ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos value) {
                this.detalleProcesos = value;
            }


            /**
             * <p>Clase Java para anonymous complex type.
             * 
             * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="DetalleProceso" maxOccurs="unbounded"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *                   &lt;element name="Transaccion" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *                   &lt;element name="Periodo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *                   &lt;element name="FechaDesde" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
             *                   &lt;element name="FechaHasta" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "detalleProceso"
            })
            public static class DetalleProcesos {

                @XmlElement(name = "DetalleProceso", required = true)
                protected List<ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos.DetalleProceso> detalleProceso;

                /**
                 * Gets the value of the detalleProceso property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the detalleProceso property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getDetalleProceso().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos.DetalleProceso }
                 * 
                 * 
                 */
                public List<ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos.DetalleProceso> getDetalleProceso() {
                    if (detalleProceso == null) {
                        detalleProceso = new ArrayList<ProcesosEIAC.Cabecera.DatosProcesos.DetalleProcesos.DetalleProceso>();
                    }
                    return this.detalleProceso;
                }


                /**
                 * <p>Clase Java para anonymous complex type.
                 * 
                 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
                 *         &lt;element name="Transaccion" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
                 *         &lt;element name="Periodo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
                 *         &lt;element name="FechaDesde" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
                 *         &lt;element name="FechaHasta" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "claseRecibo",
                    "transaccion",
                    "periodo",
                    "fechaDesde",
                    "fechaHasta"
                })
                public static class DetalleProceso {

                    @XmlElement(name = "ClaseRecibo", required = true)
                    protected String claseRecibo;
                    @XmlElement(name = "Transaccion", required = true)
                    protected String transaccion;
                    @XmlElement(name = "Periodo", required = true)
                    protected String periodo;
                    @XmlElement(name = "FechaDesde", required = true)
                    @XmlSchemaType(name = "date")
                    protected XMLGregorianCalendar fechaDesde;
                    @XmlElement(name = "FechaHasta", required = true)
                    @XmlSchemaType(name = "date")
                    protected XMLGregorianCalendar fechaHasta;

                    /**
                     * Obtiene el valor de la propiedad claseRecibo.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getClaseRecibo() {
                        return claseRecibo;
                    }

                    /**
                     * Define el valor de la propiedad claseRecibo.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setClaseRecibo(String value) {
                        this.claseRecibo = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad transaccion.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getTransaccion() {
                        return transaccion;
                    }

                    /**
                     * Define el valor de la propiedad transaccion.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setTransaccion(String value) {
                        this.transaccion = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad periodo.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getPeriodo() {
                        return periodo;
                    }

                    /**
                     * Define el valor de la propiedad periodo.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setPeriodo(String value) {
                        this.periodo = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad fechaDesde.
                     * 
                     * @return
                     *     possible object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public XMLGregorianCalendar getFechaDesde() {
                        return fechaDesde;
                    }

                    /**
                     * Define el valor de la propiedad fechaDesde.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public void setFechaDesde(XMLGregorianCalendar value) {
                        this.fechaDesde = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad fechaHasta.
                     * 
                     * @return
                     *     possible object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public XMLGregorianCalendar getFechaHasta() {
                        return fechaHasta;
                    }

                    /**
                     * Define el valor de la propiedad fechaHasta.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link XMLGregorianCalendar }
                     *     
                     */
                    public void setFechaHasta(XMLGregorianCalendar value) {
                        this.fechaHasta = value;
                    }

                }

            }

        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="CodigoInterno" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *         &lt;element name="CodigoDGS" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "codigoInterno",
            "codigoDGS"
        })
        public static class Emisor {

            @XmlElement(name = "CodigoInterno", required = true)
            protected String codigoInterno;
            @XmlElement(name = "CodigoDGS", required = true)
            protected String codigoDGS;

            /**
             * Obtiene el valor de la propiedad codigoInterno.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCodigoInterno() {
                return codigoInterno;
            }

            /**
             * Define el valor de la propiedad codigoInterno.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCodigoInterno(String value) {
                this.codigoInterno = value;
            }

            /**
             * Obtiene el valor de la propiedad codigoDGS.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCodigoDGS() {
                return codigoDGS;
            }

            /**
             * Define el valor de la propiedad codigoDGS.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCodigoDGS(String value) {
                this.codigoDGS = value;
            }

        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="CodigoInterno" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/&gt;
         *         &lt;element name="CodigoDGS" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "codigoInterno",
            "codigoDGS"
        })
        public static class Receptor {

            @XmlElement(name = "CodigoInterno")
            @XmlSchemaType(name = "unsignedInt")
            protected String codigoInterno;
            @XmlElement(name = "CodigoDGS", required = true)
            protected String codigoDGS;

            /**
             * Obtiene el valor de la propiedad codigoInterno.
             * 
             */
            public String getCodigoInterno() {
                return codigoInterno;
            }

            /**
             * Define el valor de la propiedad codigoInterno.
             * 
             */
            public void setCodigoInterno(String value) {
                this.codigoInterno = value;
            }

            /**
             * Obtiene el valor de la propiedad codigoDGS.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCodigoDGS() {
                return codigoDGS;
            }

            /**
             * Define el valor de la propiedad codigoDGS.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCodigoDGS(String value) {
                this.codigoDGS = value;
            }

        }

    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Recibo" maxOccurs="unbounded"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="DatosPoliza"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="IdPoliza" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
     *                             &lt;element name="NumeroSuplemento" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
     *                             &lt;element name="IdMediador" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/&gt;
     *                             &lt;element name="ProductoDGS" type="{http://www.w3.org/2001/XMLSchema}unsignedShort"/&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="DatosRecibo"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="IdRecibo" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
     *                             &lt;element name="SituacionRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                             &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                             &lt;element name="FraccionPago" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                             &lt;element name="Fechas"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="FechaSituacion" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
     *                                       &lt;element name="FechaEfectoActual" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
     *                                       &lt;element name="FechaVencimiento" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
     *                                       &lt;element name="FechaEmision" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="DatosImportes"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="Importes"&gt;
     *                                         &lt;complexType&gt;
     *                                           &lt;complexContent&gt;
     *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                               &lt;sequence&gt;
     *                                                 &lt;element name="PrimaTotal" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
     *                                                 &lt;element name="PrimaNeta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
     *                                                 &lt;element name="DatosCargos"&gt;
     *                                                   &lt;complexType&gt;
     *                                                     &lt;complexContent&gt;
     *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                         &lt;sequence&gt;
     *                                                           &lt;element name="Cargo"&gt;
     *                                                             &lt;complexType&gt;
     *                                                               &lt;complexContent&gt;
     *                                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                                   &lt;sequence&gt;
     *                                                                     &lt;element name="ClaseCargo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                                                                     &lt;element name="Importe" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
     *                                                                   &lt;/sequence&gt;
     *                                                                 &lt;/restriction&gt;
     *                                                               &lt;/complexContent&gt;
     *                                                             &lt;/complexType&gt;
     *                                                           &lt;/element&gt;
     *                                                         &lt;/sequence&gt;
     *                                                       &lt;/restriction&gt;
     *                                                     &lt;/complexContent&gt;
     *                                                   &lt;/complexType&gt;
     *                                                 &lt;/element&gt;
     *                                               &lt;/sequence&gt;
     *                                             &lt;/restriction&gt;
     *                                           &lt;/complexContent&gt;
     *                                         &lt;/complexType&gt;
     *                                       &lt;/element&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="DatosComisiones"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="Comision"&gt;
     *                                         &lt;complexType&gt;
     *                                           &lt;complexContent&gt;
     *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                               &lt;sequence&gt;
     *                                                 &lt;element name="NumeroOrden" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
     *                                                 &lt;element name="ClaseComision" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *                                                 &lt;element name="ComisionBruta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
     *                                                 &lt;element name="ComisionLiquida" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
     *                                               &lt;/sequence&gt;
     *                                             &lt;/restriction&gt;
     *                                           &lt;/complexContent&gt;
     *                                         &lt;/complexType&gt;
     *                                       &lt;/element&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "poliza"
    })
    public static class Objetos {
    	

        @XmlElement(name = "Poliza", required = true)
        protected List<ProcesosEIACPoliza.Objetos.Poliza> poliza;

        /**
         * Gets the value of the recibo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the recibo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRecibo().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link ProcesosEIAC.Objetos.Recibo }
         * 
         * 
         */
        public List<ProcesosEIACPoliza.Objetos.Poliza> getPoliza() {
            if (poliza == null) {
                poliza = new ArrayList<ProcesosEIACPoliza.Objetos.Poliza>();
            }
            return this.poliza;
        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="DatosPoliza"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="IdPoliza" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
         *                   &lt;element name="NumeroSuplemento" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
         *                   &lt;element name="IdMediador" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/&gt;
         *                   &lt;element name="ProductoDGS" type="{http://www.w3.org/2001/XMLSchema}unsignedShort"/&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="DatosRecibo"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="IdRecibo" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
         *                   &lt;element name="SituacionRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                   &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                   &lt;element name="FraccionPago" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                   &lt;element name="Fechas"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="FechaSituacion" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
         *                             &lt;element name="FechaEfectoActual" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
         *                             &lt;element name="FechaVencimiento" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
         *                             &lt;element name="FechaEmision" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="DatosImportes"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="Importes"&gt;
         *                               &lt;complexType&gt;
         *                                 &lt;complexContent&gt;
         *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                     &lt;sequence&gt;
         *                                       &lt;element name="PrimaTotal" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
         *                                       &lt;element name="PrimaNeta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
         *                                       &lt;element name="DatosCargos"&gt;
         *                                         &lt;complexType&gt;
         *                                           &lt;complexContent&gt;
         *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                               &lt;sequence&gt;
         *                                                 &lt;element name="Cargo"&gt;
         *                                                   &lt;complexType&gt;
         *                                                     &lt;complexContent&gt;
         *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                                         &lt;sequence&gt;
         *                                                           &lt;element name="ClaseCargo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                                                           &lt;element name="Importe" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
         *                                                         &lt;/sequence&gt;
         *                                                       &lt;/restriction&gt;
         *                                                     &lt;/complexContent&gt;
         *                                                   &lt;/complexType&gt;
         *                                                 &lt;/element&gt;
         *                                               &lt;/sequence&gt;
         *                                             &lt;/restriction&gt;
         *                                           &lt;/complexContent&gt;
         *                                         &lt;/complexType&gt;
         *                                       &lt;/element&gt;
         *                                     &lt;/sequence&gt;
         *                                   &lt;/restriction&gt;
         *                                 &lt;/complexContent&gt;
         *                               &lt;/complexType&gt;
         *                             &lt;/element&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="DatosComisiones"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="Comision"&gt;
         *                               &lt;complexType&gt;
         *                                 &lt;complexContent&gt;
         *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                     &lt;sequence&gt;
         *                                       &lt;element name="NumeroOrden" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
         *                                       &lt;element name="ClaseComision" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
         *                                       &lt;element name="ComisionBruta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
         *                                       &lt;element name="ComisionLiquida" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
         *                                     &lt;/sequence&gt;
         *                                   &lt;/restriction&gt;
         *                                 &lt;/complexContent&gt;
         *                               &lt;/complexType&gt;
         *                             &lt;/element&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "datosPoliza",
            "situacionPoliza",
            "clasePoliza",
            "fraccionPago",
            "gestionCobro",
            "datosAnulacion",
            "fechas",
            "duracionPoliza",
            "datosImportes",
            "titular",
            "tomador",
            "asegurado",
            "otrosDatos"
        })
        public static class Poliza {

            public String getSituacionPoliza() {
				return situacionPoliza;
			}

			public void setSituacionPoliza(String situacionPoliza) {
				this.situacionPoliza = situacionPoliza;
			}
			
			public ProcesosEIACPoliza.Objetos.Poliza.DatosAnulacion getDatosAnulacion() {
				return datosAnulacion;
			}

			public void setDatosAnulacion(ProcesosEIACPoliza.Objetos.Poliza.DatosAnulacion DatosAnulacion) {
				this.datosAnulacion = datosAnulacion;
			}
			
			

			public ProcesosEIACPoliza.Objetos.Poliza.Fechas getFechas() {
				return fechas;
			}

			public void setFechas(ProcesosEIACPoliza.Objetos.Poliza.Fechas fechas) {
				this.fechas = fechas;
			}
			
			

			public void setTomador(ProcesosEIACPoliza.Objetos.Poliza.Tomador tomador) {
				this.tomador = tomador;
			}
			@XmlElement(name = "DatosPoliza", required = true)
            protected ProcesosEIACPoliza.Objetos.Poliza.DatosPoliza datosPoliza;
            public ProcesosEIACPoliza.Objetos.Poliza.OtrosDatos getOtrosDatos() {
				return otrosDatos;
			}

			public void setOtrosDatos(ProcesosEIACPoliza.Objetos.Poliza.OtrosDatos otrosDatos) {
				this.otrosDatos = otrosDatos;
			}
			
            public String getFraccionPago() {
				return fraccionPago;
			}

			public void setFraccionPago(String fraccionPago) {
				this.fraccionPago = fraccionPago;
			}
			public String getClasePoliza() {
				return clasePoliza;
			}

			public void setClasePoliza(String clasePoliza) {
				this.clasePoliza = clasePoliza;
			}
			

			public ProcesosEIACPoliza.Objetos.Poliza.Tomador getAsegurado() {
				return asegurado;
			}

			public void setAsegurado(ProcesosEIACPoliza.Objetos.Poliza.Tomador asegurado) {
				this.asegurado = asegurado;
			}
			@XmlElement(name = "SituacionPoliza", required = true)
            protected String situacionPoliza;
			@XmlElement(name = "ClasePoliza", required = true)
            protected String  clasePoliza;
		
			@XmlElement(name = "FraccionPago", required = false)
            protected String fraccionPago;
			
			 @XmlElement(name = "GestionCobro", required = true)
             protected ProcesosEIAC.Objetos.Recibo.DatosRecibo.GestionCobro gestionCobro;
		
			public ProcesosEIAC.Objetos.Recibo.DatosRecibo.GestionCobro getGestionCobro() {
				return gestionCobro;
			}

			public void setGestionCobro(ProcesosEIAC.Objetos.Recibo.DatosRecibo.GestionCobro gestionCobro) {
				this.gestionCobro = gestionCobro;
			}
			
			@XmlElement(name = "DatosAnulacion", required = false)
			
            protected ProcesosEIACPoliza.Objetos.Poliza.DatosAnulacion datosAnulacion;
			
			@XmlElement(name = "Fechas", required = true)
			
            protected ProcesosEIACPoliza.Objetos.Poliza.Fechas fechas;
			
			@XmlElement(name = "DuracionPoliza", required = true)
            protected String duracionPoliza;
			
			@XmlElement(name = "DatosImportes", required = true)
            protected ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes datosImportes;
			
			public ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes getDatosImportes() {
				return datosImportes;
			}

			public void setDatosImportes(ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes datosImportes) {
				this.datosImportes = datosImportes;
			}

			//@XmlElement(name = "Iban", required = false)
	        //protected String iban;
            @XmlElement(name = "Titular", required = false)
            protected ProcesosEIACPoliza.Objetos.Poliza.Titular titular;
            @XmlElement(name = "Tomador", required = false)
            protected ProcesosEIACPoliza.Objetos.Poliza.Tomador tomador;
            @XmlElement(name = "Asegurado", required = false)
            protected ProcesosEIACPoliza.Objetos.Poliza.Tomador asegurado;
            @XmlElement(name = "OtrosDatos", required = false)
            protected ProcesosEIACPoliza.Objetos.Poliza.OtrosDatos otrosDatos; 
            /**
             * Obtiene el valor de la propiedad datosPoliza.
             * 
             * @return
             *     possible object is
             *     {@link ProcesosEIAC.Objetos.Recibo.DatosPoliza }
             *     
             */
            public String getDuracionPoliza() {
				return duracionPoliza;
			}

			public void setDuracionPoliza(String duracionPoliza) {
				this.duracionPoliza = duracionPoliza;
			}
            public ProcesosEIACPoliza.Objetos.Poliza.DatosPoliza getDatosPoliza() {
                return datosPoliza;
            }

            /**
             * Define el valor de la propiedad datosPoliza.
             * 
             * @param value
             *     allowed object is
             *     {@link ProcesosEIAC.Objetos.Recibo.DatosPoliza }
             *     
             */
            public void setDatosPoliza(ProcesosEIACPoliza.Objetos.Poliza.DatosPoliza value) {
                this.datosPoliza = value;
            }
            

            /**
             * Obtiene el valor de la propiedad datosRecibo.
             * 
             * @return
             *     possible object is
             *     {@link Iban }
             *     
             */
     
            
            /**
             * Define el valor de la propiedad datosRecibo.
             * 
             * @param value
             *     allowed object is
             *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo }
             *     
             */
    
            

            /**
             * Obtiene el valor de la propiedad datosRecibo.
             * 
             * @return
             *     possible object is
             *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo }
             *     
             */
            public ProcesosEIACPoliza.Objetos.Poliza.Titular getTitular() {
                return titular;
            }

            /**
             * Define el valor de la propiedad datosRecibo.
             * 
             * @param value
             *     allowed object is
             *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo }
             *     
             */
            public void setTitular(ProcesosEIACPoliza.Objetos.Poliza.Titular value) {
                this.titular = value;
            }
            
            
            /**
             * Obtiene el valor de la propiedad datosRecibo.
             * 
             * @return
             *     possible object is
             *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo }
             *     
             */
            public ProcesosEIACPoliza.Objetos.Poliza.Tomador getTomador() {
                return tomador;
            }

            /**
             * Define el valor de la propiedad datosRecibo.
             * 
             * @param value
             *     allowed object is
             *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo }
             *     
             */
            public void setTitular(ProcesosEIACPoliza.Objetos.Poliza.Tomador value) {
                this.tomador = value;
            }
            
            
            
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "dato"
            })
            
            public static class OtrosDatos {
            	
            	@XmlElement(name = "Dato", required = false)
                protected List<Dato>  dato;

				public List<Dato> getDato() {
					return dato;
				}

			
            	
            }
            
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
            	"numeroOrden",
                "idDato",
                "descripcionDato",
                "idSubdato",
                "valorSubdato"
            })
            
            
                
            public static class Dato {

                public String getNumeroOrden() {
					return numeroOrden;
				}
				public void setNumeroOrden(String numeroOrden) {
					this.numeroOrden = numeroOrden;
				}
				public String getIdDato() {
					return idDato;
				}
				public void setIdDato(String idDato) {
					this.idDato = idDato;
				}
				public String getDescripcionDato() {
					return descripcionDato;
				}
				public void setDescripcionDato(String descripcionDato) {
					this.descripcionDato = descripcionDato;
				}
				public String getIdSubdato() {
					return idSubdato;
				}
				public void setIdSubdato(String idSubdato) {
					this.idSubdato = idSubdato;
				}
				public String getValorSubdato() {
					return valorSubdato;
				}
				public void setValorSubdato(String valorSubdato) {
					this.valorSubdato = valorSubdato;
				}
				@XmlElement(name = "NumeroOrden", required = false)
                protected String numeroOrden;
                @XmlElement(name = "IdDato", required = false)
                protected String idDato;
                @XmlElement(name = "DescripcionDato", required = false)
                protected String descripcionDato;
                @XmlElement(name = "IdSubdato", required = false)
                protected String idSubdato;
                @XmlElement(name = "ValorSubdato", required = false)
                protected String valorSubdato;
            }                  
                
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
            	"personaFisica"
            })    
            
            public static class Titular {

                @XmlElement(name = "PersonaFisica", required = false)
                protected ProcesosEIACPoliza.Objetos.Poliza.PersonaFisica personaFisica;
            

                /**
                 * Obtiene el valor de la propiedad codigoInterno.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public ProcesosEIACPoliza.Objetos.Poliza.PersonaFisica getPersonaFisica() {
                    return personaFisica;
                }

                /**
                 * Define el valor de la propiedad codigoInterno.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setPersonaFisica(ProcesosEIACPoliza.Objetos.Poliza.PersonaFisica value) {
                    this.personaFisica = value;
                }

            } 


            /**
             * <p>Clase Java para anonymous complex type.
             * 
             * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="IdPoliza" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
             *         &lt;element name="NumeroSuplemento" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
             *         &lt;element name="IdMediador" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/&gt;
             *         &lt;element name="ProductoDGS" type="{http://www.w3.org/2001/XMLSchema}unsignedShort"/&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "fechaAnulacion",
                "motivoAnulacion",
                "detalleAnulacion"
            })
            
            public static class DatosAnulacion {

              
				@XmlElement(name = "FechaAnulacion")
                protected String fechaAnulacion;
                @XmlElement(name = "MotivoAnulacion")
                protected String motivoAnulacion;
                @XmlElement(name = "DetalleAnulacion")
                protected String detalleAnulacion;
                
                public String getFechaAnulacion() {
					return fechaAnulacion;
				}
				public void setFechaAnulacion(String fechaAnulacion) {
					this.fechaAnulacion = fechaAnulacion;
				}
				public String getMotivoAnulacion() {
					return motivoAnulacion;
				}
				public void setMotivoAnulacion(String motivoAnulacion) {
					this.motivoAnulacion = motivoAnulacion;
				}
				public String getDetalleAnulacion() {
					return detalleAnulacion;
				}
				public void setDetalleAnulacion(String detalleAnulacion) {
					this.detalleAnulacion = detalleAnulacion;
				}
                
            }
                 
            
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "fechaSituacion",
                "fechaEfectoInicial",
                "fechaEfectoActual",
                "fechaVencimiento",
                "fechaEmision"
            })
            
            public static class Fechas {

              
				@XmlElement(name = "FechaSituacion")
                protected String fechaSituacion;
                @XmlElement(name = "FechaEfectoInicial")
                protected String fechaEfectoInicial;
                @XmlElement(name = "FechaEfectoActual")
                protected String fechaEfectoActual;
                @XmlElement(name = "FechaVencimiento")
                protected String fechaVencimiento;
                @XmlElement(name = "FechaEmision")
                protected String fechaEmision;
                public String getFechaSituacion() {
					return fechaSituacion;
				}
				public void setFechaSituacion(String fechaSituacion) {
					this.fechaSituacion = fechaSituacion;
				}
				public String getFechaEfectoInicial() {
					return fechaEfectoInicial;
				}
				public void setFechaEfectoInicial(String fechaEfectoInicial) {
					this.fechaEfectoInicial = fechaEfectoInicial;
				}
				public String getFechaEfectoActual() {
					return fechaEfectoActual;
				}
				public void setFechaEfectoActual(String fechaEfectoActual) {
					this.fechaEfectoActual = fechaEfectoActual;
				}
				public String getFechaVencimiento() {
					return fechaVencimiento;
				}
				public void setFechaVencimiento(String fechaVencimiento) {
					this.fechaVencimiento = fechaVencimiento;
				}
				public String getFechaEmision() {
					return fechaEmision;
				}
				public void setFechaEmision(String fechaEmision) {
					this.fechaEmision = fechaEmision;
				}
                
            }
            
            
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "idPoliza",
                "numeroSuplemento",
                "ramo",
                "datosMediador"
            })
            public static class DatosPoliza {

                @XmlElement(name = "IdPoliza", required = true)
                protected String idPoliza;
                @XmlElement(name = "NumeroSuplemento")
                @XmlSchemaType(name = "unsignedByte")
                protected Integer numeroSuplemento;               
                @XmlElement(name = "DatosRamo")
                protected ProcesosEIACPoliza.Objetos.Poliza.DatosPoliza.DatosRamo ramo;
                @XmlElement(name = "DatosMediador")
                protected DatosMediador datosMediador;
               

				public DatosMediador getDatosMediador() {
					return datosMediador;
				}

				public void setDatosMediador(DatosMediador datosMediador) {
					this.datosMediador = datosMediador;
				}

				/**
                 * Obtiene el valor de la propiedad idPoliza.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public String getIdPoliza() {
                    return idPoliza;
                }

                /**
                 * Define el valor de la propiedad idPoliza.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setIdPoliza(String value) {
                    this.idPoliza = value;
                }

                /**
                 * Obtiene el valor de la propiedad numeroSuplemento.
                 * 
                 */
                public Integer getNumeroSuplemento() {
                    return numeroSuplemento;
                }

                /**
                 * Define el valor de la propiedad numeroSuplemento.
                 * 
                 */
                public void setNumeroSuplemento(Integer value) {
                    this.numeroSuplemento = value;
                }

                /**
                 * Obtiene el valor de la propiedad idMediador.
                 * 
                 */
            

                /**
                 * Obtiene el valor de la propiedad productoDGS.
                 * 
                 */
                public ProcesosEIACPoliza.Objetos.Poliza.DatosPoliza.DatosRamo getRamo() {
                    return ramo;
                }

                /**
                 * Define el valor de la propiedad productoDGS.
                 * 
                 */
                public void setRamo(ProcesosEIACPoliza.Objetos.Poliza.DatosPoliza.DatosRamo  value) {
                    this.ramo = value;
                }
                
                             
                
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "idMediador"
                })
                public static class DatosMediador {

                    @XmlElement(name = "IdMediador", required = true)
                    protected IdMediador idMediador;

    				public IdMediador getIdMediador() {
    					return idMediador;
    				}

    				public void setIdMediador(IdMediador idMediador) {
    					this.idMediador = idMediador;
    				}    

                } 
                          
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "codigoInterno",
                    "codigoDgs"
                })
                public static class IdMediador {

                    @XmlElement(name = "CodigoInterno", required = true)
                  
                    protected String codigoInterno;
                    @XmlElement(name = "CodigoDGS", required = true)
                    protected String codigoDgs;
        			public String getCodigoDgs() {
						return codigoDgs;
					}

					public void setCodigoDgs(String codigoDgs) {
						this.codigoDgs = codigoDgs;
					}

					public String getCodigoInterno() {
        				return codigoInterno;
        			}

        			public void setCodigoInterno(String codigoInterno) {
        				this.codigoInterno = codigoInterno;
        			}    

                } 
                
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                	"ramoDGS",                    
                    "ramoEntidad",
                    "descripcionRamo",
                    "modalidadRamo",
                    "descripcionModalidad"
                })
                public static class DatosRamo {
                
					@XmlElement(name = "RamoDGS", required = true)
                     protected String ramoDGS;
                	 @XmlElement(name = "RamoEntidad", required = true)
                     protected String ramoEntidad;
                	 @XmlElement(name = "DescripcionRamo", required = true)
                     protected String descripcionRamo;
                    @XmlElement(name = "ModalidadRamo", required = true)
                    protected String modalidadRamo;
                    @XmlElement(name = "DescripcionModalidad", required = true)
                    protected String descripcionModalidad;
               	 public String getRamoDGS() {
						return ramoDGS;
					}

					public void setRamoDGS(String ramoDGS) {
						this.ramoDGS = ramoDGS;
					}

					public String getRamoEntidad() {
						return ramoEntidad;
					}

					public void setRamoEntidad(String ramoEntidad) {
						this.ramoEntidad = ramoEntidad;
					}

					public String getDescripcionRamo() {
						return descripcionRamo;
					}

					public void setDescripcionRamo(String descripcionRamo) {
						this.descripcionRamo = descripcionRamo;
					}

					public String getDescripcionModalidad() {
						return descripcionModalidad;
					}

					public void setDescripcionModalidad(String descripcionModalidad) {
						this.descripcionModalidad = descripcionModalidad;
					}


                    /**
                     * Obtiene el valor de la propiedad codigoInterno.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getModalidadRamo() {
                        return modalidadRamo;
                    }

                    /**
                     * Define el valor de la propiedad codigoInterno.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setModalidadRamo(String value) {
                        this.modalidadRamo = value;
                    }

                } 
                
               

            }
            
            
            

            /**
             * <p>Clase Java para anonymous complex type.
             * 
             * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="IdRecibo" type="{http://www.w3.org/2001/XMLSchema}unsignedLong"/&gt;
             *         &lt;element name="SituacionRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *         &lt;element name="ClaseRecibo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *         &lt;element name="FraccionPago" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *         &lt;element name="Fechas"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="FechaSituacion" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
             *                   &lt;element name="FechaEfectoActual" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
             *                   &lt;element name="FechaVencimiento" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
             *                   &lt;element name="FechaEmision" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="DatosImportes"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="Importes"&gt;
             *                     &lt;complexType&gt;
             *                       &lt;complexContent&gt;
             *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                           &lt;sequence&gt;
             *                             &lt;element name="PrimaTotal" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
             *                             &lt;element name="PrimaNeta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
             *                             &lt;element name="DatosCargos"&gt;
             *                               &lt;complexType&gt;
             *                                 &lt;complexContent&gt;
             *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                     &lt;sequence&gt;
             *                                       &lt;element name="Cargo"&gt;
             *                                         &lt;complexType&gt;
             *                                           &lt;complexContent&gt;
             *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                               &lt;sequence&gt;
             *                                                 &lt;element name="ClaseCargo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *                                                 &lt;element name="Importe" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
             *                                               &lt;/sequence&gt;
             *                                             &lt;/restriction&gt;
             *                                           &lt;/complexContent&gt;
             *                                         &lt;/complexType&gt;
             *                                       &lt;/element&gt;
             *                                     &lt;/sequence&gt;
             *                                   &lt;/restriction&gt;
             *                                 &lt;/complexContent&gt;
             *                               &lt;/complexType&gt;
             *                             &lt;/element&gt;
             *                           &lt;/sequence&gt;
             *                         &lt;/restriction&gt;
             *                       &lt;/complexContent&gt;
             *                     &lt;/complexType&gt;
             *                   &lt;/element&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="DatosComisiones"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="Comision"&gt;
             *                     &lt;complexType&gt;
             *                       &lt;complexContent&gt;
             *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                           &lt;sequence&gt;
             *                             &lt;element name="NumeroOrden" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/&gt;
             *                             &lt;element name="ClaseComision" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
             *                             &lt;element name="ComisionBruta" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
             *                             &lt;element name="ComisionLiquida" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
             *                           &lt;/sequence&gt;
             *                         &lt;/restriction&gt;
             *                       &lt;/complexContent&gt;
             *                     &lt;/complexType&gt;
             *                   &lt;/element&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "tipoIdentificacion",
                "idPersona",
                "idCliente",
                "nombre",
                "apellido1",
                "apellido2"
            })
            public static class PersonaFisica {

                @XmlElement(name = "TipoIdentificacion", required = true)
                protected String tipoIdentificacion;
                @XmlElement(name = "IdPersona", required = true)
                protected String idPersona;
                @XmlElement(name = "IdCliente", required = true)
                protected String idCliente;
                @XmlElement(name = "Nombre", required = false)
                protected String nombre;
                @XmlElement(name = "Apellido1", required = false)
                protected String apellido1;
                @XmlElement(name = "Apellido2", required = false)
                protected String apellido2;
              
                /**
                 * Obtiene el valor de la propiedad idRecibo.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public String getTipoIdentificacion() {
                    return tipoIdentificacion;
                }

                /**
                 * Define el valor de la propiedad idRecibo.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setIdRecibo(String value) {
                    this.tipoIdentificacion = value;
                }

                /**
                 * Obtiene el valor de la propiedad situacionRecibo.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getIdPersona() {
                    return idPersona;
                }

                /**
                 * Define el valor de la propiedad situacionRecibo.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setIdPersona(String value) {
                    this.idPersona = value;
                }

                /**
                 * Obtiene el valor de la propiedad claseRecibo.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getIdCliente() {
                    return idCliente;
                }

                /**
                 * Define el valor de la propiedad claseRecibo.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setIdCliente(String value) {
                    this.idCliente = value;
                }

                /**
                 * Obtiene el valor de la propiedad fraccionPago.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getNombre() {
                    return nombre;
                }

                /**
                 * Define el valor de la propiedad fraccionPago.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setNombre(String value) {
                    this.nombre = value;
                }

                /**
                 * Obtiene el valor de la propiedad fechas.
                 * 
                 * @return
                 *     possible object is
                 *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.Fechas }
                 *     
                 */
                public String getApellido1() {
                    return apellido1;
                }

                /**
                 * Define el valor de la propiedad fechas.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.Fechas }
                 *     
                 */
                public void setApellido1(String value) {
                    this.apellido1 = value;
                }

                /**
                 * Obtiene el valor de la propiedad datosImportes.
                 * 
                 * @return
                 *     possible object is
                 *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes }
                 *     
                 */
                public String getApellido2() {
                    return apellido2;
                }

                /**
                 * Define el valor de la propiedad datosImportes.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes }
                 *     
                 */
                public void setApellido2(String value) {
                    this.apellido2 = value;
                }

            }
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "personaFisica",
                "personaJuridica"
            })
            
            public static class Tomador {

                @XmlElement(name = "PersonaFisica", required = false)
                protected ProcesosEIACPoliza.Objetos.Poliza.Tomador.PersonaFisica personaFisica;
                @XmlElement(name = "PersonaJuridica", required = false)
                protected ProcesosEIACPoliza.Objetos.Poliza.Tomador.PersonaJuridica personaJuridica;

              
                /**
                 * Obtiene el valor de la propiedad idRecibo.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public ProcesosEIACPoliza.Objetos.Poliza.Tomador.PersonaFisica getPersonaFisica() {
                    return personaFisica;
                }

                /**
                 * Define el valor de la propiedad idRecibo.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setPersonaFisica(ProcesosEIACPoliza.Objetos.Poliza.Tomador.PersonaFisica value) {
                    this.personaFisica= value;
                }

                /**
                 * Obtiene el valor de la propiedad situacionRecibo.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public ProcesosEIACPoliza.Objetos.Poliza.Tomador.PersonaJuridica getPersonaJuridica() {
                    return personaJuridica;
                }

                /**
                 * Define el valor de la propiedad situacionRecibo.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setPersonaJuridica(ProcesosEIACPoliza.Objetos.Poliza.Tomador.PersonaJuridica value) {
                    this.personaJuridica= value;
                }

               
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "tipoIdentificacion",
                    "idPersona",
                    "idCliente",
                    "nombre",
                    "apellido1",
                    "apellido2"
                })
                public static class PersonaFisica {

                    @XmlElement(name = "TipoIdentificacion", required = true)
                    protected String tipoIdentificacion;
                    @XmlElement(name = "IdPersona", required = true)
                    protected String idPersona;
                    @XmlElement(name = "IdCliente", required = true)
                    protected String idCliente;
                    @XmlElement(name = "Nombre", required = false)
                    protected String nombre;
                    @XmlElement(name = "Apellido1", required = false)
                    protected String apellido1;
                    @XmlElement(name = "Apellido2", required = false)
                    protected String apellido2;
                  
                    /**
                     * Obtiene el valor de la propiedad idRecibo.
                     * 
                     * @return
                     *     possible object is
                     *     {@link BigInteger }
                     *     
                     */
                    public String getTipoIdentificacion() {
                        return tipoIdentificacion;
                    }

                    /**
                     * Define el valor de la propiedad idRecibo.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link BigInteger }
                     *     
                     */
                    public void setIdRecibo(String value) {
                        this.tipoIdentificacion = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad situacionRecibo.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getIdPersona() {
                        return idPersona;
                    }

                    /**
                     * Define el valor de la propiedad situacionRecibo.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setIdPersona(String value) {
                        this.idPersona = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad claseRecibo.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getIdCliente() {
                        return idCliente;
                    }

                    /**
                     * Define el valor de la propiedad claseRecibo.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setIdCliente(String value) {
                        this.idCliente = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad fraccionPago.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getNombre() {
                        return nombre;
                    }

                    /**
                     * Define el valor de la propiedad fraccionPago.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setNombre(String value) {
                        this.nombre = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad fechas.
                     * 
                     * @return
                     *     possible object is
                     *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.Fechas }
                     *     
                     */
                    public String getApellido1() {
                        return apellido1;
                    }

                    /**
                     * Define el valor de la propiedad fechas.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.Fechas }
                     *     
                     */
                    public void setApellido1(String value) {
                        this.apellido1 = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad datosImportes.
                     * 
                     * @return
                     *     possible object is
                     *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes }
                     *     
                     */
                    public String getApellido2() {
                        return apellido2;
                    }

                    /**
                     * Define el valor de la propiedad datosImportes.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link ProcesosEIAC.Objetos.Recibo.DatosRecibo.DatosImportes }
                     *     
                     */
                    public void setApellido2(String value) {
                        this.apellido2 = value;
                    }

                }
                
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "tipoIdentificacion",
                    "idPersona",
                    "idCliente"
                })
                public static class PersonaJuridica {

                    @XmlElement(name = "TipoIdentificacion", required = true)
                    protected String tipoIdentificacion;
                    @XmlElement(name = "IdPersona", required = true)
                    protected String idPersona;
                    @XmlElement(name = "IdCliente", required = true)
                    protected String idCliente;
                 
                    /**
                     * Obtiene el valor de la propiedad idRecibo.
                     * 
                     * @return
                     *     possible object is
                     *     {@link BigInteger }
                     *     
                     */
                    public String getTipoIdentificacion() {
                        return tipoIdentificacion;
                    }

                    /**
                     * Define el valor de la propiedad idRecibo.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link BigInteger }
                     *     
                     */
                    public void setIdRecibo(String value) {
                        this.tipoIdentificacion = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad situacionRecibo.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getIdPersona() {
                        return idPersona;
                    }

                    /**
                     * Define el valor de la propiedad situacionRecibo.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setIdPersona(String value) {
                        this.idPersona = value;
                    }

                    /**
                     * Obtiene el valor de la propiedad claseRecibo.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getIdCliente() {
                        return idCliente;
                    }

                    /**
                     * Define el valor de la propiedad claseRecibo.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setIdCliente(String value) {
                        this.idCliente = value;
                    }                 

                }

            }

        }

    }

}
