package com.isb.gabps.concomseg.support.files.cb;

import java.io.Serializable;

public class Poliza implements Serializable{
	
	public String nombreFichero;
	public String idPoliza;
	public String ramo;
	public String idSuplemento;
	
	
	public String getNombreFichero() {
		return nombreFichero;
	}
	public void setNombreFichero(String nombreFichero) {
		this.nombreFichero = nombreFichero;
	}
	public String getIdPoliza() {
		return idPoliza;
	}
	public void setIdPoliza(String idPoliza) {
		this.idPoliza = idPoliza;
	}
	public String getRamo() {
		return ramo;
	}
	public void setRamo(String ramo) {
		this.ramo = ramo;
	}

	public String getIdSuplemento() {
		return idSuplemento;
	}
	public void setIdSuplemento(String idSuplemento) {
		this.idSuplemento = idSuplemento;
	}
}
