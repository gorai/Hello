package com.isb.gabps.concomseg.support.files.cb;

import java.io.Serializable;
import java.util.ArrayList;

public class Recibo implements Serializable {
	
	public String nombreFichero;
	public String idPoliza;
	public String ramo;
	public String NumeroSuplemento;
	public String idRecibo;
	public String situacionRecibo;
	public String claseRecibo;
	public double comisionLiquida;
	public String fechaSituacion;
	public String fechaEfectoInicial;
	public String fechaEfectoActual;
	public String fechaVencimiento;
	public String fechaEmision;
	public Double primaNeta;
	public boolean tienePoliza=false;
	public boolean ultimo=true;
	public String incongruente;
	public boolean valido=true;	
	public String fechaQuitado;
	public String estadoReciboSustituto;
	public String iban;
	public String getIban() {
		return iban;
	}
	public void setIban(String iban) {
		this.iban = iban;
	}
	public boolean isUltimo() {
		return ultimo;
	}
	public void setUltimo(boolean ultimo) {
		this.ultimo = ultimo;
	}
	public String getIncongruente() {
		return incongruente;
	}
	public void setIncongruente(String incongruente) {
		this.incongruente = incongruente;
	}
	public String getNombreFichero() {
		return nombreFichero;
	}
	public void setNombreFichero(String nombreFichero) {
		this.nombreFichero = nombreFichero;
	}
	public String getIdPoliza() {
		return idPoliza;
	}
	public void setIdPoliza(String idPoliza) {
		this.idPoliza = idPoliza;
	}
	public String getRamo() {
		return ramo;
	}
	public void setRamo(String ramo) {
		this.ramo = ramo;
	}
	public String getNumeroSuplemento() {
		return NumeroSuplemento;
	}
	public void setNumeroSuplemento(String numeroSuplemento) {
		NumeroSuplemento = numeroSuplemento;
	}
	public String getIdRecibo() {
		return idRecibo;
	}
	public void setIdRecibo(String idRecibo) {
		this.idRecibo = idRecibo;
	}
	public String getSituacionRecibo() {
		return situacionRecibo;
	}
	public void setSituacionRecibo(String situacionRecibo) {
		this.situacionRecibo = situacionRecibo;
	}
	public String getClaseRecibo() {
		return claseRecibo;
	}
	public void setClaseRecibo(String claseRecibo) {
		this.claseRecibo = claseRecibo;
	}
	public double getComisionLiquida() {
		return comisionLiquida;
	}
	public void setComisionLiquida(double comisionLiquida) {
		this.comisionLiquida = comisionLiquida;
	}
	public String getFechaSituacion() {
		return fechaSituacion;
	}
	public void setFechaSituacion(String fechaSituacion) {
		this.fechaSituacion = fechaSituacion;
	}
	public String getFechaEfectoInicial() {
		return fechaEfectoInicial;
	}
	public void setFechaEfectoInicial(String fechaEfectoInicial) {
		this.fechaEfectoInicial = fechaEfectoInicial;
	}
	public String getFechaEfectoActual() {
		return fechaEfectoActual;
	}
	public void setFechaEfectoActual(String fechaEfectoActual) {
		this.fechaEfectoActual = fechaEfectoActual;
	}
	public String getFechaVencimiento() {
		return fechaVencimiento;
	}
	public void setFechaVencimiento(String fechaVencimiento) {
		this.fechaVencimiento = fechaVencimiento;
	}
	public String getFechaEmision() {
		return fechaEmision;
	}
	public void setFechaEmision(String fechaEmision) {
		this.fechaEmision = fechaEmision;
	}
	public Double getPrimaNeta() {
		return primaNeta;
	}
	public void setPrimaNeta(Double primaNeta) {
		this.primaNeta = primaNeta;
	}	
	public boolean isTienePoliza() {
		return tienePoliza;
	}
	public void setTienePoliza(boolean tienePoliza) {
		this.tienePoliza = tienePoliza;
	}
	public boolean isValido() {
		return valido;
	}
	public void setValido(boolean valido) {
		this.valido = valido;
	}
	public String getFechaQuitado() {
		return fechaQuitado;
	}
	public void setFechaQuitado(String fechaQuitado) {
		this.fechaQuitado = fechaQuitado;
	}
	public String getEstadoReciboSustituto() {
		return estadoReciboSustituto;
	}
	public void setEstadoReciboSustituto(String estadoReciboSustituto) {
		this.estadoReciboSustituto = estadoReciboSustituto;
	}
}
