package com.isb.gabps.concomseg.support.files;

import java.io.Serializable;

public class DatosPersonaJuridico implements Serializable{
	
String situacionPoliza;
public String getSituacionPoliza() {
	return situacionPoliza;
}
public void setSituacionPoliza(String situacionPoliza) {
	this.situacionPoliza = situacionPoliza;
}
public String getFechaEfectoActual() {
	return fechaEfectoActual;
}
public void setFechaEfectoActual(String fechaEfectoActual) {
	this.fechaEfectoActual = fechaEfectoActual;
}
public String getPrimaNeta() {
	return primaNeta;
}
public void setPrimaNeta(String primaNeta) {
	this.primaNeta = primaNeta;
}
String fechaEfectoActual;
String fechaAnulacion;
public String getFechaAnulacion() {
	return fechaAnulacion;
}
public void setFechaAnulacion(String fechaAnulacion) {
	this.fechaAnulacion = fechaAnulacion;
}
String primaNeta;	
String primaTotal;	

String tipoTomador;
public String getTipoTomador() {
	return tipoTomador;
}
public void setTipoTomador(String tipoTomador) {
	this.tipoTomador = tipoTomador;
}
public String getDatoTomador() {
	return datoTomador;
}
public void setDatoTomador(String datoTomador) {
	this.datoTomador = datoTomador;
}
public String getTipoAsegurado() {
	return tipoAsegurado;
}
public void setTipoAsegurado(String tipoAsegurado) {
	this.tipoAsegurado = tipoAsegurado;
}
public String getDatoAsegurado() {
	return datoAsegurado;
}
public void setDatoAsegurado(String datoAsegurado) {
	this.datoAsegurado = datoAsegurado;
}
String datoTomador;
String tipoAsegurado;
String datoAsegurado;


public String getPrimaTotal() {
	return primaTotal;
}
public void setPrimaTotal(String primaTotal) {
	this.primaTotal = primaTotal;
}
String iban;	
public String getIban() {
	return iban;
}
public void setIban(String iban) {
	this.iban = iban;
}
String fichero;
String status="";
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getFichero() {
	return fichero;
}
public void setFichero(String fichero) {
	this.fichero = fichero;
}
String numPoliza;	
	
public String getNumPoliza() {
	return numPoliza;
}
public void setnumPoliza(String numPoliza) {
	this.numPoliza = numPoliza;
}
String tipoDoc;
public String getTipoDoc() {
	return tipoDoc;
}
public void setTipoDoc(String tipoDoc) {
	this.tipoDoc = tipoDoc;
}
public String getCodDoc() {
	return codDoc;
}
public void setCodDoc(String codDoc) {
	this.codDoc = codDoc;
}
public String getNombre() {
	return nombre;
}
public void setNombre(String nombre) {
	this.nombre = nombre;
}
public String getTipoPersona() {
	return tipoPersona;
}
public void setTipoPersona(String tipoPersona) {
	this.tipoPersona = tipoPersona;
}
public String getIdClienteZurich() {
	return idClienteZurich;
}
public void setIdClienteZurich(String idClienteZurich) {
	this.idClienteZurich = idClienteZurich;
}
String codDoc;
String nombre;
String tipoPersona;
String idClienteZurich;
String ramoDGS;

public String getRamoDGS() {
	return ramoDGS;
}
public void setRamoDGS(String ramoDGS) {
	this.ramoDGS = ramoDGS;
}
int numeroSuplemento;
public int getNumeroSuplemento() {
	return numeroSuplemento;
}
public void setNumeroSuplemento(int numeroSuplemento) {
	this.numeroSuplemento = numeroSuplemento;
}
public String getApellido1() {
	return apellido1;
}
public void setApellido1(String apellido1) {
	this.apellido1 = apellido1;
}
public String getApellido2() {
	return apellido2;
}
public void setApellido2(String apellido2) {
	this.apellido2 = apellido2;
}

String apellido1;
String apellido2;

String fecInicioPoliza;
public String getFecInicioPoliza() {
	return fecInicioPoliza;
}
public void setFecInicioPoliza(String fecInicioPoliza) {
	this.fecInicioPoliza = fecInicioPoliza;
}
public String getFecFinSeg() {
	return fecFinSeg;
}
public void setFecFinSeg(String fecFinSeg) {
	this.fecFinSeg = fecFinSeg;
}
public String getSitPoliza() {
	return sitPoliza;
}
public void setSitPoliza(String sitPoliza) {
	this.sitPoliza = sitPoliza;
}
public String getTipSeguro() {
	return tipSeguro;
}
public void setTipSeguro(String tipSeguro) {
	this.tipSeguro = tipSeguro;
}
public void setNumPoliza(String numPoliza) {
	this.numPoliza = numPoliza;
}
String fecFinSeg;
String sitPoliza;
String tipSeguro;

String fraccionPago;

public String getFraccionPago() {
	return fraccionPago;
}
public void setFraccionPago(String fraccionPago) {
	this.fraccionPago = fraccionPago;
}
String mediador;
public String getMediador() {
	return mediador;
}
public void setMediador(String mediador) {
	this.mediador = mediador;
}
public String getProducto() {
	return producto;
}
public void setProducto(String producto) {
	this.producto = producto;
}
public String getRecibo() {
	return recibo;
}
public void setRecibo(String recibo) {
	this.recibo = recibo;
}
public String getSitRecibo() {
	return sitRecibo;
}
public void setSitRecibo(String sitRecibo) {
	this.sitRecibo = sitRecibo;
}
public String getTipoRecibo() {
	return tipoRecibo;
}
public void setTipoRecibo(String tipoRecibo) {
	this.tipoRecibo = tipoRecibo;
}
public String getPeridoPago() {
	return peridoPago;
}
public void setPeridoPago(String peridoPago) {
	this.peridoPago = peridoPago;
}
String producto;
String recibo;
String sitRecibo;
String tipoRecibo;
String peridoPago;


public String getRamoEntidad() {
	return ramoEntidad;
}
public void setRamoEntidad(String ramoEntidad) {
	this.ramoEntidad = ramoEntidad;
}
public String getDescripcionRamo() {
	return descripcionRamo;
}
public void setDescripcionRamo(String descripcionRamo) {
	this.descripcionRamo = descripcionRamo;
}
public String getModalidadRamo() {
	return modalidadRamo;
}
public void setModalidadRamo(String modalidadRamo) {
	this.modalidadRamo = modalidadRamo;
}
String descripcionRamo;
String modalidadRamo;
String ramoEntidad;
String clasePoliza;
String fechaSituacion;
String duracionPoliza;
String claseRecibo;



public String getClaseRecibo() {
	return claseRecibo;
}
public void setClaseRecibo(String claseRecibo) {
	this.claseRecibo = claseRecibo;
}
public String getDuracionPoliza() {
	return duracionPoliza;
}
public void setDuracionPoliza(String duracionPoliza) {
	this.duracionPoliza = duracionPoliza;
}
public String getFechaSituacion() {
	return fechaSituacion;
}
public void setFechaSituacion(String fechaSituacion) {
	this.fechaSituacion = fechaSituacion;
}
public String getClasePoliza() {
	return clasePoliza;
}
public void setClasePoliza(String clasePoliza) {
	this.clasePoliza = clasePoliza;
}
public String getFechaEmision() {
	return FechaEmision;
}
public void setFechaEmision(String fechaEmision) {
	FechaEmision = fechaEmision;
}
public String getImporteRecibo() {
	return ImporteRecibo;
}
public void setImporteRecibo(String importeRecibo) {
	ImporteRecibo = importeRecibo;
}
String FechaEmision;
String ImporteRecibo;

String polizaFechaSituacion;
String polizaFechaEfectoActual;
String polizaFechaVencimiento;
String polizaFechaEmision;



public String getPolizaFechaSituacion() {
	return polizaFechaSituacion;
}
public void setPolizaFechaSituacion(String polizaFechaSituacion) {
	this.polizaFechaSituacion = polizaFechaSituacion;
}
public String getPolizaFechaEfectoActual() {
	return polizaFechaEfectoActual;
}
public void setPolizaFechaEfectoActual(String polizaFechaEfectoActual) {
	this.polizaFechaEfectoActual = polizaFechaEfectoActual;
}
public String getPolizaFechaVencimiento() {
	return polizaFechaVencimiento;
}
public void setPolizaFechaVencimiento(String polizaFechaVencimiento) {
	this.polizaFechaVencimiento = polizaFechaVencimiento;
}
public String getPolizaFechaEmision() {
	return polizaFechaEmision;
}
public void setPolizaFechaEmision(String polizaFechaEmision) {
	this.polizaFechaEmision = polizaFechaEmision;
}
}
