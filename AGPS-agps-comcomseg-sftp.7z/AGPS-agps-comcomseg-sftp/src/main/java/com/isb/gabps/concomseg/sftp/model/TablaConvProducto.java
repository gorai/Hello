package com.isb.gabps.concomseg.sftp.model;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * The Class TablaSeleccionRecibo.
 */
@Entity
@Table(name = "SEGUROS_CONV_PRODUCTOS")//,schema="adescm1d")
public class TablaConvProducto implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -402022497988842862L;

    /** The co producto. */
    @Id
    @Column(name = "CO_PRODUCTO")
    private String coProducto;
    
    /** The con liquida. */
    @Column(name = "CO_COCONCLI")
    private String conLiquida;

    /** The cuen debe. */
    @Column(name = "CO_CTA_DEBE")
    private String cuenDebe;

    /** The cuen haber. */
    @Column(name = "CO_CTA_HABER")
    private String cuenHaber;

    /** The co usuario. */
    @Column(name = "CO_USUARIO")
    private String coUsuario;

    /** The fh modif. */
    @Column(name = "FH_MODIF")
    private Calendar fhModif;

    /**
     * Gets the co producto.
     *
     * @return the co producto
     */
    public String getCoProducto() {
        return coProducto;
    }

    /**
     * Sets the co producto.
     *
     * @param coProducto the new co producto
     */
    public void setCoProducto(String coProducto) {
        this.coProducto = coProducto;
    }

    /**
     * Gets the con liquida.
     *
     * @return the con liquida
     */
    public String getConLiquida() {
        return conLiquida;
    }

    /**
     * Sets the con liquida.
     *
     * @param conLiquida the new con liquida
     */
    public void setConLiquida(String conLiquida) {
        this.conLiquida = conLiquida;
    }

    /**
     * Gets the cuen debe.
     *
     * @return the cuen debe
     */
    public String getCuenDebe() {
        return cuenDebe;
    }

    /**
     * Sets the cuen debe.
     *
     * @param cuenDebe the new cuen debe
     */
    public void setCuenDebe(String cuenDebe) {
        this.cuenDebe = cuenDebe;
    }

    /**
     * Gets the cuen haber.
     *
     * @return the cuen haber
     */
    public String getCuenHaber() {
        return cuenHaber;
    }

    /**
     * Sets the cuen haber.
     *
     * @param cuenHaber the new cuen haber
     */
    public void setCuenHaber(String cuenHaber) {
        this.cuenHaber = cuenHaber;
    }

    /**
     * Gets the co usuario.
     *
     * @return the co usuario
     */
    public String getCoUsuario() {
        return coUsuario;
    }

    /**
     * Sets the co usuario.
     *
     * @param coUsuario the new co usuario
     */
    public void setCoUsuario(String coUsuario) {
        this.coUsuario = coUsuario;
    }

    /**
     * Gets the fh modif.
     *
     * @return the fh modif
     */
    public Calendar getFhModif() {
        return fhModif;
    }

    /**
     * Sets the fh modif.
     *
     * @param fhModif the new fh modif
     */
    public void setFhModif(Calendar fhModif) {
        this.fhModif = fhModif;
    }
    
    /**
     * Copy.
     *
     * @return the tabla conv producto
     */
    public TablaConvProducto copy() {
        TablaConvProducto tabla = new TablaConvProducto();
        tabla.setConLiquida(this.conLiquida);
        tabla.setCoProducto(this.coProducto);
        tabla.setCoUsuario(this.coUsuario);
        tabla.setCuenDebe(this.cuenDebe);
        tabla.setCuenHaber(this.cuenHaber);
        Calendar cal = Calendar.getInstance();
        tabla.setFhModif(this.fhModif!=null?(Calendar)cal.clone():null);
        return tabla;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        return (new HashCodeBuilder()).append(this.conLiquida).append(this.coProducto).append(this.coUsuario)
                .append(this.cuenDebe).append(this.cuenHaber).append(this.fhModif).hashCode();
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof TablaConvProducto)) {
            return false;
        }
        TablaConvProducto other  = (TablaConvProducto) obj;
        return (new EqualsBuilder()).append(this.conLiquida, other.getConLiquida())
                .append(this.coProducto, other.getCoProducto()).append(this.coUsuario, other.getCoUsuario())
                .append(this.cuenDebe, other.getCuenDebe()).append(this.cuenHaber, other.getCuenHaber())
                .append(this.fhModif, other.getFhModif()).isEquals();
    }
    
    
}
