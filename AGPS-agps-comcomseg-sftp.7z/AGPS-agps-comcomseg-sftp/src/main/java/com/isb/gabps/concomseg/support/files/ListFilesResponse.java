package com.isb.gabps.concomseg.support.files;

import java.util.ArrayList;
import java.util.List;

/**
 * Respuesta REST con la lista de ficheros.
 * 
 * @author xIS08485
 */
public class ListFilesResponse {
	// OK/KO
	private String result;
	
	// Lista de ficheros
	private List<String> filesList = new ArrayList<>(); 
	
	
	
	/**
	 * Devuelve resultado de operación REST.
	 * 
	 * @return OK/KO
	 */
	public String getResult() {
		return result;
	}
	
	/**
	 * Asignar resultado de operación REST.
	 * 
	 * @param result OK/KO
	 */
	public void setResult(String result) {
		this.result = result;
	}
	
	/**
	 * Devuelve lista de ficheros.
	 * 
	 * @return Lista de ficheros
	 */
	public List<String> getFilesList() {
		return filesList;
	}

	/**
	 * Asigna lista de ficheros a devolver en la respuesta.
	 * 
	 * @param filesList Lista de ficheros
	 */
	public void setFilesList(List<String> filesList) {
		this.filesList = filesList;
	}
}
