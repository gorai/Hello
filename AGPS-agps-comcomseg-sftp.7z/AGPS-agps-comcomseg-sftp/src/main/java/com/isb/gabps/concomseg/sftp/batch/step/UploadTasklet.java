package com.isb.gabps.concomseg.sftp.batch.step;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;

import com.isb.gabps.concomseg.sftp.SFTPConfig;
import com.isb.gabps.concomseg.sftp.batch.BatchGlobals;
import com.isb.gabps.concomseg.sftp.service.SFTPService;

/**
 * Step para subir el fichero contable al servidor sftp.
 * 
 * @author xIS08485
 */
@Component(BatchGlobals.TASKLET_UPLOAD)
public class UploadTasklet implements Tasklet {
	// Logger
	private static final Logger LOGGER = LoggerFactory.getLogger(UploadTasklet.class);
	
	// Servicio para descargar los ficheros del servidor sftp
	@Autowired
	private SFTPService service;
	
	// Configuración (del properties)
	@Autowired
	private SFTPConfig config;
	
	// Para reintenta abrir conexiones al servidor sftp si éste falla 
	private RetryTemplate connectRetrier;
	
	
	
	/**
	 * Sube el fichero contable generado por el batch de contabilidad, al servidor sftp.
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		
		// Recuperamos el contexto de ejecución, lo usaremos para guardar datos
		// de la ejecución que usaremos en otras clases (como el id del job,
		// o el estado actual del proceso)
		StepExecution stepExec = chunkContext.getStepContext().getStepExecution();
		ExecutionContext contexto = stepExec.getJobExecution().getExecutionContext();
		
		// Nos conectamos al sftp
		// Usamos Spring Retry para reintentar varias veces la conexión
		contexto.putString(BatchGlobals.JOB_CTX_JOB_ACTION, BatchGlobals.ACTION_CONNECT);
		service.setTimeout(config.getConnectTimeout());
		connectRetrier = config.connectRetrier(stepExec.getJobExecutionId());
		connectRetrier.execute(retryContext -> {
			service.connect(config.getSFTPServer(), config.getSFTPPort(),
					config.getSFTPLogin(), config.getSFTPSecret());
		    return null;
		});
		contexto.remove(BatchGlobals.JOB_CTX_JOB_ACTION);
		
		// Enviamos el fichero contable al sftp
		contexto.putString(BatchGlobals.JOB_CTX_JOB_ACTION, BatchGlobals.ACTION_UPLOAD);
		LOGGER.debug("Iniciando subida del fichero contable");
		List<String> ficheros = new ArrayList<>();
		
		service.uploadFile(config.getFSOutFile2(), config.getSFTPOutPath());
		contexto.remove(BatchGlobals.JOB_CTX_JOB_ACTION);
		
		// Desconectando del servidor sftp
		LOGGER.debug("Finalizando conexión al servidor sftp.");
		service.disconnect();
		
		// FIN OK
		LOGGER.debug("Fin exitoso del step");
		return RepeatStatus.FINISHED;
	}
}
