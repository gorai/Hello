package com.isb.gabps.concomseg.sftp.batch.job;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.FileSystemUtils;

import com.isb.gabps.concomseg.sftp.SFTPConfig;
import com.isb.gabps.concomseg.sftp.batch.BatchGlobals;
import com.isb.gabps.concomseg.sftp.util.ValidationsHelper;

/**
 * Listener para preparar o limpiar el entorno para los jobs.
 * 
 * @author xIS08485
 */
@Component(BatchGlobals.LISTENER_WORKDIR)
public class WorkdirListener implements JobExecutionListener {
	// Logger
	private static final Logger LOGGER = LoggerFactory.getLogger(WorkdirListener.class);
	
	// Configuración (del properties)
	@Autowired
	private SFTPConfig config;
	
	

	/**
	 * Realiza las inicializaciones y acciones oportunas antes de ejecutar el job.
	 * En este caso se guarda el job-id en el contexto, y se comprueba que exista la carpeta de trabajo.
	 */
	@Override
	public void beforeJob(JobExecution jobExecution) {
		// Validar datos de entrada
		JobParameters params = jobExecution.getJobParameters();
		String fecha = params.getString(BatchGlobals.JOB_PARAM_DATE);
		ValidationsHelper.notEmpty("parámetros del job",
				BatchGlobals.JOB_PARAM_DATE, fecha);
		Long ciclo = params.getLong(BatchGlobals.JOB_PARAM_CYCLE);
		ValidationsHelper.isPositive("parámetros del job",
				BatchGlobals.JOB_PARAM_CYCLE, ciclo);
		
		// Generar job-id
		String jobId = "pull-job-" + fecha + "-" + ciclo;
		
		
		// Guardar job-id en contexto
		ExecutionContext contexto = jobExecution.getExecutionContext();
		contexto.putString(BatchGlobals.JOB_CTX_JOB_ID, jobId);
		
		// Crear carpeta temporal
		String workdir = config.getFSTempPath(jobId);
		if(false) {//if (!Files.exists(workdir)) {
		
			
				//	Files.createDirectories(workdir);
			
		}
	}
	
	/**
	 * Limpia luego de ejecutar el job.
	 * Si el job ha terminado (estado = {@code COMPLETED o ABANDONED}), borra la carpeta de trabajo
	 * si está activada la propiedad {@code app.feat.cleanup}. 
	 */
	@Override
	public void afterJob(JobExecution jobExecution) {
		// Leer del contexto, ruta a carpeta del trabajo
		ExecutionContext contexto = jobExecution.getExecutionContext();
		String jobId = contexto.getString(BatchGlobals.JOB_CTX_JOB_ID);
		ValidationsHelper.notEmpty("datos contextuales del job",
				BatchGlobals.JOB_CTX_JOB_ID, jobId);
		BatchStatus estado = jobExecution.getStatus();
		
		// Borrar carpeta
		String workdir = config.getFSTempPath(jobId);
		if (config.isFeatCleanup() &&
				((estado == BatchStatus.COMPLETED) || (estado == BatchStatus.ABANDONED))) {
		
		// (!FileSystemUtils.deleteRecursively(workdir)) {
		//		LOGGER.warn("Error al borrando carpeta de trabajo.");
		//	}
		}
	}
}
