package com.isb.gabps.concomseg.sftp.batch.step;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;

import com.isb.gabps.concomseg.sftp.SFTPConfig;
import com.isb.gabps.concomseg.sftp.batch.BatchGlobals;
import com.isb.gabps.concomseg.sftp.model.TablaSeleccionRecibo;
import com.isb.gabps.concomseg.sftp.repository.TratComDao;
import com.isb.gabps.concomseg.sftp.service.SFTPService;

/**
 * Step para subir el fichero contable al servidor sftp.
 * 
 * @author xIS08485
 */
@Component(BatchGlobals.TASKLET_REPORT)
public class ReportTasklet implements Tasklet {
	// Logger
	private static final Logger LOGGER = LoggerFactory.getLogger(ReportTasklet.class);
	
	// Servicio para descargar generar el informe mensual
	@Autowired
	private SFTPService service;
	
	// Configuración (del properties)
	@Autowired
	private SFTPConfig config;
	
	// Para reintenta abrir conexiones al servidor sftp si éste falla 
	private RetryTemplate connectRetrier;
	
	@Autowired
	private TratComDao repository;
	
	
	
	/**
	 * Sube el fichero contable generado por el batch de contabilidad, al servidor sftp.
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.debug("La generación de informe");
		
		String fecha = (String)chunkContext.getStepContext().getJobParameters()
				.get(BatchGlobals.JOB_PARAM_DATE);
		
		List<TablaSeleccionRecibo> listaResultado=repository.reportExport(fecha);
		Date myDate = new Date();

		//Aquí obtienes el formato que deseas.
		String fechaFormateada=new SimpleDateFormat("yyyyMMddHHmm").format(myDate);
		String nombreFichero="CONCOMSEG_REPORT_"+fechaFormateada+".csv";
		String ruta=config.getFSOutPath()+nombreFichero;
		escribirReport(listaResultado, ruta);
		// Recuperamos el contexto de ejecución, lo usaremos para guardar datos
		// de la ejecución que usaremos en otras clases (como el id del job,
		// o el estado actual del proceso)
		StepExecution stepExec = chunkContext.getStepContext().getStepExecution();
		ExecutionContext contexto = stepExec.getJobExecution().getExecutionContext();
		
		// Nos conectamos al sftp
		// Usamos Spring Retry para reintentar varias veces la conexión
		contexto.putString(BatchGlobals.JOB_CTX_JOB_ACTION, BatchGlobals.ACTION_CONNECT);
		service.setTimeout(config.getConnectTimeout());
		connectRetrier = config.connectRetrier(stepExec.getJobExecutionId());
		connectRetrier.execute(retryContext -> {
			service.connect(config.getSFTPServer(), config.getSFTPPort(),
					config.getSFTPLogin(), config.getSFTPSecret());
		    return null;
		});
		contexto.remove(BatchGlobals.JOB_CTX_JOB_ACTION);
		
		// Enviamos el fichero contable al sftp
		contexto.putString(BatchGlobals.JOB_CTX_JOB_ACTION, BatchGlobals.ACTION_UPLOAD);
				
		LOGGER.debug("Iniciando subida del fichero contable");
		//List<String> ficheros = new ArrayList<>();
  	   // ficheros.add(config.getFSReportFile(nombreFichero));
		service.uploadFile(config.getFSReportFile(nombreFichero), config.getSFTPOutPath());
		
		contexto.remove(BatchGlobals.JOB_CTX_JOB_ACTION);
		
		// Desconectando del servidor sftp
		LOGGER.debug("Finalizando conexión al servidor sftp.");
		service.disconnect();
		
		// FIN OK
		LOGGER.debug("Fin exitoso del step");
		return RepeatStatus.FINISHED;
	}
	
	private void escribirReport(List<TablaSeleccionRecibo> listaReport,String ruta) {
	
     try(// FileWriter fichero = new FileWriter(ruta);
        	// PrintWriter 	 pw  = new PrintWriter(fichero);)
     
     OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(ruta),Charset.forName("ISO-8859-1"));)
    		//    osw.write("Hola mundo\n");

     {
    	
String cabecera="FechaEmisión;Cod.Recibo;Cod.Póliza;Sit.Recibo;TipoRecibo;FechaEfecto;Imp.PrimaTotalPol;Imp.PrimaNetaPol;ComisiónBruta;;EstadoInterno;RetrContab;Mediador;PeriodoPago;Producto;ComisiónLiquida;FechAltaComi;FechModif;FechRetrnCom;FechSitRecibo;FechUltPeriod;FechVtoRecibo;Imp.Cargo;ImTotPeriodo;ImpUltPeriodo;NumSuplemento";
osw.write(new String(cabecera.getBytes(Charset.forName("ISO-8859-1")), Charset.forName("ISO-8859-1"))+"\n");
         for (int i = 0; i <listaReport.size(); i++) {
        	 String linea="";
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhEmisRec().getTime())+";";
        	 linea+=listaReport.get(i).getCoRecibo()+";";
        	 linea+=listaReport.get(i).getCoPoliza()+";";
        	 linea+=listaReport.get(i).getCoSitRecibo()+";";
        	 linea+=listaReport.get(i).getCoTipoRecibo()+";";
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhEfeActRec().getTime())+";";
        	 linea+=String.valueOf(listaReport.get(i).getImPrimTotPol()).replace(".",",")+";";
        	 linea+=String.valueOf(listaReport.get(i).getImPrimNetPol()).replace(".",",")+";";
        	 linea+=String.valueOf(listaReport.get(i).getComBruta()).replace(".",",")+";";
        	 linea+=";";
        	 
        	 linea+=listaReport.get(i).getCiEstInterno()+";";
        	 linea+=listaReport.get(i).getCiRetrContab()+";";
             linea+=listaReport.get(i).getCoMediador()+";";
        	 linea+=listaReport.get(i).getCoPeriodPago()+";";	
        	 linea+=listaReport.get(i).getCoProducto()+";";      	
        	 linea+=String.valueOf(listaReport.get(i).getComLiquida()).replace(".",",")+";";
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhAltaCom().getTime())+";";    	 
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhModif().getTime())+";";
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhRetrCom().getTime())+";";
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhSitRec().getTime())+";";
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhUltPeriod().getTime())+";";
        	 linea+=new SimpleDateFormat("dd/MM/yyyy").format(listaReport.get(i).getFhVtoRec().getTime())+";";
        	 linea+=String.valueOf(listaReport.get(i).getImCargo()).replace(".",",")+";";
        	
        	
        	 linea+=String.valueOf(listaReport.get(i).getImTotPeriod()).replace(".",",")+";";
        	 linea+=String.valueOf(listaReport.get(i).getImUltPeriod()).replace(".",",")+";";
        	 linea+=listaReport.get(i).getNumSuplemento();
        	 osw.write(new String(linea.getBytes(Charset.forName("ISO-8859-1")), Charset.forName("ISO-8859-1"))+"\n");
        	
         }
         osw.close();  
       //  fichero.close();
     } catch (Exception e) {
    	
    	  LOGGER.error(e.getMessage());
     }

	}

}
