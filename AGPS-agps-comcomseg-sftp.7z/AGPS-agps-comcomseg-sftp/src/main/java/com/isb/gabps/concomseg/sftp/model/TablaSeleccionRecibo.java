package com.isb.gabps.concomseg.sftp.model;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class TablaSeleccionRecibo.
 */
@Entity

@Table(name = "SEGUROS_COMIS_CONTAB")//,schema="adescm1d")
public class TablaSeleccionRecibo implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 3371005308931383617L;

    /** The id poliza. */
    @Id
    @Column(name = "CO_POLIZA")
    private String coPoliza;

    /** The numero suplemento. */
    @Id
    @Column(name = "NUM_SUPLEMENTO")
    private int numSuplemento;

    /** The id mediador. */
    @Column(name = "CO_MEDIADOR")
    private String coMediador;

    /** The producto. */
    @Column(name = "CO_PRODUCTO")
    private String coProducto;

    /** The id recibo. */
    @Id
    @Column(name = "CO_RECIBO")
    private String coRecibo;

    /** The situacion recibo. */
    @Column(name = "CO_SIT_RECIBO")
    private String coSitRecibo;

    /** The clase recibo. */
    @Column(name = "CO_TIPO_RECIBO")
    private String coTipoRecibo;

    /** The fraccion pago. */
    @Column(name = "CO_PERIOD_PAGO")
    private String coPeriodPago;

    /** The fecha sitaucion. */
    @Column(name = "FH_SIT_REC")
    private Calendar fhSitRec;

    /** The fecha efecto actual. */
    @Column(name = "FH_EFE_ACT_REC")
    private Calendar fhEfeActRec;

    /** The fecha vencimiento. */
    @Column(name = "FH_VTO_REC")
    private Calendar fhVtoRec;

    /** The fecha emision. */
    @Column(name = "FH_EMIS_REC")
    private Calendar fhEmisRec;

    /** The prima total. */
    @Column(name = "IM_PRIM_TOT_POL")
    private double imPrimTotPol;

    /** The prima neta. */
    @Column(name = "IM_PRIM_NET_POL")
    private double imPrimNetPol;

    /** The cargo importe. */
    @Column(name = "IM_CARGO")
    private double imCargo;

    /** The comision bruta. */
    @Column(name = "COM_BRUTA")
    private double comBruta;

    /** The comision liquida. */
    @Column(name = "COM_LIQUIDA")
    private double comLiquida;

    /** The estado interno. */
    @Column(name = "CI_EST_INTERNO")
    private String ciEstInterno;

    /** The retroceder contabilidad. */
    @Column(name = "CI_RETR_CONTAB")
    private String ciRetrContab;

    /** The fecha alta comision. */
    @Column(name = "FH_ALTA_COM")
    private Calendar fhAltaCom;

    /** The fecha proceso retrocesion. */
    @Column(name = "FH_RETR_COM")
    private Calendar fhRetrCom;

    /** The fecha ult periodificacion. */
    @Column(name = "FH_ULT_PERIOD")
    private Calendar fhUltPeriod;

    /** The importe ult periodificacion. */
    @Column(name = "IM_ULT_PERIOD")
    private double imUltPeriod;

    /** The importe total peridificad. */
    @Column(name = "IM_TOT_PERIOD")
    private double imTotPeriod;

    /** The iduser. */
    @Column(name = "CO_USUARIO")
    private String coUsuario;

    /** The fecha modificacion. */
    @Column(name = "FH_MODIF")
    private Calendar fhModif;

    /**
     * Gets the co poliza.
     *
     * @return the coPoliza
     */
    public String getCoPoliza() {
        return coPoliza;
    }

    /**
     * Sets the co poliza.
     *
     * @param coPoliza
     *            the coPoliza to set
     */
    public void setCoPoliza(String coPoliza) {
        this.coPoliza = coPoliza;
    }

    /**
     * Gets the num suplemento.
     *
     * @return the numSuplemento
     */
    public int getNumSuplemento() {
        return numSuplemento;
    }

    /**
     * Sets the num suplemento.
     *
     * @param numSuplemento
     *            the numSuplemento to set
     */
    public void setNumSuplemento(int numSuplemento) {
        this.numSuplemento = numSuplemento;
    }

    /**
     * Gets the co mediador.
     *
     * @return the coMediador
     */
    public String getCoMediador() {
        return coMediador;
    }

    /**
     * Sets the co mediador.
     *
     * @param coMediador
     *            the coMediador to set
     */
    public void setCoMediador(String coMediador) {
        this.coMediador = coMediador;
    }

    /**
     * Gets the co producto.
     *
     * @return the coProducto
     */
    public String getCoProducto() {
        return coProducto;
    }

    /**
     * Sets the co producto.
     *
     * @param coProducto
     *            the coProducto to set
     */
    public void setCoProducto(String coProducto) {
        this.coProducto = coProducto;
    }

    /**
     * Gets the co recibo.
     *
     * @return the coRecibo
     */
    public String getCoRecibo() {
        return this.coRecibo;
    }

    /**
     * Sets the co recibo.
     *
     * @param coRecibo
     *            the coRecibo to set
     */
    public void setCoRecibo(String coRecibo) {
        this.coRecibo = coRecibo;
    }

    /**
     * Gets the co sit recibo.
     *
     * @return the coSitRecibo
     */
    public String getCoSitRecibo() {
        return coSitRecibo;
    }

    /**
     * Sets the co sit recibo.
     *
     * @param coSitRecibo
     *            the coSitRecibo to set
     */
    public void setCoSitRecibo(String coSitRecibo) {
        this.coSitRecibo = coSitRecibo;
    }

    /**
     * Gets the co tipo recibo.
     *
     * @return the coTipoRecibo
     */
    public String getCoTipoRecibo() {
        return coTipoRecibo;
    }

    /**
     * Sets the co tipo recibo.
     *
     * @param coTipoRecibo
     *            the coTipoRecibo to set
     */
    public void setCoTipoRecibo(String coTipoRecibo) {
        this.coTipoRecibo = coTipoRecibo;
    }

    /**
     * Gets the co period pago.
     *
     * @return the coPeriodPago
     */
    public String getCoPeriodPago() {
        return coPeriodPago;
    }

    /**
     * Sets the co period pago.
     *
     * @param coPeriodPago
     *            the coPeriodPago to set
     */
    public void setCoPeriodPago(String coPeriodPago) {
        this.coPeriodPago = coPeriodPago;
    }

    /**
     * Gets the fh sit rec.
     *
     * @return the fhSitRec
     */
    public Calendar getFhSitRec() {
        return fhSitRec;
    }

    /**
     * Sets the fh sit rec.
     *
     * @param fhSitRec
     *            the fhSitRec to set
     */
    public void setFhSitRec(Calendar fhSitRec) {
        this.fhSitRec = fhSitRec;
    }

    /**
     * Gets the fh efe act rec.
     *
     * @return the fhEfeActRec
     */
    public Calendar getFhEfeActRec() {
        return fhEfeActRec;
    }

    /**
     * Sets the fh efe act rec.
     *
     * @param fhEfeActRec
     *            the fhEfeActRec to set
     */
    public void setFhEfeActRec(Calendar fhEfeActRec) {
        this.fhEfeActRec = fhEfeActRec;
    }

    /**
     * Gets the fh vto rec.
     *
     * @return the fhVtoRec
     */
    public Calendar getFhVtoRec() {
        return fhVtoRec;
    }

    /**
     * Sets the fh vto rec.
     *
     * @param fhVtoRec
     *            the fhVtoRec to set
     */
    public void setFhVtoRec(Calendar fhVtoRec) {
        this.fhVtoRec = fhVtoRec;
    }

    /**
     * Gets the fh emis rec.
     *
     * @return the fhEmisRec
     */
    public Calendar getFhEmisRec() {
        return fhEmisRec;
    }

    /**
     * Sets the fh emis rec.
     *
     * @param fhEmisRec
     *            the fhEmisRec to set
     */
    public void setFhEmisRec(Calendar fhEmisRec) {
        this.fhEmisRec = fhEmisRec;
    }

    /**
     * Gets the im prim tot pol.
     *
     * @return the imPrimTotPol
     */
    public double getImPrimTotPol() {
        return imPrimTotPol;
    }

    /**
     * Sets the im prim tot pol.
     *
     * @param imPrimTotPol
     *            the imPrimTotPol to set
     */
    public void setImPrimTotPol(double imPrimTotPol) {
        this.imPrimTotPol = imPrimTotPol;
    }

    /**
     * Gets the im prim net pol.
     *
     * @return the imPrimNetPol
     */
    public double getImPrimNetPol() {
        return imPrimNetPol;
    }

    /**
     * Sets the im prim net pol.
     *
     * @param imPrimNetPol
     *            the imPrimNetPol to set
     */
    public void setImPrimNetPol(double imPrimNetPol) {
        this.imPrimNetPol = imPrimNetPol;
    }

    /**
     * Gets the im cargo.
     *
     * @return the imCargo
     */
    public double getImCargo() {
        return imCargo;
    }

    /**
     * Sets the im cargo.
     *
     * @param imCargo
     *            the imCargo to set
     */
    public void setImCargo(double imCargo) {
        this.imCargo = imCargo;
    }

    /**
     * Gets the com bruta.
     *
     * @return the comBruta
     */
    public double getComBruta() {
        return comBruta;
    }

    /**
     * Sets the com bruta.
     *
     * @param comBruta
     *            the comBruta to set
     */
    public void setComBruta(double comBruta) {
        this.comBruta = comBruta;
    }

    /**
     * Gets the com liquida.
     *
     * @return the comLiquida
     */
    public double getComLiquida() {
        return comLiquida;
    }

    /**
     * Sets the com liquida.
     *
     * @param comLiquida
     *            the comLiquida to set
     */
    public void setComLiquida(double comLiquida) {
        this.comLiquida = comLiquida;
    }

    /**
     * Gets the ci est interno.
     *
     * @return the ciEstInterno
     */
    public String getCiEstInterno() {
        return ciEstInterno;
    }

    /**
     * Sets the ci est interno.
     *
     * @param ciEstInterno
     *            the ciEstInterno to set
     */
    public void setCiEstInterno(String ciEstInterno) {
        this.ciEstInterno = ciEstInterno;
    }

    /**
     * Gets the ci retr contab.
     *
     * @return the ciRetrContab
     */
    public String getCiRetrContab() {
        return ciRetrContab;
    }

    /**
     * Sets the ci retr contab.
     *
     * @param ciRetrContab
     *            the ciRetrContab to set
     */
    public void setCiRetrContab(String ciRetrContab) {
        this.ciRetrContab = ciRetrContab;
    }

    /**
     * Gets the fh alta com.
     *
     * @return the fhAltaCom
     */
    public Calendar getFhAltaCom() {
        return fhAltaCom;
    }

    /**
     * Sets the fh alta com.
     *
     * @param fhAltaCom
     *            the fhAltaCom to set
     */
    public void setFhAltaCom(Calendar fhAltaCom) {
        this.fhAltaCom = fhAltaCom;
    }

    /**
     * Gets the fh retr com.
     *
     * @return the fhRetrCom
     */
    public Calendar getFhRetrCom() {
        return fhRetrCom;
    }

    /**
     * Sets the fh retr com.
     *
     * @param fhRetrCom
     *            the fhRetrCom to set
     */
    public void setFhRetrCom(Calendar fhRetrCom) {
        this.fhRetrCom = fhRetrCom;
    }

    /**
     * Gets the fh ult period.
     *
     * @return the fhUltPeriod
     */
    public Calendar getFhUltPeriod() {
        return fhUltPeriod;
    }

    /**
     * Sets the fh ult period.
     *
     * @param fhUltPeriod
     *            the fhUltPeriod to set
     */
    public void setFhUltPeriod(Calendar fhUltPeriod) {
        this.fhUltPeriod = fhUltPeriod;
    }

    /**
     * Gets the im ult period.
     *
     * @return the imUltPeriod
     */
    public double getImUltPeriod() {
        return imUltPeriod;
    }

    /**
     * Sets the im ult period.
     *
     * @param imUltPeriod
     *            the imUltPeriod to set
     */
    public void setImUltPeriod(double imUltPeriod) {
        this.imUltPeriod = imUltPeriod;
    }

    /**
     * Gets the im tot period.
     *
     * @return the imTotPeriod
     */
    public double getImTotPeriod() {
        return imTotPeriod;
    }

    /**
     * Sets the im tot period.
     *
     * @param imTotPeriod
     *            the imTotPeriod to set
     */
    public void setImTotPeriod(double imTotPeriod) {
        this.imTotPeriod = imTotPeriod;
    }

    /**
     * Gets the co usuario.
     *
     * @return the coUsuario
     */
    public String getCoUsuario() {
        return coUsuario;
    }

    /**
     * Sets the co usuario.
     *
     * @param coUsuario
     *            the coUsuario to set
     */
    public void setCoUsuario(String coUsuario) {
        this.coUsuario = coUsuario;
    }

    /**
     * Gets the fh modif.
     *
     * @return the fhModif
     */
    public Calendar getFhModif() {
        return fhModif;
    }

    /**
     * Sets the fh modif.
     *
     * @param fhModif
     *            the fhModif to set
     */
    public void setFhModif(Calendar fhModif) {
        this.fhModif = fhModif;
    }

}
