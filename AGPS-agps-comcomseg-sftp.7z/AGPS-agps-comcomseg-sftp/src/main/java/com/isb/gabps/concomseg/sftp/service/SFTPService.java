package com.isb.gabps.concomseg.sftp.service;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Path;
import java.util.List;

import com.isb.gabps.concomseg.sftp.SFTPException;
import com.jcraft.jsch.SftpException;

/**
 * Servicio que realiza las conexiones SSH para el envio y recepcion de los ficheros
 * al servidor sftpnuevo.
 * 
 * @author xIS08485
 */
public interface SFTPService {
	/**
	 * Define el tiempo a esperar antes de dar un timeout
	 * durante la apertura de conexi�n al servidor sftp.
	 * 
	 * @param milliseconds Tiempo a esperar (milisegundos)
	 */
	public void setTimeout(int timeout);
	
	/***
	 * Abre una conexi�n al servidor sftp.
	 * 
	 * @param server IP/hostname del servidor ssh
	 * @param port Puerto del servidor ssh
	 * @param login Usuario de conexi�n
	 * @param secret Contrase�a del usuario de conexi�n
	 * 
	 * @return void
	 *  
	 * @throws SFTPException Error ocurrido durante la ejecuci�n, tipos de errores:
	 * <ul>
	 * <li>INPUT_DATA_ERROR: Error en validaci�n de datos de entrada</li>
	 * <li>CONNECTION_ERROR: Error de comunicaci�n con el servidor sftp</li>
	 * <li>TECHNICAL_ERROR: Error t�cnico</li>
	 * </ul> 
	 */
	public void connect(String server, int port, String login, String secret)
			throws SFTPException;
	
	/**
	 * Desconectarse del servidor sftp.
	 *  @return void
	 */
	public void disconnect();
	
	/**
	 * Busca y descarga los archivos que cumplan con el patr�n de b�squeda.
	 * La ruta {@code destination} debe ser una carpeta, y se crear� si no existe.
	 * Si uno de los ficheros no puede ser descargado, se detiene el proceso.
	 * 
	 * @param pattern Patr�n de b�squeda (globbing pattern)
	 * @param destination Carpeta donde se guardar�n los ficheros
	 * @param mes  mes de contabilizaci�n
	 * 
	 * @return List<Path> Devuelve las ruta en local donde se han guardado los ficheros
	 * 
	 * @throws SFTPException Error ocurrido durante la ejecuci�n, tipos de errores:
	 * <ul>
	 * <li>INPUT_DATA_ERROR: Error en validaci�n de datos de entrada</li>
	 * <li>CONNECTION_ERROR: Error de comunicaci�n con el servidor sftp</li>
	 * <li>TECHNICAL_ERROR: Error t�cnico</li>
	 * </ul>
	 * 
	 * @see <a href="https://docs.oracle.com/javase/tutorial/essential/io/fileOps.html#glob">Globbing Pattern</a>
	 */ 
	public List<String> downloadFiles(String pattern, String destination,String mes) throws SFTPException;
	
	/**
	 * Env�a una lista de ficheros al servidor sftp.
	 * La ruta {@code destination} debe existir de lo contrario se devolver� error.
	 * 
	 * @param files Lista de ficheros a enviar
	 * @param destination Carpeta (en local) donde se guardar�n los ficheros
	 * 
	 * @return void
	 * 
	 * @throws SFTPException Error ocurrido durante la ejecuci�n, tipos de errores:
	 * <ul>
	 * <li>INPUT_DATA_ERROR: Error en validaci�n de datos de entrada</li>
	 * <li>CONFIGURATION_ERROR: Error de configuraci�n</li>
	 * <li>CONNECTION_ERROR: Error de comunicaci�n con el servidor sftp</li>
	 * <li>TECHNICAL_ERROR: Error t�cnico</li>
	 * </ul>
	 */
	public void uploadFile(String file, String destination) throws SFTPException;
	
	/**
	 * Env�a una lista de ficheros al servidor sftp.
	 * La ruta {@code destination} debe existir de lo contrario se devolver� error.
	 * 
	 * @param pattern Lista de ficheros a enviar
	 * @param destination Carpeta (en local) donde se guardar�n los ficheros
	 * @param nuevo Estado para el nuevo mes
	 * 
	 * @throws SFTPException Error ocurrido durante la ejecuci�n, tipos de errores:
	 * <ul>
	 * <li>INPUT_DATA_ERROR: Error en validaci�n de datos de entrada</li>
	 * <li>CONFIGURATION_ERROR: Error de configuraci�n</li>
	 * <li>CONNECTION_ERROR: Error de comunicaci�n con el servidor sftp</li>
	 * <li>TECHNICAL_ERROR: Error t�cnico</li>
	 * </ul>
	 * @return List<Path>
	 */
	public List<String> sftpDownloadFiles(String pattern, String destination,boolean nuevo)throws SftpException;
	/**
	 * Env�a una lista de ficheros al servidor sftp.
	 * La ruta {@code destination} debe existir de lo contrario se devolver� error.
	 * 
	 * @param pattern Patron de entrada
	 * @return List<String> lista
	 * @throws SFTPException Error ocurrido durante la ejecuci�n, tipos de errores:
	 * 
	 */
	public List<String> sftpListFiles(String pattern) throws SftpException;
	/**
	 * Env�a una lista de ficheros al servidor sftp.
	 * La ruta {@code destination} debe existir de lo contrario se devolver� error.
	 * 
	 * @param rutaFichero ruta fichero
     * @return ByteArrayOutputStream Fichero en total
	 * @throws SFTPException Error ocurrido durante la ejecuci�n, tipos de errores:
	 * 
	 */
	public ByteArrayOutputStream sftpDownloadFile(String rutaFichero) throws SftpException;

	/**
	 * Env�a una lista de ficheros al servidor sftp.
	 * La ruta {@code destination} debe existir de lo contrario se devolver� error.
	 * 
	 * @param rutaFichero la ruta del fichero
     * @return InputStream Fichero de entrada
	 * @throws SFTPException Error ocurrido durante la ejecuci�n, tipos de errores:
	 * 
	 */
	InputStream getFichero(String rutaFichero) throws SFTPException;

	/**
	 * Sube un fichero al servidor sftp.
	 * La ruta {@code destination} debe existir de lo contrario se devolver� error.
	 * 
	 * @param fichero Fichero
	 * @param destination Destino del fichero
	 * @param nombre Nombre del fichero
     * @return void
	 * @throws SFTPException Error ocurrido durante la ejecuci�n, tipos de errores:
	 * 
	 */
	void uploadBinaryFiles(InputStream fichero, String destination,String nombre) throws SFTPException;

	/**
	 * Renombre ficheros en el sftp 
	 * 
	 * @param pattern Patron
	 * @param destination Destino del fichero
	 * 
     * @return void
     * 
	 */
	void sftpRenameFiles(String pattern, Path destination);

	void deleteFile(String file, String destination) throws SFTPException;

	List<String> limpiaS3();
}