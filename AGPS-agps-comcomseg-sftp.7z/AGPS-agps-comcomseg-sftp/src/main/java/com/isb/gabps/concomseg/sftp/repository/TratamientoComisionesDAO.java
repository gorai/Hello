package com.isb.gabps.concomseg.sftp.repository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.isb.gabps.concomseg.sftp.exception.ComiSegException;
import com.isb.gabps.concomseg.sftp.model.TablaConvProducto;
import com.isb.gabps.concomseg.sftp.model.TablaSeleccionRecibo;



/**
 * The Class TratamientoComisionesDAO.
 */
@Repository
@EntityScan(basePackages = { "com.isb.gabps.concomseg" })
public class TratamientoComisionesDAO implements TratComDao {
	

    /** The Constant LOGGER. */
    private static final Logger LOGGER =  LoggerFactory.getLogger(TratamientoComisionesDAO.class);
   
    /** The entity manager. */
    @PersistenceContext
    private EntityManager entityManager;
  
    /** The com seg resul. */
    /*
     * (non-Javadoc)
     *
     * @see com.isb.concomseg.daos.TratComDao#existePoliza(java.lang.String,
     * java.lang.String, java.lang.String)
     */
    @Override
    public List<TablaSeleccionRecibo> existePoliza(String idPoliza, Integer numeroSuplemento, String idRecibo) {
    	
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        LOGGER.debug("JMLO Hacemos la consulta2 ");
         
        CriteriaQuery<TablaSeleccionRecibo> query = cb.createQuery(TablaSeleccionRecibo.class);
        Root<TablaSeleccionRecibo> root = query.from(TablaSeleccionRecibo.class);
        LOGGER.debug("JMLO Preparamos la consulta");
        query.select(root);
        query.where(cb.and(cb.equal(root.get("coPoliza"), idPoliza)));//, cb
               //.and(cb.equal(root.get("numSuplemento"), numeroSuplemento), cb.equal(root.get("coRecibo"), idRecibo))));
      

        LOGGER.debug("JMLO Le metemos el where");
        return entityManager.createQuery(query).getResultList();
    }

 
    /*
     * (non-Javadoc)
     *
     * @see
     * com.isb.concomseg.daos.TratComDao#insertarEstado(com.isb.concomseg.model.
     * TablaSeleccionRecibo)
     */
    public List<TablaSeleccionRecibo> reportExport(String date){
    	
    	  CriteriaBuilder cb = entityManager.getCriteriaBuilder();
          LOGGER.debug("JMLO Generamos el reporte");
          if(date.length()<6) {
        	  	return null; 
          }
           else {
           int anio=Integer.valueOf(date.substring(0,4));
           int mes=Integer.valueOf(date.substring(4,6));
          CriteriaQuery<TablaSeleccionRecibo> query = cb.createQuery(TablaSeleccionRecibo.class);
          Root<TablaSeleccionRecibo> root = query.from(TablaSeleccionRecibo.class);
          LOGGER.debug("JMLO Preparamos la consulta");
        
          query.select(root);
          query.where( cb.equal(cb.function("YEAR", Integer.class, root.get("fhModif") ), anio),cb.and(
        		  cb.equal(cb.function("MONTH", Integer.class, root.get("fhModif") ), mes)));
         
          LOGGER.debug("JMLO Le metemos el where");
          return entityManager.createQuery(query).getResultList();
           }
    }
    
    public List<TablaSeleccionRecibo> reportExport(){
    	
    	  CriteriaBuilder cb = entityManager.getCriteriaBuilder();
          LOGGER.debug("JMLO Generamos el reporte");
         
          CriteriaQuery<TablaSeleccionRecibo> query = cb.createQuery(TablaSeleccionRecibo.class);
          Root<TablaSeleccionRecibo> root = query.from(TablaSeleccionRecibo.class);
          LOGGER.debug("JMLO Preparamos la consulta");
        
          query.select(root);
         // query.where( cb.equal(cb.function("YEAR", Integer.class, root.get("fhModif") ), anio),cb.and(
        	//	  cb.equal(cb.function("MONTH", Integer.class, root.get("fhModif") ), mes)));
         
          LOGGER.debug("JMLO Le metemos el where");
          return entityManager.createQuery(query).getResultList();
           
    }
    @Override
    public List<String> listaProductos(){
    	
  	  CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        LOGGER.debug("JMLO Generamos el reporte");
       
        CriteriaQuery<TablaConvProducto> query = cb.createQuery(TablaConvProducto.class);
        Root<TablaConvProducto> root = query.from(TablaConvProducto.class);
        LOGGER.debug("JMLO Preparamos la consulta");
      
        query.select(root);
       // query.where( cb.equal(cb.function("YEAR", Integer.class, root.get("fhModif") ), anio),cb.and(
      	//	  cb.equal(cb.function("MONTH", Integer.class, root.get("fhModif") ), mes)));
       
        LOGGER.debug("JMLO Le metemos el where");
        
        List<TablaConvProducto> listaProductos= entityManager.createQuery(query).getResultList();
        List<String> listaNomProductos= new ArrayList<String>();
        for(int i=0;i<listaProductos.size();i++){
        	listaNomProductos.add(listaProductos.get(i).getCoProducto());
        }
        return listaNomProductos;
         
  }
    
}
