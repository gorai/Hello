package com.isb.gabps.concomseg.sftp.batch.rest;

/**
 * Constantes relativas a los controllers batch
 * 
 * @author xIS08485
 */
public class ControllerGlobals {
	// Parámetros
	public static final String PARAM_URL_DATE = "{date}";
	public static final String PARAM_REQUEST_CYCLE = "new-cycle";
	
	// URLs de los jobs
	public static final String URL_BASE = "/job";
	public static final String URL_PULL_JOB = URL_BASE + "/pull-files/" + PARAM_URL_DATE;
	public static final String URL_PUSH_JOB = URL_BASE + "/push-files/" + PARAM_URL_DATE;
	public static final String URL_REPORT_JOB = URL_BASE + "/report/" + PARAM_URL_DATE;
	// Plantillas de mensajes
	public static final String TEMPLATE_LOG_REQUEST = "Atendiendo petición '%s %s";
	public static final String TEMPLATE_LOG_RESPONSE = "Respuesta petición: '%s'";
	public static final String TEMPLATE_RESPONSE = "%s: %s";
	public static final String TEMPLATE_NOT_FOUND = "?";
	
	// IDs de los mensajes
	public static final String MESSAGES_PREFIX = "batch.";
	public static final String MESSAGES_REJECTED_PREFIX = MESSAGES_PREFIX + "rejected.";
	public static final String MESSAGES_FAILED_PREFIX = MESSAGES_PREFIX + "failed.";
	
	// Estados del job adicionales creados por el controller
	public static final String STATUS_NOT_FOUND = "NOT-FOUND";
	public static final String STATUS_REJECTED = "REJECTED";
	
	
	
	// Clase no inicializable.
	private ControllerGlobals() {
		// No hace nada
	}
}
