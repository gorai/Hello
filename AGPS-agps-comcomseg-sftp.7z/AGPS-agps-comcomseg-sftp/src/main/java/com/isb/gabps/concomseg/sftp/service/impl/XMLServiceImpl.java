package com.isb.gabps.concomseg.sftp.service.impl;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;


import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import com.isb.conector.S3Repository;
import com.isb.conector.S3RepositoryImpl;
import com.isb.conector.S3RepositoryImplDummie;
import com.isb.gabps.concomseg.sftp.SFTPConfig;
import com.isb.gabps.concomseg.sftp.SFTPException;
import com.isb.gabps.concomseg.sftp.repository.TratComDao;

import com.isb.gabps.concomseg.sftp.service.XMLService;
import com.isb.gabps.concomseg.sftp.util.ExceptionsHelper;
import com.isb.gabps.concomseg.sftp.util.ValidationsHelper;

/**
 * Servicio para el tratamiento de ficheros XMLs, permitiendo hacer merge entre
 * varios ficheros.
 * 
 * @author xIS08485
 */
@Primary
@Service
@ComponentScan(basePackages = { "com.isb.gabps.concomseg" })
public class XMLServiceImpl implements XMLService {
	private static final String XPATH_PRODUCTO = "./DatosPoliza/ProductoDGS";
	
	// Logger
	private static final Logger LOGGER = LoggerFactory.getLogger(XMLServiceImpl.class);

	// Expresiones XPath
	private static final String XPATH_HEADER = "/ProcesosEIAC/Cabecera";
	private static final String XPATH_HEADER_DATE = "./FechaCreacion";
	private static final String XPATH_HEADER_RECEIVER = "./Receptor/CodigoInterno";
	private static final String XPATH_IDRECIBO="./DatosRecibo/IdRecibo";
	private static final String XPATH_HEADER_PROCESS = "./DatosProcesos/DetalleProcesos";
	private static final String XPATH_HEADER_BATCH_ID = "./DatosLote/IdLote";
	private static final String XPATH_HEADER_BATCH_SEQ = "./DatosLote/SecuenciaFichero";
	private static final String XPATH_HEADER_BATCH_TOTAL = "./DatosLote/NumeroFicheros";
	private static final String XPATH_BODY = "/ProcesosEIAC/Objetos";
	

	// Rutas est�ticas
	private static final String PATH_XSLT = "xslt/contabilidad-zurich.xslt";

	// Librerias XML
	private DocumentBuilder domBuilder;
	private XPath xpath;
	private Transformer domTransformer;
	private Transformer xsltTransformer;
	
	S3Repository repository;
	
	@Autowired
	private SFTPConfig config;

	/** The index. */
	protected int index = 0;

	/** The input. */
	private List<Double> input = new ArrayList<>();

	/**
	 * Constructor, inicializa las clases que se usar�n para el tratamiento de XMLs.
	 * 
	 * @throws SFTPException
	 *             Tpos de errores:
	 *             <ul>
	 *             <li>CONFIGURATION_ERROR: Error de configuraci�n (no existe el
	 *             fichero xslt)</li>
	 *             <li>TECHNICAL_ERROR: Error t�cnico que no deber�a ocurrir, alg�n
	 *             problema grave</li>
	 *             </ul>
	 */


	public XMLServiceImpl() throws SFTPException {
		try {
			// DOM builder
			
			
			DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
			df.setIgnoringComments(true);
			df.setValidating(false);
	
			df.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
			domBuilder = df.newDocumentBuilder();
			
	
			// XPath
			XPathFactory xf = XPathFactory.newInstance();
			xpath = xf.newXPath();

			// Transformador DOM -> XML
			TransformerFactory tf = TransformerFactory.newInstance();
			//tf.setAttribute("indent-number", 2);
			domTransformer = tf.newTransformer();
			domTransformer.setOutputProperty(OutputKeys.INDENT, "yes");
			//domTransformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

			// Transformador XSLT
			Resource xsltRes = new ClassPathResource(PATH_XSLT);
			if (!xsltRes.exists()) {
				LOGGER.error("No existe el xslt en la ruta: " + xsltRes);
				throw ExceptionsHelper.pathNonExistentError("classpath", xsltRes.toString());
			} else {
				StreamSource xsltSS = new StreamSource(xsltRes.getInputStream());
				xsltTransformer = TransformerFactory.newInstance().newTransformer(xsltSS);
				xsltTransformer.setOutputProperty(OutputKeys.INDENT, "yes");
			}
		} catch (ParserConfigurationException | TransformerConfigurationException e) {
			String error = "Error al inicializar el procesador XML";
			LOGGER.error(error, e);
			throw ExceptionsHelper.xmlProcessingError(error, e);
		} catch (IOException e) {
			String error = "Error en la carga del xslt";
			LOGGER.error(error, e);
			throw ExceptionsHelper.unexpectedError(error);
		}
	}
	

	
	public String quitarSaltos(InputStream fichero) {
		
		 String         line = null;
		 StringBuilder  stringBuilder = new StringBuilder();
	     String         ls = System.getProperty("line.separator");
	     Reader lector = new InputStreamReader(fichero);
		 
	     BufferedReader  reader = new BufferedReader(lector);
			       try {
					while((line = reader.readLine()) != null) {
						if(line.contains("<ModalidadRamo>ZV"))
							line=line.replaceAll("<ModalidadRamo>ZV", "<ModalidadRamo>");
					        stringBuilder.append(line);
					       // stringBuilder.append(ls);
					    }
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		return stringBuilder.toString();
	}

	// Permite hacer merge-union de los XMLs diarios en uno mensual.
	@Override
	public void mergeUnion(List<String> sources, String target, LocalDate date, long cycle) throws SFTPException {
		if(cycle<0)
			return;
		if(repository==null)
			repository =  config.getS3Repository(); //if(false)S3RepositoryImplDummie()S3RepositoryImpl()
		// Validaciones
		ValidationsHelper.notEmpty("datos de entrada", "sources", sources);
		ValidationsHelper.notNull("datos de entrada", "target", target);
		ValidationsHelper.notNull("datos de entrada", "date", date);
		ValidationsHelper.isPositive("datos de entrada", "cycle", cycle);

		// Validar rutas
	if(false) {}	
	//	if (Files.exists(target)) {
	//		LOGGER.warn("El fichero '" + target + "' ya existe, se sobreescribir�");
	//	}

	
		try {
			// Creamos el XML destino
			Document fusionado = domBuilder.newDocument();
			boolean nuevo = true;

			// Procesar los XMLs individuales (diarios)
			for (String ruta : sources) {
	
				// Validar XML origen
				InputStream datoFichero = repository.getFromS3(ruta, config.getBucketName());
			
		         LOGGER.warn("JMLO W::obteniendo union");
		       
				checkSourceXML(datoFichero);
			
				DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
				df.setIgnoringComments(true);
				df.setValidating(false);
		
				df.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
				
				domBuilder = df.newDocumentBuilder();
				// Si el XML fusionado no tiene cabecera, la copiamos de este fichero
				//JMLOV1
//				InputStream fichero=service.getFichero(ruta.toString());
				datoFichero = repository.getFromS3(ruta, config.getBucketName());
				
				String ficheroPlano=quitarSaltos(datoFichero);
				Document origen = domBuilder.parse(new InputSource(new StringReader(ficheroPlano)));//if(false)
				if (nuevo) {
					copyXML(origen, fusionado, date, cycle);
					nuevo = false;
				} else {
					appendXML(origen, fusionado);
				}
			}
			// Grabamos el XML fusionado a disco
				DOMSource ds = new DOMSource(fusionado);
			//	 StringWriter sw = new StringWriter();
		//if(false)
			OutputStream out = new ByteArrayOutputStream();
		    StreamResult result = new StreamResult(out);
 		   
			domTransformer.transform(ds, result);		
			InputStream inStream = new ByteArrayInputStream(((ByteArrayOutputStream) out).toByteArray() );
			String sinSaltos=quitarSaltos(inStream);
			
			DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			Document doc = db.parse( new InputSource( new StringReader( sinSaltos ) ) ); 
			
			DOMSource source = new DOMSource(doc);
			
			OutputStream out2 = new ByteArrayOutputStream();
			
			StreamResult sr2 = new StreamResult(out2);
			domTransformer.transform(source, sr2);
			
		
			repository.putToS3(target,config.getBucketName(), null,((ByteArrayOutputStream)out2).toByteArray() , false,config.getBucketKms());
		
		} catch (IllegalArgumentException | SAXException | XPathExpressionException | TransformerException e) {
			String error = "Error durante el procesamiento del XML";
			LOGGER.error(error, e);
			throw ExceptionsHelper.xmlProcessingError(error, e);
		} catch (IOException e) {
			String error = "Error en lectura/escritura de XML";
			LOGGER.error(error, e);
			throw ExceptionsHelper.xmlProcessingError(error, e);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			String error = "Error de parseo";
			LOGGER.error(error, e);
			throw ExceptionsHelper.xmlProcessingError(error, e);
		}
	}

	// Permite hacer merge-join de los XMLs de recibos y p�lizas, en uno.
	@Override
	public InputStream mergeJoin(String policyXML, String collectionXML, String target,String jobId) throws SFTPException {
		if(repository==null)
			repository =  config.getS3Repository(); //if(false)S3RepositoryImplDummie()S3RepositoryImpl()
		// Validar los datos de entrada
		ValidationsHelper.notNull("datos de entrada", "policyXML", policyXML);
	if(false) {}
	/*if (!Files.exists(policyXML)) {
			LOGGER.error("No existe el XML de p�lizas en la ruta: " + policyXML);
			throw ExceptionsHelper.pathNonExistentError("filesystem", policyXML.toString());
		}*/
		ValidationsHelper.notNull("datos de entrada", "collectionXML", collectionXML);
	/*	if (!Files.exists(collectionXML)) {
			LOGGER.error("No existe el XML de p�lizas en la ruta: " + collectionXML);
			throw ExceptionsHelper.pathNonExistentError("filesystem", collectionXML.toString());
		}*/
		ValidationsHelper.notNull("datos de entrada", "target", target);

		// Validar rutas
	/*	if (Files.exists(target)) {
			LOGGER.warn("El fichero '" + target + "' ya existe, se sobreescribir�");
		}*/
		
		
		InputStream input=repository.getFromS3(collectionXML, config.getBucketName());
		// Fusiona los XMLs de p�lizas y recibos utilizando el xslt
		try {
		
			InputStream polizas=repository.getFromS3(policyXML, config.getBucketName());
			
			if(polizas==null)
				return null;
		//	Document documento=readXml(polizas);	
		
			DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
			df.setIgnoringComments(true);
			df.setValidating(false);
	
			df.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
			
			DocumentBuilder domBuilder=df.newDocumentBuilder();
		  	Document doc2 = domBuilder.parse(polizas);
			doc2.getDocumentElement().normalize();
			
			xsltTransformer.setParameter("policy-file",doc2);

			OutputStream out = new ByteArrayOutputStream();
		    StreamResult result = new StreamResult(out);
		   input=repository.getFromS3(collectionXML, config.getBucketName());
			StreamSource xml = new StreamSource(input);//RECIBOS
	    	xsltTransformer.transform(xml, result);
	       String a=	new String (((ByteArrayOutputStream) out).toByteArray() );
	    	InputStream inStream = new ByteArrayInputStream(a.getBytes() );
		//	input	= new FileInputStream(new File("d:\\a.xml"));
	    	 StreamResult result2 =null;
		
	
			Document doc = domBuilder.parse(inStream);
			doc.getDocumentElement().normalize();

			Document doc3 = domBuilder.newDocument();
			OutputStream out2=null;
			try {
				copyXMLValores(doc, doc3);
				DOMSource ds = new DOMSource(doc3);
			//	StreamResult sr = new StreamResult(target);//if(false)
		        out2 = new ByteArrayOutputStream();
		        result2 = new StreamResult(out2);
				domTransformer.transform(ds, result2);
			//	repository.putToS3(target,config.getBucketName(), null,((ByteArrayOutputStream)out2).toByteArray() , false,config.getBucketKms());
			

			} catch (XPathExpressionException e) {
				// TODO Auto-generated catch block
				  LOGGER.error(e.getMessage());
			}    
			finally {
				if(input!=null)
				input.close();  
		    	  }

			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer transformer = tf.newTransformer();
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

			StringWriter writer = new StringWriter();
			transformer.transform(new DOMSource(doc), new StreamResult(writer));
			
			String output = writer.getBuffer().toString().replaceAll("\n|\r", "");
			//return repository.getFromS3(target, config.getBucketKms());
			//
			InputStream salida= new ByteArrayInputStream(((ByteArrayOutputStream)out2).toByteArray());
			return salida;
		} catch (TransformerException | SAXException | IOException | ParserConfigurationException e) {
			String error = "Error durante el procesamiento del XML";
			try {
				if(input!=null)
				input.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				LOGGER.error(error, e);
				throw ExceptionsHelper.xmlProcessingError(error, e);
			}
			LOGGER.error(error, e);
			throw ExceptionsHelper.xmlProcessingError(error, e);
		} 

	}
	@Override
	public boolean enviarFicheroCompleto(byte[] input,String target) {
		if(input==null)
			return true;
		if(repository==null)
			repository =  config.getS3Repository();
		repository.putToS3(target,config.getBucketName(), null,input, false,config.getBucketKms());
		
		return true;
		
	}
	/**
	 * Realiza validaciones sobre el XML origen.
	 * 
	 * @param ruta
	 *            Ruta al XML
	 * @throws SFTPException
	 *             Error de validaci�n
	 * @throws XPathExpressionException
	 *             error procesando XML
	 * @throws IOException
	 *             error entrada/salida XML
	 * @throws SAXException
	 *             error procesando XML
	 */

	private void checkSourceXML(InputStream ruta) throws SFTPException, SAXException, IOException, XPathExpressionException {
		// Validar si fichero existe
		if(false) {}
	//	if (!Files.exists(ruta)) {	
	//		throw ExceptionsHelper.pathNonExistentError("filesystem local", ruta.toString());
	//	}
		DocumentBuilder db=null;
		// Validaciones m�nimas del XML a copiar
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
		    dbf.setNamespaceAware(true);
		    dbf.setValidating(false);
		    db = dbf.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			  LOGGER.error(e.getMessage());
		}
		
//		Reader lector = new InputStreamReader(ruta);
//		 try( BufferedReader  reader = new BufferedReader(lector)) { //if(false)
			
//	    String         line = null;
//	    StringBuilder  stringBuilder = new StringBuilder();
//	    String         ls = System.getProperty("line.separator");

	 
	 /*       while((line = reader.readLine()) != null) {
	            stringBuilder.append(line);
	            stringBuilder.append(ls);
	        }

stringBuilder=null;
*/

SAXParserFactory factory = SAXParserFactory.newInstance();
factory.setValidating(false);
factory.setNamespaceAware(true);

	//	 } catch (Exception e) {
			 
	//		 LOGGER.error(e.getMessage());
	//	 }

		Document origen = domBuilder.parse(ruta);//(if(false)
		Node oriCabecera = (Node) xpath.evaluate(XPATH_HEADER, origen, XPathConstants.NODE);
		if (oriCabecera == null) {
			String mensaje = "El XML '" + ruta + "' no lleva cabecera.";
			LOGGER.error(mensaje);
			throw ExceptionsHelper.xmlProcessingError(mensaje);
		}
		Node oriCuerpo = (Node) xpath.evaluate(XPATH_BODY, origen, XPathConstants.NODE);
		if (oriCuerpo == null) {
			String mensaje = "El XML '" + ruta + "' no lleva cuerpo.";
			LOGGER.error(mensaje);
			throw ExceptionsHelper.xmlProcessingError(mensaje);
		}
	}
	

	/**
	 * Copia los nodos de un documento XML a otro.
	 * 
	 * @param inXML
	 *            Documento XML origen
	 * @param outXML
	 *            Documento XML destino
	 * @param date
	 *            Fecha en formato AAAAMMDD
	 * @param cycle
	 *            N�mero de ciclo (iteraci�n de la misma fecha)
	 * @throws XPathExpressionException
	 *             error procesando XML
	 */

	private void copyXML(Document inXML, Document outXML, LocalDate date, long cycle) throws XPathExpressionException {
			Node raiz = outXML.importNode(inXML.getFirstChild(), true);
		outXML.appendChild(raiz);

		Node cabecera = (Node) xpath.evaluate(XPATH_HEADER, outXML, XPathConstants.NODE);
		// Modificamos los nodos que nos interese
		Node fechaCreacion = (Node) xpath.evaluate(XPATH_HEADER_DATE, cabecera, XPathConstants.NODE);
		fechaCreacion.setTextContent(date.toString());

		Node loteID = (Node) xpath.evaluate(XPATH_HEADER_BATCH_ID, cabecera, XPathConstants.NODE);
		Node receptor = (Node) xpath.evaluate(XPATH_HEADER_RECEIVER, cabecera, XPathConstants.NODE);
		String receptorID = receptor.getTextContent() + date.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
		if (cycle < 10) {
			receptorID += "0" + Long.toString(cycle);
		} else if (cycle < 99) {
			receptorID += Long.toString(cycle);
		} else {
			receptorID += "99";
		}
		
		loteID.setTextContent(receptorID);

		Node loteSecuencia = (Node) xpath.evaluate(XPATH_HEADER_BATCH_SEQ, cabecera, XPathConstants.NODE);
		loteSecuencia.setTextContent("1");

		Node loteTotal = (Node) xpath.evaluate(XPATH_HEADER_BATCH_TOTAL, cabecera, XPathConstants.NODE);
		loteTotal.setTextContent("1");

	}

	private void copyXMLValores(Document inXML, Document outXML) throws XPathExpressionException {
		Node raiz = outXML.importNode(inXML.getFirstChild(), true);
		outXML.appendChild(raiz);

		Node cabecera = (Node) xpath.evaluate(XPATH_HEADER, outXML, XPathConstants.NODE);
		// Modificamos los nodos que nos interese
		Node cuerpo = (Node) xpath.evaluate(XPATH_BODY, outXML, XPathConstants.NODE);
		
		for (int i = 0; i < cuerpo.getChildNodes().getLength(); i++) {
			Node recibo = cuerpo.getChildNodes().item(i);
			Node producto = (Node) xpath.evaluate(XPATH_PRODUCTO, recibo, XPathConstants.NODE);
 			if (producto != null && producto.getTextContent().trim().equalsIgnoreCase("")) {
				Node idRecibo = (Node) xpath.evaluate(XPATH_IDRECIBO, recibo, XPathConstants.NODE);
				String id = idRecibo.getTextContent();
			
				
			}
 		
		}

		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer;
		try {
	
			transformer = tf.newTransformer();
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			
			StringWriter writer = new StringWriter();
			transformer.transform(new DOMSource(outXML), new StreamResult(writer));
		
		//	String output = writer.getBuffer().toString().replaceAll("\n|\r", "");
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
		}

		//
	}

	/**
	 * Copia el contenido de un XML en otro existente (lo a�ade al final).
	 * 
	 * @param inXML
	 *            Documento XML origen
	 * @param outXML
	 *            Documento XML destino
	 * @throws XPathExpressionException
	 *             error procesando XML
	 */
	private void appendXML(Document inXML, Document outXML) throws XPathExpressionException {
		Node oriCabecera = (Node) xpath.evaluate(XPATH_HEADER, inXML, XPathConstants.NODE);
		Node fusCabecera = (Node) xpath.evaluate(XPATH_HEADER, outXML, XPathConstants.NODE);
		Node oriCuerpo = (Node) xpath.evaluate(XPATH_BODY, inXML, XPathConstants.NODE);
		Node fusCuerpo = (Node) xpath.evaluate(XPATH_BODY, outXML, XPathConstants.NODE);

		// Como ya existe, nos copiamos solo la parte de la cabecera que nos interesa
		Node oriProcesos = (Node) xpath.evaluate(XPATH_HEADER_PROCESS, oriCabecera, XPathConstants.NODE);
		Node fusProcesos = (Node) xpath.evaluate(XPATH_HEADER_PROCESS, fusCabecera, XPathConstants.NODE);
		NodeList oriProcesosLista = oriProcesos.getChildNodes();
		for (int i = 0; i < oriProcesosLista.getLength(); i++) {
			Node fusProcesoItem = outXML.importNode(oriProcesosLista.item(i), true);
			fusProcesos.appendChild(fusProcesoItem);
		}

		// Y los objetos del cuerpo
		NodeList oriObjetos = oriCuerpo.getChildNodes();
		for (int i = 0; i < oriObjetos.getLength(); i++) {
			Node fusObjetosItem = outXML.importNode(oriObjetos.item(i), true);
			fusCuerpo.appendChild(fusObjetosItem);
		}

		// Contamos los hijos que hemos copiado
		
	}
	private Document readXml(InputStream xmlin) {
	    try {
	        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	        dbf.setNamespaceAware(true);
	        DocumentBuilder db = dbf.newDocumentBuilder();
	        return db.parse(xmlin);
	    } catch (Exception e) {
	        throw new RuntimeException(e);
	    }
	}
	
	
}
