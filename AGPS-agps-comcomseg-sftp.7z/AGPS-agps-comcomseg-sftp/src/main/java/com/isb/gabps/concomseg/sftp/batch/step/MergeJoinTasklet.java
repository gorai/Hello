package com.isb.gabps.concomseg.sftp.batch.step;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.isb.gabps.concomseg.sftp.SFTPConfig;
import com.isb.gabps.concomseg.sftp.batch.BatchGlobals;
import com.isb.gabps.concomseg.sftp.model.TablaSeleccionRecibo;
import com.isb.gabps.concomseg.sftp.pojo.ProcesosEIAC;
import com.isb.gabps.concomseg.sftp.pojo.ProcesosEIAC.Objetos;
import com.isb.gabps.concomseg.sftp.pojo.ProcesosEIAC.Objetos.Recibo;
import com.isb.gabps.concomseg.sftp.repository.TratComDao;
import com.isb.gabps.concomseg.sftp.service.XMLService;

/**
 * Step para fusionar el fichero de pólizas y recibos en uno.
 * 
 * @author xIS08485
 */
@Component(BatchGlobals.TASKLET_MERGE_JOIN)
public class MergeJoinTasklet implements Tasklet {
	// Logger
	private static final Logger LOGGER = LoggerFactory.getLogger(MergeJoinTasklet.class);
	// Servicio para tratamiento de ficheros XMLs
	@Autowired
	private TratComDao repository;
	@Autowired
	private XMLService service;

	// Configuración (del properties)
	@Autowired
	private SFTPConfig config;

	/**
	 * Hace un merge de tipo union (concatena todos los ficheros diarios en uno
	 * mensual)
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.debug("Iniciando step de merge los ficheros de pólizas y recibos.");
		
         LOGGER.warn("JMLO W : INICIANDO JOIN");
		// Obtenemos parámetros del job (la fecha)
		// Lo usaremos para componer el XML fusionado
		Map<String, Object> params = chunkContext.getStepContext().getJobParameters();
		String fecha = (String) params.get(BatchGlobals.JOB_PARAM_DATE);

		// Recuperamos el contexto de ejecución, lo usaremos para guardar datos
		// de la ejecución que usaremos en otras clases (como el id del job,
		// o el estado actual del proceso)
		ExecutionContext contexto = chunkContext.getStepContext().getStepExecution().getJobExecution()
				.getExecutionContext();

		// El job-id determina la ubicación de los archivos temporales
		String jobId = contexto.getString(BatchGlobals.JOB_CTX_JOB_ID);

		// Fusionamos los ficheros
		contexto.putString(BatchGlobals.JOB_CTX_JOB_ACTION, BatchGlobals.ACTION_MERGE_JOIN);
		LOGGER.debug("Haciendo merge de los ficheros");
		String xmlPolizas = config.getFSTempPoliciesFile(jobId);
		String xmlRecibos = config.getFSTempCollectionsFile(jobId);
		String xmlFusionado = config.getFSInFile(fecha);
		
		         LOGGER.warn("JMLO W : FIN DE MERGE union"+xmlPolizas+" "+xmlRecibos+" "+xmlFusionado);
		InputStream ficheroFusionado=service.mergeJoin(xmlPolizas, xmlRecibos, xmlFusionado,jobId);
		 if(ficheroFusionado==null)
			 return RepeatStatus.FINISHED;
		StreamSource xml = new StreamSource(service.mergeJoin(xmlPolizas, xmlRecibos, xmlFusionado,jobId));//if(false)
 
		ProcesosEIAC procesoEIAC = obtenerClasedeXml(xml,fecha);
		//LOGGER.debug("Despues en execute");
		String xmlEscribir=obtenerXmldeClase(procesoEIAC);
		if(xmlEscribir!=null) {
			service.enviarFicheroCompleto(xmlEscribir.getBytes(),xmlFusionado);
	//	InputStream source = new ByteArrayInputStream(xmlEscribir.getBytes());
		LOGGER.debug("Pasando en execute a string");
	//	xml.setInputStream(source);
		LOGGER.debug("Seteando a String");
	//	   Files.write(xmlFusionado, xmlEscribir.getBytes());//if(false)
		   LOGGER.debug("Scribiendo en fusionado");
		contexto.remove(BatchGlobals.JOB_CTX_JOB_ACTION);
		// FIN OK
		LOGGER.debug("Fin exitoso del step.");
		}
		return RepeatStatus.FINISHED;
	}
	
	
	private static String obtenerXmldeClase(ProcesosEIAC employee){
        try{
        	LOGGER.debug("Dentro de obtenerClase empleado");
            //Create JAXB Context
            JAXBContext jaxbContext = JAXBContext.newInstance(ProcesosEIAC.class);
            //Create Marshaller
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            //Required formatting??
            LOGGER.debug("Seteando");
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            //Print XML String to Console
            StringWriter sw = new StringWriter();
            //Write XML to StringWriter
            LOGGER.debug("Antes de marshal");
            jaxbMarshaller.marshal(employee, sw);
            //Verify XML Content
            LOGGER.debug("Despues de marshall");
            String xmlContent = sw.toString();
            LOGGER.debug("Pasando a String");
           return xmlContent;

        } catch (JAXBException e) {

            LOGGER.error(e.getMessage());
            return null;
        }

    }

	private ProcesosEIAC obtenerClasedeXml(StreamSource xmlString,String fecha) {
		JAXBContext jaxbContext;
		try {
			jaxbContext = JAXBContext.newInstance(ProcesosEIAC.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

			ProcesosEIAC procesos = (ProcesosEIAC) jaxbUnmarshaller.unmarshal(xmlString);
			procesos=procesarNoEncontrados(procesos,fecha);
			LOGGER.debug("DEvolvemos en obtenerClasedeXml");
			return procesos;

		}

		catch (JAXBException e){

	      LOGGER.error(e.getMessage());
			return null;
		}

	}

	private ProcesosEIAC procesarNoEncontrados(ProcesosEIAC xmls,String fecha) {
		ProcesosEIAC nuevoProceso= new ProcesosEIAC();
		nuevoProceso.setCabecera(xmls.getCabecera());
		nuevoProceso.setObjetos(new Objetos());
		String datos="";
		
		LOGGER.debug("JMLO Vamos a procesar los no encontrados");
		for (int i = 0; i < xmls.getObjetos().getRecibo().size(); i++) {

			Recibo recibo = xmls.getObjetos().getRecibo().get(i);
			
	
			//if(recibo.getDatosRecibo().getSituacionRecibo().trim().equalsIgnoreCase(""))
			//	recibo.getDatosRecibo().setSituacionRecibo("PE");
			String vacio="";
			
			if(recibo.getDatosRecibo().getSituacionRecibo().trim().equalsIgnoreCase("")) {
				LOGGER.info("información ok");
			}else {
			if (recibo.getDatosPoliza().getProductoDGS() == null
					|| recibo.getDatosPoliza().getProductoDGS().trim().equalsIgnoreCase(vacio)) {
				LOGGER.debug("JMLO Hay uno no encontrado");
				String poliza = recibo.getDatosPoliza().getIdPoliza();
				Integer numSuplemento = recibo.getDatosPoliza().getNumeroSuplemento();
				String coRecibo = recibo.getDatosRecibo().getIdRecibo();
				LOGGER.debug("JMLO Vamos a la consulta");
				List<TablaSeleccionRecibo> listaProd = repository.existePoliza(poliza, numSuplemento, coRecibo);
				LOGGER.debug("JMLO Salimos de la consulta"+listaProd.size());
				if (listaProd.size() > 0) {
					String fraccionPago = listaProd.get(0).getCoPeriodPago();
					String dgs = listaProd.get(0).getCoProducto();
					recibo.getDatosPoliza().setProductoDGS(dgs);
					recibo.getDatosRecibo().setFraccionPago(fraccionPago);
					nuevoProceso.getObjetos().getRecibo().add(recibo);
				}else {
					 datos+="No encontrado en base de datos poliza: "+poliza+" numSuplemento: "+numSuplemento+" recibo: "+coRecibo+"\n";
					
					
				} 
			}
			else {
				nuevoProceso.getObjetos().getRecibo().add(recibo);
			}
		}
		}
LOGGER.debug("Retorno");		
return nuevoProceso;
	}

}
