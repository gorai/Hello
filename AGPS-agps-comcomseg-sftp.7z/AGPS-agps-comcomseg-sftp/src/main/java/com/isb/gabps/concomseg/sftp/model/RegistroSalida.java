package com.isb.gabps.concomseg.sftp.model;

import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * The Class RegistroSalida.
 */
public class RegistroSalida {

    /** The op imuputacion. */
    private String opImputacion;

    /** The cod ident prod. */
    private String codIdentProd;

    /** The concep liquid. */
    private String concepLiquid;

    /** The cuenta debe. */
    private String cuentaDebe;

    /** The moneda. */
    private String moneda;

    /** The fecha op. */
    private LocalDateTime fechaOp;

    /** The canal comer. */
    private String canalComer;

    /** The importe total op. */
    private Double importeTotalOp;

    /** The cuenta haber. */
    private String cuentaHaber;

    /**
     * Instantiates a new registro salida.
     */
    public RegistroSalida() {
        this.opImputacion = this.codIdentProd = this.concepLiquid = this.cuentaDebe = this.moneda = this.canalComer = this.cuentaHaber = "";
        this.importeTotalOp = 0.0;
        this.fechaOp = LocalDateTime.now();
    }

    /**
     * Gets the op imuputacion.
     *
     * @return the op imuputacion
     */
    public String getOpImputacion() {
        return opImputacion;
    }

    /**
     * Sets the op imuputacion.
     *
     * @param opImputacion
     *            the new op imputacion
     */
    public void setOpImputacion(String opImputacion) {
        this.opImputacion = opImputacion;
    }

    /**
     * Gets the cod ident prod.
     *
     * @return the cod ident prod
     */
    public String getCodIdentProd() {
        return codIdentProd;
    }

    /**
     * Sets the cod ident prod.
     *
     * @param codIdentProd
     *            the new cod ident prod
     */
    public void setCodIdentProd(String codIdentProd) {
        this.codIdentProd = codIdentProd;
    }

    /**
     * Gets the concep liquid.
     *
     * @return the concep liquid
     */
    public String getConcepLiquid() {
        return concepLiquid;
    }

    /**
     * Sets the concep liquid.
     *
     * @param concepLiquid
     *            the new concep liquid
     */
    public void setConcepLiquid(String concepLiquid) {
        this.concepLiquid = concepLiquid;
    }

    /**
     * Gets the cuenta debe.
     *
     * @return the cuenta debe
     */
    public String getCuentaDebe() {
        return cuentaDebe;
    }

    /**
     * Sets the cuenta debe.
     *
     * @param cuentaDebe
     *            the new cuenta debe
     */
    public void setCuentaDebe(String cuentaDebe) {
        this.cuentaDebe = cuentaDebe;
    }

    /**
     * Gets the moneda.
     *
     * @return the moneda
     */
    public String getMoneda() {
        return moneda;
    }

    /**
     * Sets the moneda.
     *
     * @param moneda
     *            the new moneda
     */
    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }

    /**
     * Gets the fecha op.
     *
     * @return the fecha op
     */
    public LocalDateTime getFechaOp() {
        return fechaOp;
    }

    /**
     * Sets the fecha op.
     *
     * @param fechaOp
     *            the new fecha op
     */
    public void setFechaOp(LocalDateTime fechaOp) {
        this.fechaOp = fechaOp;
    }

    /**
     * Gets the canal comer.
     *
     * @return the canal comer
     */
    public String getCanalComer() {
        return canalComer;
    }

    /**
     * Sets the canal comer.
     *
     * @param canalComer
     *            the new canal comer
     */
    public void setCanalComer(String canalComer) {
        this.canalComer = canalComer;
    }

    /**
     * Gets the importe total op.
     *
     * @return the importe total op
     */
    public Double getImporteTotalOp() {
        return importeTotalOp;
    }

    /**
     * Sets the importe total op.
     *
     * @param importeTotalOp
     *            the new importe total op
     */
    public void setImporteTotalOp(Double importeTotalOp) {
        this.importeTotalOp = importeTotalOp;
    }

    /**
     * Gets the cuenta haber.
     *
     * @return the cuenta haber
     */
    public String getCuentaHaber() {
        return cuentaHaber;
    }

    /**
     * Sets the cuenta haber.
     *
     * @param cuentaHaber
     *            the new cuenta haber
     */
    public void setCuentaHaber(String cuentaHaber) {
        this.cuentaHaber = cuentaHaber;
    }

    /**
     * Copy.
     *
     * @return the registro salida
     */
    public RegistroSalida copy() {
        RegistroSalida devuelto = new RegistroSalida();
        devuelto.setOpImputacion(opImputacion);
        devuelto.setCodIdentProd(codIdentProd);
        devuelto.setConcepLiquid(concepLiquid);
        devuelto.setCuentaDebe(cuentaDebe);
        devuelto.setMoneda(moneda);
        devuelto.setCanalComer(canalComer);
        devuelto.setImporteTotalOp(importeTotalOp);
        devuelto.setCuentaHaber(cuentaHaber);
        devuelto.setFechaOp(fechaOp);
        return devuelto;
    }

    /**
     * To linea host.
     *
     * @param formatoFecha
     *            the formato fecha
     * @return the string
     */
    public String toLineaHost(String formatoFecha) {

        return String.format("%-119s", String.format("%2s", opImputacion) + String.format("%5s", codIdentProd)
                + String.format("%3s", concepLiquid) + String.format("%21s", cuentaDebe) + String.format("%3s", moneda)
                + String.format("%10s", fechaOp.format(DateTimeFormatter.ofPattern(formatoFecha)))
                + String.format("%3s", canalComer)
                + String.format("%018.2f", importeTotalOp)
                        .replace(Character.toString(((DecimalFormat) DecimalFormat.getInstance())
                                .getDecimalFormatSymbols().getDecimalSeparator()), "")
                + String.format("%21s", cuentaHaber));
    }
}
