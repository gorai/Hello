package com.isb.gabps.concomseg.sftp.batch.step;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.PathMatcher;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.isb.conector.S3Repository;
import com.isb.conector.S3RepositoryImpl;
import com.isb.conector.S3RepositoryImplDummie;
import com.isb.gabps.concomseg.sftp.SFTPConfig;
import com.isb.gabps.concomseg.sftp.batch.BatchGlobals;
import com.isb.gabps.concomseg.sftp.service.XMLService;

/**
 * Step para fusionar los ficheros XMLs diarios en uno mensual.
 * 
 * @author xIS08485
 */
@Component(BatchGlobals.TASKLET_MERGE_UNION)
public class MergeUnionTasklet implements Tasklet {
	// Logger
	private static final Logger LOGGER = LoggerFactory.getLogger(MergeUnionTasklet.class);
	
	// Servicio para tratamiento de ficheros XMLs
	@Autowired
	private XMLService service;
	
	// Configuración (del properties)
	@Autowired
	private SFTPConfig config;
	
	public S3Repository repository;
	
	public String incrementarMes(String mes) {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		String mesActual="";
		try {
			Date date = sdf.parse(mes);
			Calendar cal = Calendar.getInstance();
			cal. setTime(date);
			cal.add(Calendar.MONTH, 1);
			SimpleDateFormat format1 = new SimpleDateFormat("yyyyMM");
			mesActual = format1.format(cal.getTime());
		
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			LOGGER.error("Error al obtener las fechas");
			return "";
		}
return mesActual;
	}
	
	
	
	/**
	 * Hace un merge de tipo union (concatena todos los ficheros diarios en uno mensual)
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.debug("Iniciando step de merge los ficheros diarios en uno mensual.");
		if(repository==null)
			repository =  config.getS3Repository(); //if(false)S3RepositoryImplDummie()S3RepositoryImpl()
		// Obtenemos parámetros del job (fecha y ciclo)
		// Lo usaremos para los datos de cabecera del XML mensual
		Map<String, Object> params = chunkContext.getStepContext().getJobParameters();
		String fecha = (String) params.get(BatchGlobals.JOB_PARAM_DATE);
		long ciclo  = (long) params.get(BatchGlobals.JOB_PARAM_CYCLE);
		LocalDate localDate = LocalDate.parse(fecha, DateTimeFormatter.BASIC_ISO_DATE);
		String mes = localDate.format(DateTimeFormatter.ofPattern("yyyyMM"));
		LOGGER.debug("Obtenido parametros fecha '" + fecha + "' y ciclo '" + ciclo + "'");
		
		// Recuperamos el contexto de ejecución, lo usaremos para guardar datos
		// de la ejecución que usaremos en otras clases (como el id del job,
		// o el estado actual del proceso)
		ExecutionContext contexto = chunkContext.getStepContext().getStepExecution()
				.getJobExecution().getExecutionContext();
		
		// El job-id determina la ubicación de los archivos temporales
		String jobId = contexto.getString(BatchGlobals.JOB_CTX_JOB_ID);
		
		// Fusionamos los ficheros de pólizas en uno
		contexto.putString(BatchGlobals.JOB_CTX_JOB_ACTION, BatchGlobals.ACTION_MERGE_POL);
		LOGGER.debug("Haciendo merge de los ficheros de pólizas");
		List<String> rutas = searchFiles(config.getFSTempPath(jobId),mes,"POLIZAS");// config.getSFTPInPoliciesPattern(mes)
         LOGGER.warn("JMLO W: despues de las primeras rutas"+rutas.size());
		String mesSiguiente=incrementarMes(mes);
		List<String> rutas2 = searchFiles(config.getFSTempPath(jobId), mesSiguiente,"POLIZAS");
         LOGGER.warn("JMLO W: despues de las segundas rutas"+rutas2.size());
		rutas.addAll(rutas2);
		String destino = config.getFSTempPoliciesFile(jobId);
         LOGGER.warn("JMLO W:destino"+destino);
         if(rutas.isEmpty())
        	 return RepeatStatus.FINISHED;
         else {
		service.mergeUnion(rutas, destino, localDate, ciclo);
		contexto.remove(BatchGlobals.JOB_CTX_JOB_ACTION);
		
		// Igual para los recibos
		contexto.putString(BatchGlobals.JOB_CTX_JOB_ACTION, BatchGlobals.ACTION_MERGE_COL);
		LOGGER.debug("Haciendo merge de los ficheros de recibos");
		rutas = searchFiles(config.getFSTempPath(jobId), mes,"RECIBOS");
		rutas2=searchFiles(config.getFSTempPath(jobId), mesSiguiente,"RECIBOS");
		
	        LOGGER.warn("JMLO W: despues de las segundas rutas RECIBOS"+rutas2.size());
		rutas.addAll(rutas2);
		destino = config.getFSTempCollectionsFile(jobId);
		service.mergeUnion(rutas, destino, localDate, ciclo);
		contexto.remove(BatchGlobals.JOB_CTX_JOB_ACTION);
		
		// FIN OK
		LOGGER.debug("Fin exitoso del step");
         LOGGER.warn("JMLO W : FIN DE MERGE union");
		return RepeatStatus.FINISHED;
         }
	}
	
	/**
	 * Devuelve una lista de ficheros, buscando los ficheros que cumplen el patrón de entrada.
	 * 
	 * @param directory Carpeta en la que buscar los ficheros
	 * @param pattern Patrón glob a buscar
	 * @return Lista de rutas a los ficheros encontradas
	 * 
	 * @see <a href="https://docs.oracle.com/javase/tutorial/essential/io/fileOps.html#glob">Globbing Pattern</a>
	 */
	// squid:S2095: Close this "FileSystem".
	// Se ignora porque el default filesystem NO se puede cerrar.
	// https://docs.oracle.com/javase/8/docs/api/java/nio/file/FileSystem.html#close
	@SuppressWarnings("squid:S2095")
	private List<String> searchFiles(String directory, String pattern,String tipo) {
		
			List<String> ficheros = new ArrayList<>();
		 List<String> listaFicheros=repository.listingPattenObjectosBucket(config.getBucketName(), directory+"*"+pattern+"*"+tipo);

		 for(int i=0;i<listaFicheros.size();i++)
			 if(listaFicheros.get(i).startsWith(directory)&&listaFicheros.get(i).contains(tipo) &&listaFicheros.get(i).contains("-"+pattern))
				 ficheros.add(listaFicheros.get(i));
		 
		// Crear el buscador utilizando los filtros glob
		// Glob filtra utilizando el mismo mecanismo que en unix (por ejemplo, como el asterisco como wildcard)
		//		PathMatcher buscador = FileSystems.getDefault().getPathMatcher("glob:**/" + pattern);
	/*	
		// Listar ficheros que cumplan con el patrón de entrada
		for (File archivo: directory.toFile().listFiles()) {
			if (buscador.matches(archivo.toPath()) && esContenido(archivo,tipo)) {
				
				ficheros.add(archivo.toPath());
			}
		}
	
		// Devolver ficheros (ordenados por nombre)
		Collections.sort(ficheros);
		for(int i=0;i<ficheros.size();i++)
			LOGGER.debug("JMLO. Fichero Procesado:"+ficheros.get(i).getFileName());
		LOGGER.debug("-----");*/Collections.sort(ficheros);

		return ficheros;
	}
	
	public boolean esContenido(File archivo, String tipo) {
		//<Recibo>
		//<Poliza>
		String content = "";
		try {
			content = new String (Files.readAllBytes(archivo.toPath()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
		    LOGGER.error(e.getMessage());
			return false;
		}
		if(content.contains(tipo))
			return true;
		else return false;
	}
}
