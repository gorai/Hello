package com.isb.conector;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ListObjectsV2Result;

public interface S3Repository {

	InputStream getFromS3(String fileName, String bucketName);

	String getFromS3Base64EncodedContent(String fileName, String bucketName);

	byte[] getFromS3ByteArrayContent(String fileName, String bucketName);

	void putToS3(String fileName, String bucketName, HashMap<String, String> metadata, byte[] documentContent,
			boolean cipher, String kmsKey);

	String putToS3WithUrl(String fileName, String bucketName, HashMap<String, String> metadata, byte[] documentContent,
			boolean cipher, String kmsKey);

	List<String> listingPattenObjectosBucket(String bucketName, String pattern);
	List<String> deleteByPatter(String bucketName, String pattern);
	
	
 
}
