package com.isb.conector;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.S3ClientOptions;
import com.amazonaws.services.s3.model.CopyObjectRequest;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.ListObjectsV2Request;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;

//import es.openbank.documentmanager.utils.ErrorHandle;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Repository("S3Repository")
public class S3RepositoryImpl implements S3Repository {

  private static final Log LOGGER = LogFactory.getLog(S3RepositoryImpl.class);

  private AmazonS3 s3; 

  private static final String CONTENT_ENCODE_FORMAT = "UTF-8";
  private static final String SE_ALGORITHM = "aws:kms";
  private static final String USER_METADATA_KEY_1 = "x-amz-server-side-encryption-aws-kms-key-id";
  private static final String USER_METADATA_KEY_2 = "x-amz-server-side-encryption";
  private static final String USER_METADATA_VALUE_2 = "aws:kms";

  /**
   * Initialize S3 client.
   */
  private void initS3Client() {
    if (s3 == null) {
  
      s3 = AmazonS3ClientBuilder.defaultClient(); 
    }
  }

  /**
   * Get file from S3.
   */
  @Override
  public InputStream getFromS3(String fileName, String bucketName) {
  
    this.initS3Client();
    S3Object objeto= s3.getObject(bucketName, fileName);
    S3ObjectInputStream stream =objeto.getObjectContent();
    ByteArrayOutputStream temp = new ByteArrayOutputStream();
    try {
	IOUtils.copy(stream, temp);
    	} catch (IOException e2) {
	// TODO Auto-generated catch block
	e2.printStackTrace();
    }

    InputStream content = new ByteArrayInputStream(temp.toByteArray());
    
    try {
		objeto.close();
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
    try {
		LOGGER.info(" JMLO AVIABLEF is: " + content.available());
		LOGGER.warn("JMLO Wftp::obteniendo de s3"+ fileName+ " bucket "+bucketName+ "TOTLA "+content.available());
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
        return content;
  }

  /**
   * Get base64 encoded content from file from S3.
   */
  @Override
  public String getFromS3Base64EncodedContent(String fileName, String bucketName) {
    String content = null;
    try {
      byte[] documentBytes = getFromS3ByteArrayContent(fileName, bucketName);
      content = Base64.encodeBase64String(documentBytes);
    } catch (Throwable e) {
    return e.toString();
    }
    return content;
  }

  /**
   * Get content from file in S3 as byteArray.
   */
  @Override
  public byte[] getFromS3ByteArrayContent(String fileName, String bucketName) {
    byte[] documentBytes = null;
   
    try (InputStream document = this.getFromS3(fileName, bucketName)) {
      documentBytes = IOUtils.toByteArray(document);
      document.read(documentBytes, 0, documentBytes.length);
    } catch (IOException e) {
      return null;
    }
    return documentBytes;
  }



  /**
   * Put object to S3.
   */
  @Override
  public void putToS3(String fileName, String bucketName, HashMap<String, String> metadata,
      byte[] documentContent, boolean cipher, String kmsKey) {
	
    this.initS3Client();
    try (ByteArrayInputStream source = new ByteArrayInputStream(documentContent)) {
     
      ObjectMetadata metadataObject = new ObjectMetadata();
      if (metadata != null) {
        Iterator<String> keys = metadata.keySet().iterator();
        while (keys.hasNext()) {
          String key = keys.next();
          if (metadata.get(key) != null) {
           
            metadataObject.addUserMetadata(key, replaceAccents(metadata.get(key)));
          }
        }
      }
      
      metadataObject.setContentEncoding(CONTENT_ENCODE_FORMAT);
      metadataObject.setContentLength(documentContent.length);

      if (cipher) {
    	
        metadataObject.setSSEAlgorithm(SE_ALGORITHM);
        metadataObject.addUserMetadata(USER_METADATA_KEY_1, kmsKey);
        metadataObject.addUserMetadata(USER_METADATA_KEY_2, USER_METADATA_VALUE_2);
      
      }
 
      s3.putObject(bucketName, fileName, source, metadataObject);
   

    } catch (Exception exception) {
    	 LOGGER.error("Error al tratar de insertar el fichero");
    }
  }
 
  
  @Override
  public String putToS3WithUrl(String fileName, String bucketName, HashMap<String, String> metadata,
      byte[] documentContent, boolean cipher, String kmsKey) {
	
    this.initS3Client();
    try (ByteArrayInputStream source = new ByteArrayInputStream(documentContent)) {
     
      ObjectMetadata metadataObject = new ObjectMetadata();
      if (metadata != null) {
        Iterator<String> keys = metadata.keySet().iterator();
        while (keys.hasNext()) {
          String key = keys.next();
          if (metadata.get(key) != null) {
           
            metadataObject.addUserMetadata(key, replaceAccents(metadata.get(key)));
          }
        }
      }
      
      metadataObject.setContentEncoding(CONTENT_ENCODE_FORMAT);
      metadataObject.setContentLength(documentContent.length);

      if (cipher) {
    	
        metadataObject.setSSEAlgorithm(SE_ALGORITHM);
        metadataObject.addUserMetadata(USER_METADATA_KEY_1, kmsKey);
        metadataObject.addUserMetadata(USER_METADATA_KEY_2, USER_METADATA_VALUE_2);
      
      }
 
      s3.putObject(bucketName, fileName, source, metadataObject);
  	GeneratePresignedUrlRequest request = new GeneratePresignedUrlRequest(bucketName, fileName);

 String url=s3.generatePresignedUrl(request).toString();
return url;
    } catch (Exception exception) {
    	 LOGGER.error("Error al tratar de insertar el fichero");
    	 return "sin Url";
    }
    
  } 
  
 

  
  @Override
  public List<String> listingPattenObjectosBucket(String bucketName,String pattern) {
	  if(this.s3==null)
		  this.initS3Client();
    
	  List<String> listaFiltrada = new ArrayList<String>();
     // ObjectListing objectListing = s3.listObjects(bucketName);
    
      List<S3ObjectSummary> s3Objects = new ArrayList<>();
     
      
      ListObjectsV2Request req = new ListObjectsV2Request().withBucketName(bucketName);//.withPrefix(pattern);
      ListObjectsV2Result result;
   //   listaFiltrada.add("NUEVA ENTRADA");
      do {
          result = s3.listObjectsV2(req);

          for (S3ObjectSummary objectSummary : result.getObjectSummaries()) {
              s3Objects.add(objectSummary);
              listaFiltrada.add(objectSummary.getKey());
          }

          // Si hay más objetos en el bucket que no se han listado aún, 
          // obtén el siguiente lote de objetos y repite el proceso.
          String token = result.getNextContinuationToken();
        
          req.setContinuationToken(token);
      } while (result.isTruncated());
     
      return listaFiltrada;
  }
  
  /*

  private List<String> listingPattenObjectosBucketTemp(String bucketName,String pattern) {
	 
	  if(this.s3==null)
		  this.initS3Client();
      ListObjectsV2Result resultTemp = null;
      ListObjectsV2Request req = new ListObjectsV2Request().withBucketName(bucketName).withPrefix(pattern);
      List<String> listaFiltrada = new ArrayList<String>();
      List<S3ObjectSummary> docList=new ArrayList<>();
      try {
    	  
    	  do{
    		    resultTemp=s3.listObjectsV2(req);
    	        docList.addAll(resultTemp.getObjectSummaries());
    	        String token = resultTemp.getNextContinuationToken();
    	        req.setContinuationToken(token);    	       
    	        for (S3ObjectSummary objectSummary : resultTemp.getObjectSummaries()) {    	       
    	              	  listaFiltrada.add(objectSummary.getKey()); 
    	              }
    	    }while (resultTemp.isTruncated());
         
    	  
 
    	  resultTemp = s3.listObjectsV2(bucketName);
          for (S3ObjectSummary objectSummary : resultTemp.getObjectSummaries()) {
          //    LOGGER.warn("Objetos "+ objectSummary.getKey()+" Tamanio"+ objectSummary.getSize()+pattern);
        //      if(objectSummary.getKey().contains(pattern)) {
            	  listaFiltrada.add(objectSummary.getKey()); 
          //    }
              
          }

      } catch (Exception e) {
    	  LOGGER.warn("Error al listar los objetos del bucket ",e);
      }
      if (resultTemp != null) {
    	  LOGGER.warn("Se han recuperado " + resultTemp.getKeyCount() + " correctamente!"); 	  
      }
      else{
    	  LOGGER.warn("No se han recuperado las líneas del fichero");
      }
    
      return listaFiltrada;
  }
  
*/  
  @Override
  public List<String> deleteByPatter(String bucketName,String pattern) {
	  LOGGER.warn("Listando ficheros del bucket...");
	  if(this.s3==null)
		  this.initS3Client();
      ListObjectsV2Result resultTemp = null;
      List<String> listaFiltrada = new ArrayList<String>();
      try {
          resultTemp = s3.listObjectsV2(bucketName);
        if(!pattern.equalsIgnoreCase("*")) {  
          for (S3ObjectSummary objectSummary : resultTemp.getObjectSummaries()) {
        	  String nombre=objectSummary.getKey();
        	  if (nombre.contains(pattern)) {
        		  s3.deleteObject(bucketName, nombre);
                  listaFiltrada.add(objectSummary.getKey());
        	  }
             
          }

      }else {
    	  for (S3ObjectSummary objectSummary : resultTemp.getObjectSummaries()) {
        	  String nombre=objectSummary.getKey();   
        	  listaFiltrada.add(objectSummary.getKey());
        		  s3.deleteObject(bucketName, nombre);     
          		}
    	  
      		} 
      }
    	  catch (Exception e) {
    		  return new ArrayList<String>();
      }
    	
     
      return listaFiltrada;
  }

  
  

  private String replaceAccents(String string) {
    return StringEscapeUtils.escapeJava(string);
  }







}
