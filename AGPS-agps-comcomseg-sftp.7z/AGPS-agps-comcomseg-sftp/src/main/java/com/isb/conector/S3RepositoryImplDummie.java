package com.isb.conector;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CopyObjectRequest;
import com.amazonaws.services.s3.model.ListObjectsV2Request;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.S3ObjectSummary;

//import es.openbank.documentmanager.utils.ErrorHandle;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.FileSystems;
import java.nio.file.PathMatcher;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Repository("S3Repository")
public class S3RepositoryImplDummie implements S3Repository {

  private static final Log LOGGER = LogFactory.getLog(S3RepositoryImplDummie.class);

 // private AmazonS3 s3;

  private static final String CONTENT_ENCODE_FORMAT = "UTF-8";
  private static final String SE_ALGORITHM = "aws:kms";
  private static final String USER_METADATA_KEY_1 = "x-amz-server-side-encryption-aws-kms-key-id";
  private static final String USER_METADATA_KEY_2 = "x-amz-server-side-encryption";
  private static final String USER_METADATA_VALUE_2 = "aws:kms";
  public static ArrayList<String> listaFicheros=new ArrayList<String>();
  public static String carpetaBucket="d:\\concomseg\\bucket\\";
  /**
   * Initialize S3 client.
   */
  private void initS3Client() {
 /*   if (s3 == null) {
    
      s3 = AmazonS3ClientBuilder.defaultClient();
    }*/
  }

  /**
   * Copy file1 from bucket1 in file2 of the bucket2.
   */
  public void copyS3(String bucket1, String file1, String bucket2, String file2,
      Map<String, String> metadata, String kmsKey) {
    this.initS3Client();
    ObjectMetadata metadataObject = new ObjectMetadata();
    Iterator<String> keys = metadata.keySet().iterator();
    LOGGER.warn("Creando primer s3");
	
    while (keys.hasNext()) {
      String key = keys.next();
      LOGGER.info("Adding metadata: " + key + " - " + replaceAccents(metadata.get(key)));
      metadataObject.addUserMetadata(key, replaceAccents(metadata.get(key)));
    }
    LOGGER.warn("Añadiendo datos");
  	
    metadataObject.setSSEAlgorithm(SE_ALGORITHM);
    metadataObject.addUserMetadata(USER_METADATA_KEY_1, kmsKey);
    metadataObject.addUserMetadata(USER_METADATA_KEY_2, USER_METADATA_VALUE_2);

   LOGGER.info("Source bucket: " + bucket1);
    LOGGER.info("Source file: " + file1);
    LOGGER.info("Destination bucket: " + bucket2);
    LOGGER.info("Destination file: " + file2);

    CopyObjectRequest copyOr = new CopyObjectRequest(bucket1, file1, bucket2, file2);
    LOGGER.warn("Añadiendo datos");
  
    copyOr.setNewObjectMetadata(metadataObject);
    LOGGER.warn("Añadiendo datos");
  
//    s3.copyObject(copyOr);
  }

  /**
   * Get file from S3.
   */
  @Override
  public InputStream getFromS3(String fileName, String bucketName) {
    LOGGER.info("get file from s3  to : " + fileName);
    LOGGER.info("bucketName is: " + bucketName);
    this.initS3Client();
   
    File file = new File(carpetaBucket+fileName);
    InputStream content=null;
	try {
		content = new FileInputStream(file);
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return null;
	}
	 return content;
   
  }

  /**
   * Get base64 encoded content from file from S3.
   */
  @Override
  public String getFromS3Base64EncodedContent(String fileName, String bucketName) {
    String content = null;
    try {
      byte[] documentBytes = getFromS3ByteArrayContent(fileName, bucketName);
      content = Base64.encodeBase64String(documentBytes);
    } catch (Throwable e) {
    return e.toString();
    }
    return content;
  }

  /**
   * Get content from file in S3 as byteArray.
   */
  @Override
  public byte[] getFromS3ByteArrayContent(String fileName, String bucketName) {
	  InputStream inputStream;
	try {
		inputStream = new FileInputStream(carpetaBucket+fileName);
		  byte[] data=IOUtils.readFully(inputStream,-1);  
		  return data;
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    return null;
	}
	  

  }



  /**
   * Put object to S3.
   */
  @Override
  public void putToS3(String fileName, String bucketName, HashMap<String, String> metadata,
      byte[] documentContent, boolean cipher, String kmsKey) {
  
      File file = new File(carpetaBucket+fileName);
      
      try {

          OutputStream os = new FileOutputStream(file);
          os.write(documentContent);       
          os.close();
      } catch (Exception e) {
          e.printStackTrace();
      }
  }
  
 

  
  @Override
  public List<String> listingPattenObjectosBucket(String bucketName,String pattern) {
	  LOGGER.warn("Listando ficheros del bucket...");
	
	  PathMatcher buscador = FileSystems.getDefault().getPathMatcher("glob:**/" + pattern);
	
	 
	  
  //  String[] datos=pattern.split("*");
      List<String> listaFiltrada = new ArrayList<String>();
      File carpeta = new File(carpetaBucket);
      String[] listado = carpeta.list();
      
      for (File archivo: carpeta.listFiles()) {
			if (buscador.matches(archivo.toPath())){
				listaFiltrada.add(archivo.getName());
			}
			}
					
   /*   
      if (listado == null || listado.length == 0) {
        
          return listaFiltrada;
      }
      else {
          for (int i=0; i< listado.length; i++) {
            if(listado[i].contains(datos[i]))
            	listaFiltrada.add(listado[i]);
          }
      }*/
    
      return listaFiltrada;
  }

 
  @Override
  public List<String> deleteByPatter(String bucketName,String pattern) {
	  LOGGER.warn("Listando ficheros del bucket...");
	
	  PathMatcher buscador = FileSystems.getDefault().getPathMatcher("glob:**/" + pattern);
	
	 
	  
  //  String[] datos=pattern.split("*");
      List<String> listaFiltrada = new ArrayList<String>();
      File carpeta = new File(carpetaBucket);
      String[] listado = carpeta.list();
   if(!pattern.equalsIgnoreCase("*")) {  
      for (File archivo: carpeta.listFiles()) {
			if (buscador.matches(archivo.toPath())){
				listaFiltrada.add(archivo.getName());
				archivo.delete();	
			}
      }
   }else {
    	  for (File archivo: carpeta.listFiles()) {
  			
  				listaFiltrada.add(archivo.getName());
  				archivo.delete();	
     }
	
   }				    
      return listaFiltrada;
  }
  
  
  private String replaceAccents(String string) {
    return StringEscapeUtils.escapeJava(string);
  }

@Override
public String putToS3WithUrl(String fileName, String bucketName, HashMap<String, String> metadata,
		byte[] documentContent, boolean cipher, String kmsKey) {
	// TODO Auto-generated method stub
	return null;
}
}
