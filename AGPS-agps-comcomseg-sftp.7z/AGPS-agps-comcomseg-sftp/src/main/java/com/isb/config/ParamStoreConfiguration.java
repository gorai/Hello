package com.isb.config;

import es.openbank.helper.ParameterStoreHelper;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.isb.gabps.concomseg.sftp.SFTPLauncher;

import java.security.ProviderException;
import java.util.Arrays;

@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ParamStoreConfiguration {
	private static final Logger log = LoggerFactory.getLogger(SFTPLauncher.class);
  public static void loadParamStoreConfiguration(String projectKey) {

    try {
      String activeProfiles =System.getenv("ENVIRONMENT");//"dev-es"; 
      
      String[] profiles = ArrayUtils.nullToEmpty(StringUtils.split(activeProfiles, ","));
      Arrays.asList(profiles).forEach(environment -> {
        try {
          String region = System.getenv("REGION");//
          String platform = System.getenv("PLATFORM");
          String msName = System.getenv("SERVICE_NAME");
          String bucketName = System.getenv("bucket.name");
         
         
        
          ParameterStoreHelper.INSTANCE.perform(msName, projectKey, environment, region, platform);
        } catch (Exception e) {
      //    log.error("There was a problem loading environment variables (" + environment
       //       + ") from ParamStore", e);
        }
      });
    } catch (Exception ex) {
      String errorMsg = "Error loading properties";
 //     log.error(errorMsg, ex);
      throw new ProviderException(errorMsg, ex);
    }

  }
}
