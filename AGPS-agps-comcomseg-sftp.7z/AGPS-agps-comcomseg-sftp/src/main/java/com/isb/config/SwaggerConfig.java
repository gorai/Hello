package com.isb.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.DocExpansion;
import springfox.documentation.swagger.web.ModelRendering;
import springfox.documentation.swagger.web.OperationsSorter;
import springfox.documentation.swagger.web.TagsSorter;
import springfox.documentation.swagger.web.UiConfiguration;
import springfox.documentation.swagger.web.UiConfigurationBuilder;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Date;

@Configuration
@EnableSwagger2
@Profile("default")
public class SwaggerConfig {

  @Value("${project.version}")
  private String version;
  @Value("${project.name}")
  private String name;
  @Value("${project.description}")
  private String description;
 /* @Value("${bucket.name}")
  public String bucketName;
  @Value("${bucket.kms}")
  public String bucketKms;*/

  /**
   * Swagger docket configuration.
   */
  @Bean
  public Docket api() {
    return new Docket(DocumentationType.SWAGGER_2).select()
        .apis(RequestHandlerSelectors.basePackage("es.openbank"))
        .paths(PathSelectors.ant("/**")).build().useDefaultResponseMessages(false)
        .directModelSubstitute(Instant.class, Date.class)
        .directModelSubstitute(LocalDate.class, Date.class).apiInfo(apiInfo());
  }

  /**
   * Configuración de Swagger
   *
   * @return Configuración
   */
  @Bean
  public UiConfiguration uiConfig() {
    return UiConfigurationBuilder.builder().deepLinking(true).displayOperationId(false)
        .defaultModelsExpandDepth(1).defaultModelExpandDepth(1)
        .defaultModelRendering(ModelRendering.EXAMPLE).displayRequestDuration(false)
        .docExpansion(DocExpansion.NONE).filter(false).maxDisplayedTags(null)
        .operationsSorter(OperationsSorter.ALPHA).showExtensions(false).tagsSorter(TagsSorter.ALPHA)
        .supportedSubmitMethods(UiConfiguration.Constants.DEFAULT_SUBMIT_METHODS).validatorUrl(null)
        .build();
  }

  private ApiInfo apiInfo() {
    return new ApiInfoBuilder().title(name).description(description).version(version).build();
  }
}
