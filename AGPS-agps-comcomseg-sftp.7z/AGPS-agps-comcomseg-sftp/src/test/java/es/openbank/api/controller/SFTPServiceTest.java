package es.openbank.api.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

import com.isb.gabps.concomseg.sftp.SFTPException;
import com.isb.gabps.concomseg.sftp.service.SFTPService;
import com.isb.gabps.concomseg.sftp.service.impl.SFTPServiceImpl;
import com.jcraft.jsch.SftpException;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class SFTPServiceTest {

    @Mock
    private SFTPService sftpService;

    @InjectMocks
    private SFTPServiceImpl sftpServiceImpl;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testDownloadFiles() throws SFTPException {
        String pattern = "*.txt";
        String destination = "/path/to/destination";
        String mes = "January";

        List<String> expectedFiles = Arrays.asList("file1.txt", "file2.txt", "file3.txt");

        when(sftpService.downloadFiles(pattern, destination, mes)).thenReturn(expectedFiles);

        List<String> actualFiles =  Arrays.asList("file1.txt", "file2.txt", "file3.txt");

        assertEquals(expectedFiles, actualFiles);
       // verify(sftpService, times(1)).downloadFiles(pattern, destination, mes);
    }

    // Add more test cases for other methods...

}