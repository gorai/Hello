package es.openbank.api.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.isb.gabps.concomseg.sftp.SFTPException;
import com.isb.gabps.concomseg.sftp.service.XMLService;
import com.isb.gabps.concomseg.sftp.service.impl.XMLServiceImpl;

public class XMLServiceTest {

    private XMLService xmlService;

    @Before
    public void setUp() {
        try {
			xmlService = new XMLServiceImpl();
		} catch (SFTPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @Test
    public void testMergeUnion() throws SFTPException {
        List<String> sources = new ArrayList<>();
        sources.add("source1.xml");
        sources.add("source2.xml");
        String target = "target.xml";
        LocalDate date = LocalDate.now();
        long cycle = -1;

        // Mock any dependencies if needed
      
        // when(xmlParser.parse(anyString())).thenReturn(someValue);
         xmlService.mergeUnion(sources, target, date, cycle);
         assertNotNull(xmlService);
        //xmlService.mergeUnion(sources, target, date, cycle);

        // Add assertions to verify the behavior of the method
        // Example: assertEquals(expectedValue, actualValue);
    }

    @Test
    public void testMergeJoin() throws SFTPException {
        String policyXML = "policy.xml";
        String collectionXML = "collection.xml";
        String target = "target.xml";
        String jobId = "job123";

        // Mock any dependencies if needed
        // Example: XMLParser xmlParser = mock(XMLParser.class);
        // when(xmlParser.parse(anyString())).thenReturn(someValue);
        // xmlService.setXMLParser(xmlParser);
        String lista="";
        InputStream result = new ByteArrayInputStream(lista.getBytes());
        assertNotNull(result);
        // Add assertions to verify the behavior of the method
        // Example: assertNotNull(result);
    }

    @Test
    public void testEnviarFicheroCompleto() {
        byte[] input = new byte[] { 1, 2, 3 };
        String target = "target.xml";
       boolean ejecucion= xmlService.enviarFicheroCompleto(null, "salida/test");
       
       assertEquals(ejecucion, true);
        // Mock any dependencies if needed
       
        // when(sftpClient.uploadFile(any(byte[].class), anyString())).thenReturn(true);
         
     
       //xmlService.enviarFicheroCompleto(input, target);
        
        // Add assertions to verify the behavior of the method
        // Example: assertTrue(result);
    }
}