package es.openbank.api.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.isb.gabps.concomseg.sftp.batch.step.DownloadTasklet;

public class DownloadTaskletTest {

    @Test
    public void testGenerarFicheroDiarioCompleto() {
        // Create a sample list of data
        List<String> data = new ArrayList<>();
        data.add("Data 1");
        data.add("Data 2");
        data.add("Data 3");

        // Call the method to generate the file
        DownloadTasklet downloadTasklet = new DownloadTasklet();
        

        // TODO: Add assertions to verify the generated file
        // For example, you can check if the file exists, has the correct content, etc.
        // Add your assertions here

        // Example assertion: Check if the file exists
        File file = new File("path/to/generated/file.txt");
       // Assert.assertTrue(file.exists());

        // Example assertion: Check if the file has the correct content
        List<String> fileContent = null;
		try {
			fileContent = Files.readAllLines(Paths.get("path/to/generated/file.txt"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      
    }
}